-- ACNextGen.lua v0.7 Phase0-5統合版
local observer   = require('modules/observer')
local tire_state = require('modules/tire_state')
local tire_memory =require('modules/tire_memory')
local tire_force = require('modules/tire_force')
local drivetrain =require('modules/drivetrain')
local diff_lsd = require('modules/diff_lsd')
local suspension = require('modules/suspension')
local thermal    = require('modules/thermal')
local steering = require('modules/steering_dynamics')
local steering_mechanism =require('modules/steering_mechanism')
local virtual_inertia =require('modules/virtual_inertia')
local chassis_flex =require('modules/chassis_flex')
local chassis_roll =require('modules/chassis_roll')
local chassis_energy = require('modules/chassis_energy')
local tire_contact  = require('modules/tire_contact')
local tire_compliance =require('modules/tire_compliance')
local load_transfer = require('modules/load_transfer')
local sprung_mass = require('modules/sprung_mass')
local tire_dynamics = require('modules/tire_dynamics')
local control_arm =require('modules/control_arm')
local arm_compliance =require('modules/arm_compliance')
local brake_system =require('modules/brake_system')
local brake_fade =require('modules/brake_fade')
local brake_lock =require('modules/brake_lock')
local tire_hop =require('modules/tire_hop')
local damper_model =require('modules/damper_model')
local caster_effect =require('modules/caster_effect')
local progressive_spring =require('modules/progressive_spring')
local vehicle_condition =require('modules/vehicle_condition')
local damage_event =require('modules/damage_event')
local weight_distribution =require('modules/weight_distribution')
local physics = require('modules/physics')

function script.init()
    observer.init()
    ac.log("ACNextGen Phase 0-5 起動")
end

function script.update(dt)

    observer.update(dt)

    tire_state.update(dt)

    tire_memory.update(dt)

    steering.update(dt)
    
    steering_mechanism.update(dt)

    chassis_flex.update(dt)

    chassis_energy.update(dt)

    control_arm.update(dt)

    arm_compliance.update(dt)

    chassis_roll.update(dt)

    suspension.update(dt)

    load_transfer.update(dt)

    sprung_mass.update(dt)

    virtual_inertia.update(dt)

    tire_contact.update(dt)

    tire_force.update(dt)

    tire_compliance.update(dt)

    diff_lsd.update(dt)

    drivetrain.update(dt)

    thermal.update(dt)

    brake_system.update(dt)

    brake_fade.update(dt)

    tire_dynamics.update(dt)

    brake_lock.update(dt)

    tire_hop.update(dt)

    damper_model.update(dt)

    progressive_spring.update(dt)

    caster_effect.update(dt)

    vehicle_condition.update(dt)

    damage_event.update(dt)

    weight_distribution.update(dt)

    physics.update(dt)
    
end

function script.windowMain(dt)

    if observer and observer.drawUI then
        observer.drawUI()
    end

    if physics and physics.drawUI then
        physics.drawUI()
    end

end