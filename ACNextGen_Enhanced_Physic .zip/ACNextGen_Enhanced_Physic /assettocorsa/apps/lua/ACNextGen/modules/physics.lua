---@diagnostic disable: undefined-global

--============================================================
-- physics.lua
-- ACNextGen v1.1
-- Universal Physics Hub
--
-- 車両側 script.lua は使わない。
-- ACNextGen App側で各Phaseを統合し、共有値を管理する。
--============================================================

local M = {}

------------------------------------------------------------
-- Safe number
------------------------------------------------------------

local function num(v)
    return tonumber(v) or 0
end

local function clamp(v, minV, maxV)
    if v < minV then return minV end
    if v > maxV then return maxV end
    return v
end

------------------------------------------------------------
-- Internal state
------------------------------------------------------------

M.state = {
    alive = 0,

    speedKmh = 0,
    yawRate = 0,

    wheelsValid = false,

    load = {[0]=0,[1]=0,[2]=0,[3]=0},
    slipRatio = {[0]=0,[1]=0,[2]=0,[3]=0},
    slipAngle = {[0]=0,[1]=0,[2]=0,[3]=0},
    omega = {[0]=0,[1]=0,[2]=0,[3]=0},

    dltLoad = {[0]=0,[1]=0,[2]=0,[3]=0},

    forceLat = {[0]=0,[1]=0,[2]=0,[3]=0},
    forceLong = {[0]=0,[1]=0,[2]=0,[3]=0},

    loadRatio = {[0]=1,[1]=1,[2]=1,[3]=1},

    diffLock = 0,
    diffDiff = 0,
    diffHeat = 0,

    status = "INIT",
}

------------------------------------------------------------
-- Read car base data
------------------------------------------------------------

local function readCar(car)

    if not car then
        M.state.status = "NO CAR"
        M.state.wheelsValid = false
        return
    end

    M.state.speedKmh =
        num(car.speedKmh)

    if car.localAngularVelocity then
        M.state.yawRate =
            num(car.localAngularVelocity.y)
    else
        M.state.yawRate = 0
    end

    if not car.wheels then
        M.state.status = "NO WHEELS"
        M.state.wheelsValid = false
        return
    end

    M.state.wheelsValid = true

    for i = 0, 3 do

        local w = car.wheels[i]

        if w then

            M.state.load[i] =
                num(w.load)

            M.state.slipRatio[i] =
                num(w.slipRatio)

            M.state.slipAngle[i] =
                num(w.slipAngle)

            M.state.omega[i] =
                num(w.angularSpeed)

        else

            M.state.load[i] = 0
            M.state.slipRatio[i] = 0
            M.state.slipAngle[i] = 0
            M.state.omega[i] = 0

        end

    end

    M.state.status = "RUNNING"

end

------------------------------------------------------------
-- Read ACNextGen module outputs
------------------------------------------------------------

local function readModules()

    for i = 0, 3 do

        ----------------------------------------------------
        -- Phase6 Dynamic Load Transfer
        ----------------------------------------------------

        M.state.dltLoad[i] =
            num(
                ac.load(
                    "ngp_dlt_load_" .. i
                )
            )

        ----------------------------------------------------
        -- Tire force / contact patch outputs
        ----------------------------------------------------

        local lat =
            num(
                ac.load(
                    "ngp_lat_" .. i
                )
            )

        local long =
            num(
                ac.load(
                    "ngp_long_" .. i
                )
            )

        local cpLat =
            num(
                ac.load(
                    "ngp_cp_lat_" .. i
                )
            )

        local cpLong =
            num(
                ac.load(
                    "ngp_cp_long_" .. i
                )
            )

        M.state.forceLat[i] =
            lat + cpLat

        M.state.forceLong[i] =
            long + cpLong

        ----------------------------------------------------
        -- Virtual load ratio
        ----------------------------------------------------

        local baseLoad =
            M.state.load[i]

        if baseLoad > 100 then

            local ratio =
                (
                    baseLoad +
                    M.state.dltLoad[i]
                )
                /
                (
                    baseLoad +
                    1
                )

            M.state.loadRatio[i] =
                clamp(
                    ratio,
                    0.70,
                    1.30
                )

        else

            M.state.loadRatio[i] = 1.0

        end

    end

    --------------------------------------------------------
    -- Diff / LSD values
    --------------------------------------------------------

    M.state.diffLock =
        num(
            ac.load(
                "ngp_diff_lock"
            )
        )

    M.state.diffDiff =
        num(
            ac.load(
                "ngp_diff_diff"
            )
        )

    M.state.diffHeat =
        num(
            ac.load(
                "ngp_diff_heat"
            )
        )

end

------------------------------------------------------------
-- Publish unified physics state
------------------------------------------------------------

local function publish()

    ac.store(
        "ngp_hub_alive",
        M.state.alive
    )

    ac.store(
        "ngp_hub_status",
        M.state.status
    )

    ac.store(
        "ngp_hub_speed",
        M.state.speedKmh
    )

    ac.store(
        "ngp_hub_yaw",
        M.state.yawRate
    )

    ac.store(
        "ngp_hub_diff_lock",
        M.state.diffLock
    )

    ac.store(
        "ngp_hub_diff_diff",
        M.state.diffDiff
    )

    ac.store(
        "ngp_hub_diff_heat",
        M.state.diffHeat
    )

    for i = 0, 3 do

        ac.store(
            "ngp_hub_load_" .. i,
            M.state.load[i]
        )

        ac.store(
            "ngp_hub_dlt_" .. i,
            M.state.dltLoad[i]
        )

        ac.store(
            "ngp_hub_ratio_" .. i,
            M.state.loadRatio[i]
        )

        ac.store(
            "ngp_hub_slipR_" .. i,
            M.state.slipRatio[i]
        )

        ac.store(
            "ngp_hub_slipA_" .. i,
            M.state.slipAngle[i]
        )

        ac.store(
            "ngp_hub_omega_" .. i,
            M.state.omega[i]
        )

        ac.store(
            "ngp_hub_force_lat_" .. i,
            M.state.forceLat[i]
        )

        ac.store(
            "ngp_hub_force_long_" .. i,
            M.state.forceLong[i]
        )

    end

end

------------------------------------------------------------
-- Main update
------------------------------------------------------------

function M.update(dt, car)

    M.state.alive =
        M.state.alive + 1

    readCar(car)
    readModules()
    publish()

end

------------------------------------------------------------
-- Debug draw
------------------------------------------------------------

function M.drawUI()

    ui.separator()
    ui.text("=== ACNextGen Physics Hub ===")

    ui.text(
        "Status : " ..
        tostring(
            ac.load("ngp_hub_status")
        )
    )

    ui.text(
        "Alive  : " ..
        tostring(
            ac.load("ngp_hub_alive")
        )
    )

    ui.text(
        string.format(
            "Speed %.1f km/h | Yaw %.5f",
            num(ac.load("ngp_hub_speed")),
            num(ac.load("ngp_hub_yaw"))
        )
    )

    ui.text(
        string.format(
            "Diff Lock %.1f%% | Diff %.3f | Heat %.1f",
            num(ac.load("ngp_hub_diff_lock")) * 100,
            num(ac.load("ngp_hub_diff_diff")),
            num(ac.load("ngp_hub_diff_heat"))
        )
    )

    ui.separator()

    for i = 0, 3 do

        ui.text(
            string.format(
                "W%d load %.0f dLT %.0f ratio %.3f slipR %.3f slipA %.3f",
                i,
                num(ac.load("ngp_hub_load_" .. i)),
                num(ac.load("ngp_hub_dlt_" .. i)),
                num(ac.load("ngp_hub_ratio_" .. i)),
                num(ac.load("ngp_hub_slipR_" .. i)),
                num(ac.load("ngp_hub_slipA_" .. i))
            )
        )

        ui.text(
            string.format(
                "   forceLat %.1f forceLong %.1f omega %.2f",
                num(ac.load("ngp_hub_force_lat_" .. i)),
                num(ac.load("ngp_hub_force_long_" .. i)),
                num(ac.load("ngp_hub_omega_" .. i))
            )
        )

    end

end

return M