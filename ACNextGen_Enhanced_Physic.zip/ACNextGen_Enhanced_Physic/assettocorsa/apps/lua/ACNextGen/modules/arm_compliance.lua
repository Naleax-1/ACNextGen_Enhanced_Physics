---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- arm_compliance.lua
-- Phase 4.6
-- Control Arm Elastic Compliance
-- ブッシュ・アームたわみ近似
--============================================================

local M = {}

--============================================================
-- Parameters
--============================================================

M.params = {
    lateralFlex = 0.020,
    brakeFlex   = 0.010,
    driveFlex   = 0.008,

    tau = 0.080,

    maxCamber = 0.080,
    maxToe    = 0.050,
}

--============================================================
-- State
--============================================================

local state = {
    camber = {
        [0] = 0,
        [1] = 0,
        [2] = 0,
        [3] = 0,
    },

    toe = {
        [0] = 0,
        [1] = 0,
        [2] = 0,
        [3] = 0,
    },
}

M.debug = state

--============================================================
-- Utility
--============================================================

local function clamp(v, minValue, maxValue)
    if v < minValue then
        return minValue
    end

    if v > maxValue then
        return maxValue
    end

    return v
end

local function lowPass(current, target, alpha)
    return current + (target - current) * alpha
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    local car = ac.getCar(0)
    if not car then
        return
    end

    local lateralAccel = 0

    if car.acceleration then
        lateralAccel = car.acceleration.x or 0
    end

    local brake = car.brake or 0
    local gas   = car.gas or 0

    local alpha =
        dt /
        (
            M.params.tau
            +
            dt
        )

    for i = 0, 3 do
        --------------------------------------------------
        -- Wheel side
        -- 0 FL / 1 FR / 2 RL / 3 RR
        --------------------------------------------------

        local side =
            (
                i == 0
                or
                i == 2
            )
            and -1
            or 1

        --------------------------------------------------
        -- Camber compliance
        --------------------------------------------------

        local targetCamber =
            lateralAccel
            *
            side
            *
            M.params.lateralFlex

        targetCamber =
            clamp(
                targetCamber,
                -M.params.maxCamber,
                M.params.maxCamber
            )

        --------------------------------------------------
        -- Toe compliance
        --------------------------------------------------

        local rearBias =
            (
                i >= 2
            )
            and 1.5
            or 0.5

        local targetToe =
            (
                brake * M.params.brakeFlex
                -
                gas * M.params.driveFlex
            )
            *
            rearBias

        targetToe =
            clamp(
                targetToe,
                -M.params.maxToe,
                M.params.maxToe
            )

        --------------------------------------------------
        -- Filter
        --------------------------------------------------

        state.camber[i] =
            lowPass(
                state.camber[i],
                targetCamber,
                alpha
            )

        state.toe[i] =
            lowPass(
                state.toe[i],
                targetToe,
                alpha
            )

        --------------------------------------------------
        -- Export
        --------------------------------------------------

        ac.store(
            "ngp_arm_camber_" .. i,
            state.camber[i]
        )

        ac.store(
            "ngp_arm_toe_" .. i,
            state.toe[i]
        )
    end
end

--============================================================
-- Public API
--============================================================

function M.getCamber(i)
    return state.camber[i] or 0
end

function M.getToe(i)
    return state.toe[i] or 0
end

function M.debugStr()
    return string.format(
        "CAM %.5f %.5f %.5f %.5f\n" ..
        "TOE %.5f %.5f %.5f %.5f",

        state.camber[0],
        state.camber[1],
        state.camber[2],
        state.camber[3],

        state.toe[0],
        state.toe[1],
        state.toe[2],
        state.toe[3]
    )
end

return M
