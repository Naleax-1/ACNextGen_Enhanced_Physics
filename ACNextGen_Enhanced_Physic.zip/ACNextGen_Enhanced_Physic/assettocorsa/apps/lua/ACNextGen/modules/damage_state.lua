---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- damage_state.lua
-- Phase 11.2
-- Damage State Core
-- 車体・各輪ダメージ蓄積状態
--============================================================

local M = {}

--============================================================
-- Parameters
--============================================================

M.params = {
    minDamage = 0.0,
    maxDamage = 1.0,
}

--============================================================
-- State
--============================================================

local state = {
    chassis = 0.0,

    wheel = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },
}

M.debug = state

--============================================================
-- Utility
--============================================================

local function safeNumber(value, defaultValue)
    return tonumber(value) or defaultValue
end

local function clampDamage(value)
    value =
        safeNumber(
            value,
            0.0
        )

    if value < M.params.minDamage then
        return M.params.minDamage
    end

    if value > M.params.maxDamage then
        return M.params.maxDamage
    end

    return value
end

local function isValidWheelIndex(index)
    return
        index == 0
        or index == 1
        or index == 2
        or index == 3
end

local function exportChassis()
    ac.store(
        "ngp_damage_chassis",
        state.chassis
    )
end

local function exportWheel(index)
    if not isValidWheelIndex(index) then
        return
    end

    ac.store(
        "ngp_damage_wheel_" .. index,
        state.wheel[index]
    )
end

local function exportAll()
    exportChassis()

    for i = 0, 3 do
        exportWheel(i)
    end
end

--============================================================
-- Public API
--============================================================

function M.damageChassis(value)
    local amount =
        safeNumber(
            value,
            0.0
        )

    state.chassis =
        clampDamage(
            state.chassis
            +
            amount
        )

    exportChassis()
end

function M.damageWheel(index, value)
    if not isValidWheelIndex(index) then
        return
    end

    local amount =
        safeNumber(
            value,
            0.0
        )

    state.wheel[index] =
        clampDamage(
            state.wheel[index]
            +
            amount
        )

    exportWheel(index)
end

function M.setChassis(value)
    state.chassis =
        clampDamage(
            value
        )

    exportChassis()
end

function M.setWheel(index, value)
    if not isValidWheelIndex(index) then
        return
    end

    state.wheel[index] =
        clampDamage(
            value
        )

    exportWheel(index)
end

function M.reset()
    state.chassis = 0.0

    for i = 0, 3 do
        state.wheel[i] = 0.0
    end

    exportAll()
end

function M.get()
    return state
end

function M.getChassis()
    return state.chassis
end

function M.getWheel(index)
    if not isValidWheelIndex(index) then
        return 0.0
    end

    return state.wheel[index] or 0.0
end

function M.debugStr()
    return string.format(
        "Damage Chassis %.3f\n" ..
        "Wheel %.3f %.3f %.3f %.3f",

        state.chassis,

        state.wheel[0],
        state.wheel[1],
        state.wheel[2],
        state.wheel[3]
    )
end

--============================================================
-- Initial export
--============================================================

exportAll()

return M
