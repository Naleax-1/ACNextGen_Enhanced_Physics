---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- tire_memory.lua
-- Phase 17
-- Tire Memory / Recovery Model
-- タイヤ履歴記憶・回復・一時グリップ低下モデル
--============================================================

local M = {}

--============================================================
-- Parameters
--============================================================

M.params = {
    --------------------------------------------------------
    -- Filtering
    --------------------------------------------------------

    slipTau = 0.25,
    loadTau = 0.35,

    --------------------------------------------------------
    -- Memory build
    --------------------------------------------------------

    slipAngleBuildGain = 0.50,
    slipRatioBuildGain = 0.30,
    loadBuildGain      = 0.20,

    loadReference = 4000.0,

    --------------------------------------------------------
    -- Recovery
    --------------------------------------------------------

    recoveryGain = 0.18,

    warmRecoveryTemp = 75.0,
    hotRecoveryTemp  = 105.0,

    normalTempRecovery = 1.00,
    warmTempRecovery   = 0.70,
    hotTempRecovery    = 0.35,

    slipAngleRecoveryGain = 0.60,
    slipRatioRecoveryGain = 0.80,

    --------------------------------------------------------
    -- Grip
    --------------------------------------------------------

    gripGain = 0.30,

    minGrip = 0.70,
    maxGrip = 1.05,

    --------------------------------------------------------
    -- Limits
    --------------------------------------------------------

    maxMemory = 1.0,

    ambientTemp = 25.0,
}

--============================================================
-- State
--============================================================

M.state = {}

for i = 0, 3 do
    M.state[i] = {
        slipAngle = 0.0,
        slipRatio = 0.0,

        load = 0.0,

        memory = 0.0,
        grip = 1.0,

        build = 0.0,
        recovery = 0.0,

        tyreTemp = 25.0,
        tempRecovery = 1.0,
        slipRecovery = 1.0,
    }
end

M.debug = M.state

--============================================================
-- Utility
--============================================================

local function clamp(v, minValue, maxValue)
    if v < minValue then
        return minValue
    end

    if v > maxValue then
        return maxValue
    end

    return v
end

local function safeNumber(value, defaultValue)
    return tonumber(value) or defaultValue
end

local function safeLoad(key, defaultValue)
    local value =
        ac.load(key)

    if value == nil then
        return defaultValue
    end

    return safeNumber(
        value,
        defaultValue
    )
end

local function safeStore(key, value)
    pcall(
        function()
            ac.store(
                key,
                value
            )
        end
    )
end

local function lowPass(current, target, tau, dt)
    return
        current
        +
        (
            target
            -
            current
        )
        *
        (
            dt
            /
            (
                tau
                +
                dt
            )
        )
end

--============================================================
-- Input helpers
--============================================================

local function getWheelLoad(wheel, index)
    local load =
        safeNumber(
            wheel.load,
            nil
        )

    if load ~= nil then
        return load
    end

    local normalLoad =
        safeNumber(
            wheel.normalLoad,
            nil
        )

    if normalLoad ~= nil then
        return normalLoad
    end

    local dynamicLoad =
        safeLoad(
            "ngp_dlt_load_" .. index,
            0.0
        )

    return
        M.params.loadReference
        +
        dynamicLoad
end

local function getTyreTemp(index)
    return safeLoad(
        "ngp_tyre_temp_" .. index,
        M.params.ambientTemp
    )
end

--============================================================
-- Memory calculation
--============================================================

local function calculateBuild(state)
    local loadFactor =
        state.load
        /
        math.max(
            M.params.loadReference,
            1.0
        )

    local build =
        state.slipAngle
        *
        M.params.slipAngleBuildGain
        +
        state.slipRatio
        *
        M.params.slipRatioBuildGain
        +
        loadFactor
        *
        M.params.loadBuildGain

    return clamp(
        build,
        0.0,
        M.params.maxMemory
    )
end

local function calculateTempRecovery(tyreTemp)
    if tyreTemp < M.params.warmRecoveryTemp then
        return M.params.normalTempRecovery
    end

    if tyreTemp < M.params.hotRecoveryTemp then
        return M.params.warmTempRecovery
    end

    return M.params.hotTempRecovery
end

local function calculateSlipRecovery(state)
    local slipLoss =
        state.slipAngle
        *
        M.params.slipAngleRecoveryGain
        +
        state.slipRatio
        *
        M.params.slipRatioRecoveryGain

    return clamp(
        1.0
        -
        slipLoss,
        0.0,
        1.0
    )
end

local function updateMemory(state, dt)
    local build =
        calculateBuild(
            state
        )

    local tempRecovery =
        calculateTempRecovery(
            state.tyreTemp
        )

    local slipRecovery =
        calculateSlipRecovery(
            state
        )

    local recovery =
        tempRecovery
        *
        slipRecovery
        *
        dt
        *
        M.params.recoveryGain

    --------------------------------------------------------
    -- 元コードの思想を維持:
    -- memory は build まで一気に上がり、recovery でゆっくり下がる
    --------------------------------------------------------

    state.memory =
        clamp(
            math.max(
                state.memory,
                build
            )
            -
            recovery,
            0.0,
            M.params.maxMemory
        )

    state.build =
        build

    state.recovery =
        recovery

    state.tempRecovery =
        tempRecovery

    state.slipRecovery =
        slipRecovery
end

local function updateGrip(state)
    state.grip =
        clamp(
            1.0
            -
            state.memory
            *
            M.params.gripGain,
            M.params.minGrip,
            M.params.maxGrip
        )
end

--============================================================
-- Export
--============================================================

local function exportWheel(index, state)
    safeStore(
        "ngp_memory_" .. index,
        state.memory
    )

    safeStore(
        "ngp_memory_grip_" .. index,
        state.grip
    )

    safeStore(
        "ngp_memory_build_" .. index,
        state.build
    )

    safeStore(
        "ngp_memory_recovery_" .. index,
        state.recovery
    )

    safeStore(
        "ngp_memory_slip_angle_" .. index,
        state.slipAngle
    )

    safeStore(
        "ngp_memory_slip_ratio_" .. index,
        state.slipRatio
    )
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    local car =
        ac.getCar(0)

    if not car or not car.wheels then
        return
    end

    for i = 0, 3 do
        local wheel =
            car.wheels[i]

        if wheel then
            local state =
                M.state[i]

            ------------------------------------------------
            -- Filtered slip / load
            ------------------------------------------------

            local slipAngle =
                math.abs(
                    safeNumber(
                        wheel.slipAngle,
                        0.0
                    )
                )

            local slipRatio =
                math.abs(
                    safeNumber(
                        wheel.slipRatio,
                        0.0
                    )
                )

            local load =
                math.abs(
                    getWheelLoad(
                        wheel,
                        i
                    )
                )

            state.slipAngle =
                lowPass(
                    state.slipAngle,
                    slipAngle,
                    M.params.slipTau,
                    dt
                )

            state.slipRatio =
                lowPass(
                    state.slipRatio,
                    slipRatio,
                    M.params.slipTau,
                    dt
                )

            state.load =
                lowPass(
                    state.load,
                    load,
                    M.params.loadTau,
                    dt
                )

            ------------------------------------------------
            -- Temperature
            ------------------------------------------------

            state.tyreTemp =
                getTyreTemp(
                    i
                )

            ------------------------------------------------
            -- Memory / grip
            ------------------------------------------------

            updateMemory(
                state,
                dt
            )

            updateGrip(
                state
            )

            ------------------------------------------------
            -- Export
            ------------------------------------------------

            exportWheel(
                i,
                state
            )
        end
    end
end

--============================================================
-- Public API
--============================================================

function M.getMemory(index)
    local state =
        M.state[index]

    if not state then
        return 0.0
    end

    return state.memory
end

function M.getGrip(index)
    local state =
        M.state[index]

    if not state then
        return 1.0
    end

    return state.grip
end

function M.getState(index)
    return M.state[index]
end

function M.debugStr(index)
    local state =
        M.state[index or 0]
        or
        M.state[0]

    return string.format(
        "Mem %.3f Grip %.3f\n" ..
        "SA %.3f SR %.3f Load %.0f\n" ..
        "Build %.3f Rec %.4f Temp %.1f",

        state.memory,
        state.grip,

        state.slipAngle,
        state.slipRatio,
        state.load,

        state.build,
        state.recovery,
        state.tyreTemp
    )
end

return M
