---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- load_transfer.lua
-- Phase 6
-- Dynamic Load Transfer / Perception Mapping
-- 動的荷重移動・認知マッピング
--============================================================

local M = {}

--============================================================
-- Geometry
--============================================================

local initialized = false

local geometry = {
    wheelbase = 2.50,
    trackF    = 1.45,
    trackR    = 1.42,
}

--============================================================
-- Parameters
--============================================================

M.params = {
    tauPitch = 0.060,
    tauRoll  = 0.040,

    maxPitch = 4500.0,
    maxRoll  = 3500.0,

    defaultMass = 1300.0,
    defaultCGH  = 0.55,

    tireHopLoadGain = 0.25,
}

--============================================================
-- State
--============================================================

local filtered = {
    pitch = 0.0,
    roll  = 0.0,
}

M.state = {
    front = 0.5,
    rear  = 0.5,

    left  = 0.5,
    right = 0.5,

    pitchState = "NEUTRAL",
    rollState  = "NEUTRAL",

    transition = "STABLE",
}

M.debug = {
    ax = 0.0,
    az = 0.0,

    mass = 0.0,
    cgH  = 0.0,

    rawPitch  = 0.0,
    rawRoll   = 0.0,

    filtPitch = 0.0,
    filtRoll  = 0.0,

    load = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    pitchRatio = 0.0,
    rollRatio  = 0.0,
}

--============================================================
-- Utility
--============================================================

local function clamp(v, minValue, maxValue)
    if v < minValue then
        return minValue
    end

    if v > maxValue then
        return maxValue
    end

    return v
end

local function safeNumber(value, defaultValue)
    return tonumber(value) or defaultValue
end

local function lowPass(current, target, tau, dt)
    return
        current
        +
        (
            target
            -
            current
        )
        *
        (
            dt
            /
            (
                tau
                +
                dt
            )
        )
end

local function safeLoad(key, defaultValue)
    local value =
        ac.load(key)

    if value == nil then
        return defaultValue
    end

    return safeNumber(
        value,
        defaultValue
    )
end

local function safeStore(key, value)
    pcall(
        function()
            ac.store(
                key,
                value
            )
        end
    )
end

local function safeConfig(section, key, defaultValue)
    local ok, value =
        pcall(
            function()
                return ac.getCarConfig(
                    0,
                    section,
                    key,
                    defaultValue
                )
            end
        )

    if not ok then
        return defaultValue
    end

    return safeNumber(
        value,
        defaultValue
    )
end

--============================================================
-- Geometry
--============================================================

local function initGeometry()
    geometry.wheelbase =
        safeConfig(
            "BASIC",
            "WHEELBASE",
            geometry.wheelbase
        )

    geometry.trackF =
        safeConfig(
            "BASIC",
            "FRONT_TRACK",
            geometry.trackF
        )

    geometry.trackR =
        safeConfig(
            "BASIC",
            "REAR_TRACK",
            geometry.trackR
        )

    if geometry.wheelbase <= 0 then
        geometry.wheelbase = 2.50
    end

    if geometry.trackF <= 0 then
        geometry.trackF = 1.45
    end

    if geometry.trackR <= 0 then
        geometry.trackR = 1.42
    end

    initialized = true

    pcall(
        function()
            ac.log(
                string.format(
                    "[NGP LoadTransfer] WB=%.2f TF=%.2f TR=%.2f",
                    geometry.wheelbase,
                    geometry.trackF,
                    geometry.trackR
                )
            )
        end
    )
end

--============================================================
-- Input
--============================================================

local function readAcceleration(car)
    local ax = 0.0
    local az = 0.0

    if car.acceleration then
        ax =
            safeNumber(
                car.acceleration.x,
                0.0
            )

        az =
            safeNumber(
                car.acceleration.z,
                0.0
            )
    end

    return ax, az
end

local function readMass(car)
    return safeNumber(
        car.mass,
        M.params.defaultMass
    )
end

local function readCGHeight()
    local cgH =
        safeConfig(
            "BASIC",
            "CG_HEIGHT",
            M.params.defaultCGH
        )

    if cgH <= 0 then
        return M.params.defaultCGH
    end

    return cgH
end

--============================================================
-- Core calculation
--============================================================

local function calculateRawTransfer(ax, az, mass, cgH)
    local rawPitch =
        mass
        *
        az
        *
        cgH
        /
        geometry.wheelbase

    local averageTrack =
        (
            geometry.trackF
            +
            geometry.trackR
        )
        *
        0.5

    local rawRoll =
        mass
        *
        ax
        *
        cgH
        /
        averageTrack

    rawPitch =
        clamp(
            rawPitch,
            -M.params.maxPitch,
            M.params.maxPitch
        )

    rawRoll =
        clamp(
            rawRoll,
            -M.params.maxRoll,
            M.params.maxRoll
        )

    return rawPitch, rawRoll
end

local function updateFilteredTransfer(rawPitch, rawRoll, dt)
    filtered.pitch =
        lowPass(
            filtered.pitch,
            rawPitch,
            M.params.tauPitch,
            dt
        )

    filtered.roll =
        lowPass(
            filtered.roll,
            rawRoll,
            M.params.tauRoll,
            dt
        )
end

local function distributeWheelLoads()
    local pitch =
        filtered.pitch

    local roll =
        filtered.roll

    --------------------------------------------------------
    -- Wheel index:
    -- 0 FL / 1 FR / 2 RL / 3 RR
    --------------------------------------------------------

    M.debug.load[0] =
        -pitch * 0.5
        -
        roll
        *
        0.5

    M.debug.load[1] =
        -pitch
        *
        0.5
        +
        roll
        *
        0.5

    M.debug.load[2] =
        pitch
        *
        0.5
        -
        roll
        *
        0.5

    M.debug.load[3] =
        pitch
        *
        0.5
        +
        roll
        *
        0.5
end

local function applyTireHopLoadPulse()
    for i = 0, 3 do
        local hop =
            safeLoad(
                "ngp_tirehop_" .. i,
                0.0
            )

        M.debug.load[i] =
            M.debug.load[i]
            +
            hop
            *
            M.params.tireHopLoadGain
    end
end

--============================================================
-- Perception mapping
--============================================================

local function updatePerceptionState()
    local pitchRatio =
        clamp(
            filtered.pitch
            /
            M.params.maxPitch,
            -1.0,
            1.0
        )

    local rollRatio =
        clamp(
            filtered.roll
            /
            M.params.maxRoll,
            -1.0,
            1.0
        )

    M.debug.pitchRatio =
        pitchRatio

    M.debug.rollRatio =
        rollRatio

    M.state.front =
        clamp(
            0.5
            -
            pitchRatio
            *
            0.5,
            0.0,
            1.0
        )

    M.state.rear =
        clamp(
            0.5
            +
            pitchRatio
            *
            0.5,
            0.0,
            1.0
        )

    M.state.left =
        clamp(
            0.5
            -
            rollRatio
            *
            0.5,
            0.0,
            1.0
        )

    M.state.right =
        clamp(
            0.5
            +
            rollRatio
            *
            0.5,
            0.0,
            1.0
        )

    if math.abs(pitchRatio) < 0.1 then
        M.state.pitchState = "NEUTRAL"

    elseif pitchRatio > 0 then
        M.state.pitchState = "BRAKE LOAD"

    else
        M.state.pitchState = "DRIVE LOAD"
    end

    if math.abs(rollRatio) < 0.1 then
        M.state.rollState = "NEUTRAL"

    elseif rollRatio > 0 then
        M.state.rollState = "RIGHT LOAD"

    else
        M.state.rollState = "LEFT LOAD"
    end

    if
        math.abs(
            pitchRatio
        )
        +
        math.abs(
            rollRatio
        )
        >
        0.8
    then
        M.state.transition = "LIMIT TRANSITION"
    else
        M.state.transition = "NORMAL"
    end
end

--============================================================
-- Export
--============================================================

local function exportState()
    for i = 0, 3 do
        safeStore(
            "ngp_dlt_load_" .. i,
            M.debug.load[i]
        )
    end

    safeStore(
        "ngp_dlt_pitch",
        filtered.pitch
    )

    safeStore(
        "ngp_dlt_roll",
        filtered.roll
    )

    safeStore(
        "ngp_load_front",
        M.state.front
    )

    safeStore(
        "ngp_load_rear",
        M.state.rear
    )

    safeStore(
        "ngp_load_left",
        M.state.left
    )

    safeStore(
        "ngp_load_right",
        M.state.right
    )

    --------------------------------------------------------
    -- Bias aliases
    -- diff_lsd.lua / tire_dynamics.lua 連携用
    --------------------------------------------------------

    safeStore(
        "ngp_front_bias",
        M.state.front
    )

    safeStore(
        "ngp_rear_bias",
        M.state.rear
    )

    safeStore(
        "ngp_left_bias",
        M.state.left
    )

    safeStore(
        "ngp_right_bias",
        M.state.right
    )
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    if not initialized then
        initGeometry()
    end

    local car =
        ac.getCar(0)

    if not car then
        return
    end

    --------------------------------------------------------
    -- Read input
    --------------------------------------------------------

    local ax, az =
        readAcceleration(
            car
        )

    local mass =
        readMass(
            car
        )

    local cgH =
        readCGHeight()

    --------------------------------------------------------
    -- Raw load transfer
    --------------------------------------------------------

    local rawPitch,
          rawRoll =
        calculateRawTransfer(
            ax,
            az,
            mass,
            cgH
        )

    --------------------------------------------------------
    -- Filter
    --------------------------------------------------------

    updateFilteredTransfer(
        rawPitch,
        rawRoll,
        dt
    )

    --------------------------------------------------------
    -- Wheel load distribution
    --------------------------------------------------------

    distributeWheelLoads()

    applyTireHopLoadPulse()

    --------------------------------------------------------
    -- Debug
    --------------------------------------------------------

    M.debug.ax =
        ax

    M.debug.az =
        az

    M.debug.mass =
        mass

    M.debug.cgH =
        cgH

    M.debug.rawPitch =
        rawPitch

    M.debug.rawRoll =
        rawRoll

    M.debug.filtPitch =
        filtered.pitch

    M.debug.filtRoll =
        filtered.roll

    --------------------------------------------------------
    -- Perception
    --------------------------------------------------------

    updatePerceptionState()

    --------------------------------------------------------
    -- Export
    --------------------------------------------------------

    exportState()
end

--============================================================
-- Public API
--============================================================

function M.getState()
    return M.state
end

function M.getLoad(i)
    return M.debug.load[i] or 0.0
end

function M.getPitch()
    return filtered.pitch
end

function M.getRoll()
    return filtered.roll
end

function M.debugStr()
    return string.format(
        "Mass:%.0f CGH:%.3f\n" ..
        "Pitch raw:%+.0f filt:%+.0f %s\n" ..
        "Roll  raw:%+.0f filt:%+.0f %s\n" ..
        "FL:%+.0f FR:%+.0f RL:%+.0f RR:%+.0f",

        M.debug.mass,
        M.debug.cgH,

        M.debug.rawPitch,
        M.debug.filtPitch,
        M.state.pitchState,

        M.debug.rawRoll,
        M.debug.filtRoll,
        M.state.rollState,

        M.debug.load[0],
        M.debug.load[1],
        M.debug.load[2],
        M.debug.load[3]
    )
end

return M
