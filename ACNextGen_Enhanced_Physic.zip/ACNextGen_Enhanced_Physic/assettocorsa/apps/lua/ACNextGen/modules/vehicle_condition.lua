---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- vehicle_condition.lua
-- Phase 12
-- Vehicle Condition / Wear Accumulation Model
-- 車両コンディション・累積劣化モデル
--============================================================

local M = {}

--============================================================
-- Parameters
--============================================================

M.params = {
    --------------------------------------------------------
    -- Damage gains
    --------------------------------------------------------

    impactGain = 0.002,

    loadGain = 0.0005,

    heatGain = 0.0008,

    recovery = 0.00001,

    --------------------------------------------------------
    -- References
    --------------------------------------------------------

    gravity = 9.81,

    suspensionLoadReference = 12000.0,

    brakeHeatStart = 300.0,
    gearboxHeatStart = 80.0,

    --------------------------------------------------------
    -- Limits
    --------------------------------------------------------

    maxDamage = 1.0,
}

--============================================================
-- State
--============================================================

local state = {
    chassis = 0.0,

    suspension = 0.0,

    drivetrain = 0.0,

    brake = 0.0,

    total = 0.0,
}

M.debug = {
    chassis = 0.0,
    suspension = 0.0,
    drivetrain = 0.0,
    brake = 0.0,
    total = 0.0,

    impact = 0.0,
    suspensionLoad = 0.0,
    suspensionOverload = 0.0,

    brakeTemp = 0.0,
    gearboxTemp = 0.0,
}

--============================================================
-- Utility
--============================================================

local function clamp(v, minValue, maxValue)
    if v < minValue then
        return minValue
    end

    if v > maxValue then
        return maxValue
    end

    return v
end

local function safeNumber(value, defaultValue)
    return tonumber(value) or defaultValue
end

local function safeLoad(key, defaultValue)
    local value =
        ac.load(key)

    if value == nil then
        return defaultValue
    end

    return safeNumber(
        value,
        defaultValue
    )
end

local function safeStore(key, value)
    pcall(
        function()
            ac.store(
                key,
                value
            )
        end
    )
end

--============================================================
-- Input
--============================================================

local function calculateImpact(car)
    local acceleration =
        car.acceleration

    if not acceleration then
        return 0.0
    end

    local ax =
        math.abs(
            safeNumber(
                acceleration.x,
                0.0
            )
        )

    local ay =
        math.abs(
            safeNumber(
                acceleration.y,
                0.0
            )
        )

    local az =
        math.abs(
            safeNumber(
                acceleration.z,
                0.0
            )
        )

    --------------------------------------------------------
    -- 元コードと同じく3軸合計。
    -- ただしG換算ではなく、AC加速度値そのものを使う。
    --------------------------------------------------------

    return
        ax
        +
        ay
        +
        az
end

local function getWheelLoad(car, index)
    local wheel =
        car.wheels
        and car.wheels[index]
        or nil

    if wheel then
        local load =
            safeNumber(
                wheel.load,
                nil
            )

        if load ~= nil then
            return load
        end

        local normalLoad =
            safeNumber(
                wheel.normalLoad,
                nil
            )

        if normalLoad ~= nil then
            return normalLoad
        end
    end

    return safeLoad(
        "ngp_dlt_load_" .. index,
        0.0
    )
end

local function calculateSuspensionLoad(car)
    local totalLoad = 0.0

    if not car.wheels then
        return 0.0
    end

    for i = 0, 3 do
        totalLoad =
            totalLoad
            +
            math.abs(
                getWheelLoad(
                    car,
                    i
                )
            )
    end

    return totalLoad
end

local function getMaxBrakeTemp()
    local maxTemp = 0.0

    for i = 0, 3 do
        maxTemp =
            math.max(
                maxTemp,
                safeLoad(
                    "ngp_brake_temp_" .. i,
                    0.0
                )
            )
    end

    return maxTemp
end

--============================================================
-- Condition calculation
--============================================================

local function updateChassisCondition(impact, dt)
    state.chassis =
        clamp(
            state.chassis
            +
            impact
            *
            M.params.impactGain
            *
            dt
            -
            M.params.recovery
            *
            dt,
            0.0,
            M.params.maxDamage
        )
end

local function updateSuspensionCondition(suspensionLoad, dt)
    --------------------------------------------------------
    -- 通常荷重ではなく、基準を超えた分だけ劣化にする
    --------------------------------------------------------

    local overload =
        math.max(
            0.0,
            suspensionLoad
            -
            M.params.suspensionLoadReference
        )

    M.debug.suspensionOverload =
        overload

    state.suspension =
        clamp(
            state.suspension
            +
            overload
            *
            M.params.loadGain
            *
            dt
            -
            M.params.recovery
            *
            dt,
            0.0,
            M.params.maxDamage
        )
end

local function updateDrivetrainCondition(gearboxTemp, dt)
    local heat =
        math.max(
            gearboxTemp
            -
            M.params.gearboxHeatStart,
            0.0
        )

    state.drivetrain =
        clamp(
            state.drivetrain
            +
            heat
            *
            M.params.heatGain
            *
            dt
            -
            M.params.recovery
            *
            dt,
            0.0,
            M.params.maxDamage
        )
end

local function updateBrakeCondition(brakeTemp, dt)
    local heat =
        math.max(
            brakeTemp
            -
            M.params.brakeHeatStart,
            0.0
        )

    state.brake =
        clamp(
            state.brake
            +
            heat
            *
            M.params.heatGain
            *
            dt
            -
            M.params.recovery
            *
            dt,
            0.0,
            M.params.maxDamage
        )
end

local function updateTotalCondition()
    state.total =
        clamp(
            (
                state.chassis
                +
                state.suspension
                +
                state.drivetrain
                +
                state.brake
            )
            *
            0.25,
            0.0,
            M.params.maxDamage
        )
end

--============================================================
-- Export
--============================================================

local function exportState()
    safeStore(
        "ngp_condition_chassis",
        state.chassis
    )

    safeStore(
        "ngp_condition_suspension",
        state.suspension
    )

    safeStore(
        "ngp_condition_drivetrain",
        state.drivetrain
    )

    safeStore(
        "ngp_condition_brake",
        state.brake
    )

    safeStore(
        "ngp_condition_total",
        state.total
    )

    safeStore(
        "ngp_condition_impact",
        M.debug.impact
    )

    safeStore(
        "ngp_condition_susp_load",
        M.debug.suspensionLoad
    )
end

local function updateDebug(impact, suspensionLoad, brakeTemp, gearboxTemp)
    M.debug.chassis =
        state.chassis

    M.debug.suspension =
        state.suspension

    M.debug.drivetrain =
        state.drivetrain

    M.debug.brake =
        state.brake

    M.debug.total =
        state.total

    M.debug.impact =
        impact

    M.debug.suspensionLoad =
        suspensionLoad

    M.debug.brakeTemp =
        brakeTemp

    M.debug.gearboxTemp =
        gearboxTemp
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    local car =
        ac.getCar(0)

    if not car then
        return
    end

    --------------------------------------------------------
    -- Inputs
    --------------------------------------------------------

    local impact =
        calculateImpact(
            car
        )

    local suspensionLoad =
        calculateSuspensionLoad(
            car
        )

    local brakeTemp =
        getMaxBrakeTemp()

    local gearboxTemp =
        safeLoad(
            "ngp_gearbox_temp",
            0.0
        )

    --------------------------------------------------------
    -- Conditions
    --------------------------------------------------------

    updateChassisCondition(
        impact,
        dt
    )

    updateSuspensionCondition(
        suspensionLoad,
        dt
    )

    updateDrivetrainCondition(
        gearboxTemp,
        dt
    )

    updateBrakeCondition(
        brakeTemp,
        dt
    )

    updateTotalCondition()

    --------------------------------------------------------
    -- Debug / Export
    --------------------------------------------------------

    updateDebug(
        impact,
        suspensionLoad,
        brakeTemp,
        gearboxTemp
    )

    exportState()
end

--============================================================
-- Public API
--============================================================

function M.getState()
    return state
end

function M.getTotal()
    return state.total
end

function M.getChassis()
    return state.chassis
end

function M.getSuspension()
    return state.suspension
end

function M.getDrivetrain()
    return state.drivetrain
end

function M.getBrake()
    return state.brake
end

function M.reset()
    state.chassis = 0.0
    state.suspension = 0.0
    state.drivetrain = 0.0
    state.brake = 0.0
    state.total = 0.0

    updateDebug(
        0.0,
        0.0,
        0.0,
        0.0
    )

    exportState()
end

function M.debugStr()
    return string.format(
        "Condition Total %.3f\n" ..
        "Chassis %.3f Susp %.3f\n" ..
        "Drive %.3f Brake %.3f\n" ..
        "Impact %.2f Load %.0f",

        state.total,

        state.chassis,
        state.suspension,

        state.drivetrain,
        state.brake,

        M.debug.impact,
        M.debug.suspensionLoad
    )
end

return M
