---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- brake_fade.lua
-- Phase 10.2
-- Brake Pad Friction Fade Model
-- ブレーキ温度による摩擦係数低下モデル
--============================================================

local M = {}

--============================================================
-- Parameters
--============================================================

M.params = {
    normalMu = 1.00,

    fadeStart = 350.0,
    fadeEnd   = 750.0,

    minMu = 0.55,

    recoveryTau = 3.00,
}

--============================================================
-- State
--============================================================

local state = {
    mu = {
        [0] = 1.0,
        [1] = 1.0,
        [2] = 1.0,
        [3] = 1.0,
    },
}

M.debug = state

--============================================================
-- Dependencies
--============================================================

local okBrakeSystem, brakeSystem =
    pcall(
        require,
        "modules/brake_system"
    )

--============================================================
-- Utility
--============================================================

local function clamp(v, minValue, maxValue)
    if v < minValue then
        return minValue
    end

    if v > maxValue then
        return maxValue
    end

    return v
end

local function lowPass(current, target, alpha)
    return current + (target - current) * alpha
end

local function getBrakeTemperature(index)
    if not okBrakeSystem then
        return 25.0
    end

    if not brakeSystem then
        return 25.0
    end

    if not brakeSystem.getTemp then
        return 25.0
    end

    local ok, value =
        pcall(
            function()
                return brakeSystem.getTemp(index)
            end
        )

    if not ok then
        return 25.0
    end

    return tonumber(value) or 25.0
end

--============================================================
-- Core
--============================================================

local function calculateTargetMu(temp)
    local p = M.params

    if temp <= p.fadeStart then
        return p.normalMu
    end

    local fadeRatio =
        (
            temp
            -
            p.fadeStart
        )
        /
        (
            p.fadeEnd
            -
            p.fadeStart
        )

    fadeRatio =
        clamp(
            fadeRatio,
            0.0,
            1.0
        )

    return
        p.normalMu
        -
        fadeRatio
        *
        (
            p.normalMu
            -
            p.minMu
        )
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    local alpha =
        dt /
        (
            M.params.recoveryTau
            +
            dt
        )

    for i = 0, 3 do
        local temp =
            getBrakeTemperature(i)

        local targetMu =
            calculateTargetMu(temp)

        state.mu[i] =
            lowPass(
                state.mu[i],
                targetMu,
                alpha
            )

        ac.store(
            "ngp_brake_mu_" .. i,
            state.mu[i]
        )
    end
end

--============================================================
-- Public API
--============================================================

function M.getMu(i)
    return state.mu[i] or 1.0
end

function M.debugStr()
    return string.format(
        "BrakeMu FL %.3f FR %.3f RL %.3f RR %.3f",
        state.mu[0],
        state.mu[1],
        state.mu[2],
        state.mu[3]
    )
end

return M
