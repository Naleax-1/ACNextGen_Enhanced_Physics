---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- drivetrain.lua
-- Phase 3.1
-- Drivetrain / Lash / Shaft Model
-- 駆動系・バックラッシュ・シャフトねじれモデル
--============================================================

local M = {}

--============================================================
-- Parameters
--============================================================

M.params = {
    rpmTau = 0.080,

    gearInertia = 0.120,

    lash    = 0.080,
    lashTau = 0.040,

    shaftStiffness = 18.0,
    shaftDamping   = 2.0,

    clutchTau = 0.150,

    shiftShockScale = 0.015,

    gearboxHeatGain = 0.100,

    lsdResistanceGain = 0.150,

    hopShockReference = 5000.0,
    hopTorqueLossGain = 0.120,

    gearboxAmbient = 20.0,
    gearboxCoolRate = 0.0025,
}

--============================================================
-- State
--============================================================

local state = {
    filteredRPM = 0.0,

    driveTorque = 0.0,

    shaftAngle    = 0.0,
    shaftVelocity = 0.0,

    lashState = 0.0,

    clutch = 1.0,

    shiftShock = 0.0,
    shiftStress = 0.0,

    gearboxHeat = 20.0,

    lsdResistance = 0.0,

    prevGear = 0,
}

M.debug = state

--============================================================
-- Utility
--============================================================

local function clamp(v, minValue, maxValue)
    if v < minValue then
        return minValue
    end

    if v > maxValue then
        return maxValue
    end

    return v
end

local function safeNumber(value, defaultValue)
    return tonumber(value) or defaultValue
end

local function safeLoad(key, defaultValue)
    local value =
        ac.load(key)

    if value == nil then
        return defaultValue
    end

    return safeNumber(
        value,
        defaultValue
    )
end

local function lowPass(current, target, tau, dt)
    return
        current
        +
        (
            target
            -
            current
        )
        *
        (
            dt
            /
            (
                tau
                +
                dt
            )
        )
end

--============================================================
-- Input
--============================================================

local function readInputs(car)
    return {
        rpm =
            safeNumber(
                car.rpm,
                0.0
            ),

        gas =
            safeNumber(
                car.gas,
                0.0
            ),

        clutch =
            safeNumber(
                car.clutch,
                1.0
            ),

        gear =
            safeNumber(
                car.gear,
                0
            ),
    }
end

--============================================================
-- Core calculation
--============================================================

local function calculateEngineTorque(gas)
    local rpmRatio =
        clamp(
            state.filteredRPM
            /
            9000.0,
            0.0,
            1.0
        )

    local rpmFactor =
        math.max(
            0.35,
            1.0
            -
            rpmRatio
        )

    return
        gas
        *
        rpmFactor
end

local function calculateTransmittedTorque(engineTorque, gear)
    local gearLoad =
        math.max(
            math.abs(
                gear
            ),
            1.0
        )

    local transmitted =
        engineTorque
        /
        (
            1.0
            +
            gearLoad
            *
            M.params.gearInertia
        )

    transmitted =
        transmitted
        *
        state.clutch

    return transmitted
end

local function updateShiftShock(rpm, gear)
    state.shiftShock = 0.0

    if gear ~= state.prevGear then
        local rpmDiff =
            math.abs(
                rpm
                -
                state.filteredRPM
            )

        state.shiftShock =
            rpmDiff
            *
            M.params.shiftShockScale
    end

    state.prevGear =
        gear
end

local function updateLash(transmittedTorque, dt)
    local lashTarget = 0.0

    if math.abs(transmittedTorque) > M.params.lash then
        lashTarget =
            transmittedTorque
    end

    state.lashState =
        lowPass(
            state.lashState,
            lashTarget,
            M.params.lashTau,
            dt
        )
end

local function updateShaft(dt)
    local shaftForce =
        state.lashState
        *
        M.params.shaftStiffness

    local dampingForce =
        state.shaftVelocity
        *
        M.params.shaftDamping

    state.shaftVelocity =
        state.shaftVelocity
        +
        (
            shaftForce
            -
            dampingForce
        )
        *
        dt

    state.shaftAngle =
        state.shaftAngle
        +
        state.shaftVelocity
        *
        dt
end

local function getHopShock()
    local hopRL =
        math.abs(
            safeLoad(
                "ngp_tirehop_2",
                0.0
            )
        )

    local hopRR =
        math.abs(
            safeLoad(
                "ngp_tirehop_3",
                0.0
            )
        )

    return clamp(
        (
            hopRL
            +
            hopRR
        )
        /
        M.params.hopShockReference,
        0.0,
        1.0
    )
end

local function updateDriveTorque()
    local lsdLock =
        safeLoad(
            "ngp_lsd_lock",
            0.0
        )

    local hopShock =
        getHopShock()

    state.lsdResistance =
        lsdLock
        *
        M.params.lsdResistanceGain

    state.driveTorque =
        state.lashState
        *
        (
            1.0
            -
            state.lsdResistance
        )
        *
        (
            1.0
            -
            hopShock
            *
            M.params.hopTorqueLossGain
        )
end

local function updateStress(engineTorque, transmittedTorque, clutchInput)
    local clutchSlip =
        math.abs(
            clutchInput
            -
            state.clutch
        )

    state.shiftStress =
        math.abs(
            engineTorque
        )
        +
        math.abs(
            transmittedTorque
        )
        +
        clutchSlip
        *
        5.0
        +
        (
            state.filteredRPM
            /
            10000.0
        )
        *
        3.0
end

local function updateGearboxHeat(dt)
    local gearboxLoad =
        math.abs(
            state.lashState
        )
        +
        math.abs(
            state.shiftShock
        )
        +
        math.abs(
            state.shaftVelocity
        )

    state.gearboxHeat =
        state.gearboxHeat
        +
        gearboxLoad
        *
        M.params.gearboxHeatGain
        *
        dt

    state.gearboxHeat =
        state.gearboxHeat
        -
        (
            state.gearboxHeat
            -
            M.params.gearboxAmbient
        )
        *
        M.params.gearboxCoolRate
end

--============================================================
-- Export
--============================================================

local function exportState()
    ac.store(
        "ngp_drive_torque",
        state.driveTorque
    )

    ac.store(
        "ngp_shaft_twist",
        state.shaftAngle
    )

    ac.store(
        "ngp_drive_clutch",
        state.clutch
    )

    ac.store(
        "ngp_gearbox_heat",
        state.gearboxHeat
    )

    ac.store(
        "ngp_drive_lash",
        state.lashState
    )

    ac.store(
        "ngp_shift_shock",
        state.shiftShock
    )

    ac.store(
        "ngp_shift_stress",
        state.shiftStress
    )

    ac.store(
        "ngp_lsd_resistance",
        state.lsdResistance
    )
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    local car =
        ac.getCar(0)

    if not car then
        return
    end

    local input =
        readInputs(
            car
        )

    --------------------------------------------------------
    -- RPM filter
    --------------------------------------------------------

    state.filteredRPM =
        lowPass(
            state.filteredRPM,
            input.rpm,
            M.params.rpmTau,
            dt
        )

    --------------------------------------------------------
    -- Clutch filter
    --------------------------------------------------------

    state.clutch =
        lowPass(
            state.clutch,
            input.clutch,
            M.params.clutchTau,
            dt
        )

    state.clutch =
        clamp(
            state.clutch,
            0.0,
            1.0
        )

    --------------------------------------------------------
    -- Torque path
    --------------------------------------------------------

    local engineTorque =
        calculateEngineTorque(
            input.gas
        )

    local transmittedTorque =
        calculateTransmittedTorque(
            engineTorque,
            input.gear
        )

    --------------------------------------------------------
    -- Shift / lash / shaft
    --------------------------------------------------------

    updateShiftShock(
        input.rpm,
        input.gear
    )

    updateLash(
        transmittedTorque,
        dt
    )

    updateShaft(
        dt
    )

    --------------------------------------------------------
    -- Output torque
    --------------------------------------------------------

    updateDriveTorque()

    --------------------------------------------------------
    -- Stress / heat
    --------------------------------------------------------

    updateStress(
        engineTorque,
        transmittedTorque,
        input.clutch
    )

    updateGearboxHeat(
        dt
    )

    --------------------------------------------------------
    -- Export
    --------------------------------------------------------

    exportState()
end

--============================================================
-- Public API
--============================================================

function M.getDriveTorque()
    return state.driveTorque
end

function M.getShaftTwist()
    return state.shaftAngle
end

function M.getClutch()
    return state.clutch
end

function M.getGearboxHeat()
    return state.gearboxHeat
end

function M.getLash()
    return state.lashState
end

function M.debugStr()
    return string.format(
        "RPMF %.0f\n" ..
        "Torque %.3f\n" ..
        "Shaft %.3f Lash %.3f\n" ..
        "Shift %.3f Stress %.3f\n" ..
        "Heat %.1f LSDRes %.3f",

        state.filteredRPM,

        state.driveTorque,

        state.shaftAngle,
        state.lashState,

        state.shiftShock,
        state.shiftStress,

        state.gearboxHeat,
        state.lsdResistance
    )
end

return M
