---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- brake_lock.lua
-- Phase 10.3
-- Wheel Lock Transition Model
-- ブレーキロック遷移モデル
--============================================================

local M = {}

--============================================================
-- Parameters
--============================================================

M.params = {
    lockSlip      = 0.18,
    recoverSlip   = 0.08,

    transitionTau = 0.08,

    minSpeed      = 10.0,
}

--============================================================
-- State
--============================================================

local state = {
    lock = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },
}

M.debug = {
    slip = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    lock = state.lock,
}

--============================================================
-- Utility
--============================================================

local function lowPass(current, target, alpha)
    return current + (target - current) * alpha
end

local function getWheelSlipRatio(wheel)
    if not wheel then
        return 0.0
    end

    return math.abs(
        tonumber(wheel.slipRatio)
        or 0.0
    )
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    local car = ac.getCar(0)
    if not car or not car.wheels then
        return
    end

    local speedKmh =
        car.speedKmh
        or 0.0

    local alpha =
        dt /
        (
            M.params.transitionTau
            +
            dt
        )

    --------------------------------------------------------
    -- Low speed recovery
    -- 低速ではロック判定を止めるが、値は自然に0へ戻す
    --------------------------------------------------------

    if speedKmh < M.params.minSpeed then
        for i = 0, 3 do
            state.lock[i] =
                lowPass(
                    state.lock[i],
                    0.0,
                    alpha
                )

            M.debug.slip[i] = 0.0

            ac.store(
                "ngp_brake_lock_" .. i,
                state.lock[i]
            )
        end

        return
    end

    --------------------------------------------------------
    -- Wheel lock detection
    --------------------------------------------------------

    for i = 0, 3 do
        local wheel =
            car.wheels[i]

        if wheel then
            local slip =
                getWheelSlipRatio(wheel)

            local target =
                state.lock[i]

            if slip > M.params.lockSlip then
                target = 1.0

            elseif slip < M.params.recoverSlip then
                target = 0.0
            end

            state.lock[i] =
                lowPass(
                    state.lock[i],
                    target,
                    alpha
                )

            M.debug.slip[i] =
                slip

            ac.store(
                "ngp_brake_lock_" .. i,
                state.lock[i]
            )
        else
            state.lock[i] =
                lowPass(
                    state.lock[i],
                    0.0,
                    alpha
                )

            M.debug.slip[i] =
                0.0

            ac.store(
                "ngp_brake_lock_" .. i,
                state.lock[i]
            )
        end
    end
end

--============================================================
-- Public API
--============================================================

function M.getLock(i)
    return state.lock[i] or 0.0
end

function M.debugStr()
    return string.format(
        "Lock FL %.2f FR %.2f RL %.2f RR %.2f",
        state.lock[0],
        state.lock[1],
        state.lock[2],
        state.lock[3]
    )
end

return M
