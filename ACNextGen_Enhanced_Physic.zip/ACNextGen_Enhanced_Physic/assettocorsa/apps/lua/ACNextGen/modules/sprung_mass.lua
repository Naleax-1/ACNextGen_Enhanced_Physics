---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- sprung_mass.lua
-- Phase 13
-- Sprung Mass / Dynamic CG Approximation
-- バネ上質量・動的CG近似モデル
--============================================================

local M = {}

--============================================================
-- Parameters
--============================================================

M.params = {
    frontSpringRef = 32000.0,
    rearSpringRef  = 36000.0,

    pitchCGScale = 0.10,
    rollCGScale  = 0.08,

    pitchTau = 0.100,
    rollTau  = 0.080,

    maxPitchCG = 0.080,
    maxRollCG  = 0.060,

    chassisEnergyPitchGain   = 0.004,
    chassisReleasePitchGain  = 0.006,

    chassisEnergyRollGain    = 0.003,
    chassisReleaseRollGain   = 0.005,
}

--============================================================
-- State
--============================================================

local state = {
    frontCompression = 0.0,
    rearCompression  = 0.0,

    leftCompression  = 0.0,
    rightCompression = 0.0,

    pitchCG = 0.0,
    rollCG  = 0.0,

    pitchState = "NEUTRAL",
    rollState  = "NEUTRAL",
}

M.debug = state

--============================================================
-- Utility
--============================================================

local function clamp(v, minValue, maxValue)
    if v < minValue then
        return minValue
    end

    if v > maxValue then
        return maxValue
    end

    return v
end

local function safeNumber(value, defaultValue)
    return tonumber(value) or defaultValue
end

local function safeLoad(key, defaultValue)
    local value =
        ac.load(key)

    if value == nil then
        return defaultValue
    end

    return safeNumber(
        value,
        defaultValue
    )
end

local function lowPass(current, target, tau, dt)
    return
        current
        +
        (
            target
            -
            current
        )
        *
        (
            dt
            /
            (
                tau
                +
                dt
            )
        )
end

local function safeDiv(value, divisor, fallback)
    if math.abs(divisor) < 0.0001 then
        return fallback
    end

    return value / divisor
end

--============================================================
-- Load input
--============================================================

local function readDynamicLoads()
    return
        safeLoad("ngp_dlt_load_0", 0.0),
        safeLoad("ngp_dlt_load_1", 0.0),
        safeLoad("ngp_dlt_load_2", 0.0),
        safeLoad("ngp_dlt_load_3", 0.0)
end

--============================================================
-- Compression calculation
--============================================================

local function calculateTargetCompression(loadFL, loadFR, loadRL, loadRR)
    local frontSpringRef =
        math.max(
            M.params.frontSpringRef,
            1.0
        )

    local rearSpringRef =
        math.max(
            M.params.rearSpringRef,
            1.0
        )

    local averageSpringRef =
        math.max(
            (
                frontSpringRef
                +
                rearSpringRef
            )
            *
            0.5,
            1.0
        )

    --------------------------------------------------------
    -- Front / rear compression
    --------------------------------------------------------

    local frontLoad =
        (
            loadFL
            +
            loadFR
        )
        *
        0.5

    local rearLoad =
        (
            loadRL
            +
            loadRR
        )
        *
        0.5

    local targetFrontCompression =
        safeDiv(
            frontLoad,
            frontSpringRef,
            0.0
        )

    local targetRearCompression =
        safeDiv(
            rearLoad,
            rearSpringRef,
            0.0
        )

    --------------------------------------------------------
    -- Left / right compression
    --------------------------------------------------------

    local leftLoad =
        (
            loadFL
            +
            loadRL
        )
        *
        0.5

    local rightLoad =
        (
            loadFR
            +
            loadRR
        )
        *
        0.5

    local targetLeftCompression =
        safeDiv(
            leftLoad,
            averageSpringRef,
            0.0
        )

    local targetRightCompression =
        safeDiv(
            rightLoad,
            averageSpringRef,
            0.0
        )

    return
        targetFrontCompression,
        targetRearCompression,
        targetLeftCompression,
        targetRightCompression
end

local function updateCompression(
    targetFront,
    targetRear,
    targetLeft,
    targetRight,
    dt
)
    state.frontCompression =
        lowPass(
            state.frontCompression,
            targetFront,
            M.params.pitchTau,
            dt
        )

    state.rearCompression =
        lowPass(
            state.rearCompression,
            targetRear,
            M.params.pitchTau,
            dt
        )

    state.leftCompression =
        lowPass(
            state.leftCompression,
            targetLeft,
            M.params.rollTau,
            dt
        )

    state.rightCompression =
        lowPass(
            state.rightCompression,
            targetRight,
            M.params.rollTau,
            dt
        )
end

--============================================================
-- Dynamic CG
--============================================================

local function calculateBaseCG()
    local pitchCG =
        (
            state.frontCompression
            -
            state.rearCompression
        )
        *
        M.params.pitchCGScale

    local rollCG =
        (
            state.leftCompression
            -
            state.rightCompression
        )
        *
        M.params.rollCGScale

    pitchCG =
        clamp(
            pitchCG,
            -M.params.maxPitchCG,
            M.params.maxPitchCG
        )

    rollCG =
        clamp(
            rollCG,
            -M.params.maxRollCG,
            M.params.maxRollCG
        )

    return pitchCG, rollCG
end

local function applyChassisEnergyCoupling(pitchCG, rollCG)
    local chassisEnergy =
        safeLoad(
            "ngp_chassis_energy",
            0.0
        )

    local chassisRelease =
        safeLoad(
            "ngp_chassis_release",
            0.0
        )

    pitchCG =
        pitchCG
        +
        chassisEnergy
        *
        M.params.chassisEnergyPitchGain
        -
        chassisRelease
        *
        M.params.chassisReleasePitchGain

    rollCG =
        rollCG
        +
        chassisEnergy
        *
        M.params.chassisEnergyRollGain
        -
        chassisRelease
        *
        M.params.chassisReleaseRollGain

    pitchCG =
        clamp(
            pitchCG,
            -M.params.maxPitchCG,
            M.params.maxPitchCG
        )

    rollCG =
        clamp(
            rollCG,
            -M.params.maxRollCG,
            M.params.maxRollCG
        )

    return pitchCG, rollCG
end

local function updateStateNames()
    if math.abs(state.pitchCG) < 0.005 then
        state.pitchState = "NEUTRAL"

    elseif state.pitchCG > 0 then
        state.pitchState = "FRONT CG"

    else
        state.pitchState = "REAR CG"
    end

    if math.abs(state.rollCG) < 0.005 then
        state.rollState = "NEUTRAL"

    elseif state.rollCG > 0 then
        state.rollState = "LEFT CG"

    else
        state.rollState = "RIGHT CG"
    end
end

--============================================================
-- Export
--============================================================

local function exportState()
    ac.store(
        "ngp_pitch_cg",
        state.pitchCG
    )

    ac.store(
        "ngp_roll_cg",
        state.rollCG
    )

    ac.store(
        "ngp_front_compression",
        state.frontCompression
    )

    ac.store(
        "ngp_rear_compression",
        state.rearCompression
    )

    ac.store(
        "ngp_left_compression",
        state.leftCompression
    )

    ac.store(
        "ngp_right_compression",
        state.rightCompression
    )
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    --------------------------------------------------------
    -- Load transfer input
    --------------------------------------------------------

    local loadFL,
          loadFR,
          loadRL,
          loadRR =
        readDynamicLoads()

    --------------------------------------------------------
    -- Target compression
    --------------------------------------------------------

    local targetFront,
          targetRear,
          targetLeft,
          targetRight =
        calculateTargetCompression(
            loadFL,
            loadFR,
            loadRL,
            loadRR
        )

    --------------------------------------------------------
    -- Filtered compression
    --------------------------------------------------------

    updateCompression(
        targetFront,
        targetRear,
        targetLeft,
        targetRight,
        dt
    )

    --------------------------------------------------------
    -- Dynamic CG
    --------------------------------------------------------

    local pitchCG,
          rollCG =
        calculateBaseCG()

    pitchCG,
    rollCG =
        applyChassisEnergyCoupling(
            pitchCG,
            rollCG
        )

    state.pitchCG =
        pitchCG

    state.rollCG =
        rollCG

    --------------------------------------------------------
    -- State names
    --------------------------------------------------------

    updateStateNames()

    --------------------------------------------------------
    -- Export
    --------------------------------------------------------

    exportState()
end

--============================================================
-- Public API
--============================================================

function M.getState()
    return state
end

function M.getPitchCG()
    return state.pitchCG
end

function M.getRollCG()
    return state.rollCG
end

function M.getFrontCompression()
    return state.frontCompression
end

function M.getRearCompression()
    return state.rearCompression
end

function M.debugStr()
    return string.format(
        "PitchCG %+.4f %s\n" ..
        "RollCG %+.4f %s\n" ..
        "F %.4f R %.4f L %.4f R %.4f",

        state.pitchCG,
        state.pitchState,

        state.rollCG,
        state.rollState,

        state.frontCompression,
        state.rearCompression,
        state.leftCompression,
        state.rightCompression
    )
end

return M
