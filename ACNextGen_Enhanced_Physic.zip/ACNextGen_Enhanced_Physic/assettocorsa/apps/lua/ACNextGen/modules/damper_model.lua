---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- damper_model.lua
-- Phase 4.8
-- High / Low Speed Damper Model
-- 高速・低速ダンパー近似モデル
--============================================================

local M = {}

--============================================================
-- Parameters
--============================================================

M.params = {
    lowSpeedBump    = 2500.0,
    lowSpeedRebound = 3500.0,

    highSpeedBump    = 7000.0,
    highSpeedRebound = 9000.0,

    transition = 0.150,

    maxForce = 12000.0,
}

--============================================================
-- State
--============================================================

local state = {
    force = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    travel = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    velocity = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    mode = {
        [0] = "INIT",
        [1] = "INIT",
        [2] = "INIT",
        [3] = "INIT",
    },

    initialized = {
        [0] = false,
        [1] = false,
        [2] = false,
        [3] = false,
    },
}

M.debug = state

--============================================================
-- Utility
--============================================================

local function clamp(v, minValue, maxValue)
    if v < minValue then
        return minValue
    end

    if v > maxValue then
        return maxValue
    end

    return v
end

local function safeNumber(value, defaultValue)
    return tonumber(value) or defaultValue
end

local function getSuspensionTravel(wheel, fallback)
    if not wheel then
        return fallback
    end

    return safeNumber(
        wheel.suspensionTravel,
        fallback
    )
end

--============================================================
-- Core
--============================================================

local function getDamperCoefficient(velocity)
    local speed =
        math.abs(
            velocity
        )

    local isHighSpeed =
        speed > M.params.transition

    --------------------------------------------------------
    -- compression / rebound
    -- vel > 0 : compression
    -- vel < 0 : rebound
    --------------------------------------------------------

    if velocity > 0 then
        if isHighSpeed then
            return M.params.highSpeedBump, "HIGH BUMP"
        end

        return M.params.lowSpeedBump, "LOW BUMP"
    end

    if isHighSpeed then
        return M.params.highSpeedRebound, "HIGH REBOUND"
    end

    return M.params.lowSpeedRebound, "LOW REBOUND"
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    local car =
        ac.getCar(0)

    if not car or not car.wheels then
        return
    end

    for i = 0, 3 do
        local wheel =
            car.wheels[i]

        if wheel then
            local travel =
                getSuspensionTravel(
                    wheel,
                    state.travel[i]
                )

            ------------------------------------------------
            -- First frame initialization
            -- 初回だけ現在値を基準にして、不自然な初期ショックを防ぐ
            ------------------------------------------------

            if not state.initialized[i] then
                state.travel[i] =
                    travel

                state.velocity[i] =
                    0.0

                state.force[i] =
                    0.0

                state.mode[i] =
                    "INIT"

                state.initialized[i] =
                    true

                ac.store(
                    "ngp_damper_" .. i,
                    state.force[i]
                )

            else
                ------------------------------------------------
                -- Damper velocity
                ------------------------------------------------

                local velocity =
                    (
                        travel
                        -
                        state.travel[i]
                    )
                    /
                    dt

                state.travel[i] =
                    travel

                state.velocity[i] =
                    velocity

                ------------------------------------------------
                -- Damping force
                ------------------------------------------------

                local coefficient, mode =
                    getDamperCoefficient(
                        velocity
                    )

                local force =
                    -velocity
                    *
                    coefficient

                force =
                    clamp(
                        force,
                        -M.params.maxForce,
                        M.params.maxForce
                    )

                state.force[i] =
                    force

                state.mode[i] =
                    mode

                ------------------------------------------------
                -- Export
                ------------------------------------------------

                ac.store(
                    "ngp_damper_" .. i,
                    state.force[i]
                )

                ac.store(
                    "ngp_damper_velocity_" .. i,
                    state.velocity[i]
                )
            end
        else
            state.velocity[i] =
                0.0

            state.force[i] =
                0.0

            state.mode[i] =
                "NIL"

            ac.store(
                "ngp_damper_" .. i,
                state.force[i]
            )

            ac.store(
                "ngp_damper_velocity_" .. i,
                state.velocity[i]
            )
        end
    end
end

--============================================================
-- Public API
--============================================================

function M.getForce(i)
    return state.force[i] or 0.0
end

function M.getVelocity(i)
    return state.velocity[i] or 0.0
end

function M.getMode(i)
    return state.mode[i] or "NIL"
end

function M.debugStr()
    return string.format(
        "Damper FL:%+.0f FR:%+.0f RL:%+.0f RR:%+.0f\n" ..
        "Vel    FL:%+.3f FR:%+.3f RL:%+.3f RR:%+.3f",

        state.force[0],
        state.force[1],
        state.force[2],
        state.force[3],

        state.velocity[0],
        state.velocity[1],
        state.velocity[2],
        state.velocity[3]
    )
end

return M
