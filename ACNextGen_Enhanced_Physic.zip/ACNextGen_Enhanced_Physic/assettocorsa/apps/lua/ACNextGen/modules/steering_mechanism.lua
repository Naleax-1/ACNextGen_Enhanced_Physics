---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- steering_dynamics.lua
-- Phase 8.1
-- Steering Rack / Tie Rod / Knuckle Dynamics
-- ステアリングラック・タイロッド・ナックル反力モデル
--============================================================

local M = {}

--============================================================
-- Parameters
--============================================================

M.params = {
    rackTau    = 0.045,
    tieRodTau  = 0.030,
    knuckleTau = 0.040,

    tieRodGain  = 0.00008,
    knuckleGain = 0.00035,

    friction = 0.08,

    fxKnuckleMix = 0.075,

    minFrictionRack = 0.01,

    maxReaction = 1.50,
    maxOutput   = 2.00,
}

--============================================================
-- State
--============================================================

local state = {
    rack = 0.0,

    tieRod  = 0.0,
    knuckle = 0.0,

    reaction = 0.0,
    friction = 0.0,

    output = 0.0,
}

M.debug = {
    input = 0.0,

    rack = 0.0,

    tieRod  = 0.0,
    knuckle = 0.0,

    reaction = 0.0,
    friction = 0.0,

    output = 0.0,

    fy = 0.0,
    mz = 0.0,
    fx = 0.0,
}

--============================================================
-- Utility
--============================================================

local function sign(x)
    if x < 0 then
        return -1
    end

    if x > 0 then
        return 1
    end

    return 0
end

local function clamp(v, minValue, maxValue)
    if v < minValue then
        return minValue
    end

    if v > maxValue then
        return maxValue
    end

    return v
end

local function safeNumber(value, defaultValue)
    return tonumber(value) or defaultValue
end

local function lowPass(current, target, tau, dt)
    return
        current
        +
        (
            target
            -
            current
        )
        *
        (
            dt
            /
            (
                tau
                +
                dt
            )
        )
end

local function safeStore(key, value)
    pcall(
        function()
            ac.store(
                key,
                value
            )
        end
    )
end

--============================================================
-- Wheel input
--============================================================

local function readFrontWheels(car)
    if not car.wheels then
        return nil, nil
    end

    return car.wheels[0], car.wheels[1]
end

local function readFrontForces(frontLeft, frontRight)
    local fy =
        (
            safeNumber(
                frontLeft.fy,
                0.0
            )
            +
            safeNumber(
                frontRight.fy,
                0.0
            )
        )
        *
        0.5

    local mz =
        (
            safeNumber(
                frontLeft.mz,
                0.0
            )
            +
            safeNumber(
                frontRight.mz,
                0.0
            )
        )
        *
        0.5

    local fx =
        (
            safeNumber(
                frontLeft.fx,
                0.0
            )
            +
            safeNumber(
                frontRight.fx,
                0.0
            )
        )
        *
        0.5

    return fy, mz, fx
end

--============================================================
-- Core
--============================================================

local function updateRack(steer, dt)
    state.rack =
        lowPass(
            state.rack,
            steer,
            M.params.rackTau,
            dt
        )
end

local function updateTieRod(fy, dt)
    state.tieRod =
        lowPass(
            state.tieRod,
            fy,
            M.params.tieRodTau,
            dt
        )
end

local function updateKnuckle(mz, fx, dt)
    local knuckleInput =
        mz
        +
        fx
        *
        M.params.fxKnuckleMix

    state.knuckle =
        lowPass(
            state.knuckle,
            knuckleInput,
            M.params.knuckleTau,
            dt
        )
end

local function calculateReaction()
    local reaction =
        state.tieRod
        *
        M.params.tieRodGain
        +
        state.knuckle
        *
        M.params.knuckleGain

    return clamp(
        reaction,
        -M.params.maxReaction,
        M.params.maxReaction
    )
end

local function calculateFriction()
    if math.abs(state.rack) <= M.params.minFrictionRack then
        return 0.0
    end

    return
        sign(
            state.rack
        )
        *
        M.params.friction
end

local function calculateOutput()
    local output =
        state.rack
        +
        state.reaction
        -
        state.friction

    return clamp(
        output,
        -M.params.maxOutput,
        M.params.maxOutput
    )
end

--============================================================
-- Export
--============================================================

local function exportState()
    safeStore(
        "ngp_steer_mech",
        state.output
    )

    safeStore(
        "ngp_steer_reaction",
        state.reaction
    )

    safeStore(
        "ngp_steer_rack",
        state.rack
    )

    safeStore(
        "ngp_steer_tierod",
        state.tieRod
    )

    safeStore(
        "ngp_steer_knuckle",
        state.knuckle
    )

    safeStore(
        "ngp_steer_friction",
        state.friction
    )
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    local car =
        ac.getCar(0)

    if not car or not car.wheels then
        return
    end

    local steer =
        safeNumber(
            car.steer,
            0.0
        )

    local frontLeft,
          frontRight =
        readFrontWheels(
            car
        )

    if not frontLeft or not frontRight then
        return
    end

    --------------------------------------------------------
    -- Front wheel force input
    --------------------------------------------------------

    local fy,
          mz,
          fx =
        readFrontForces(
            frontLeft,
            frontRight
        )

    --------------------------------------------------------
    -- Steering mechanism
    --------------------------------------------------------

    updateRack(
        steer,
        dt
    )

    updateTieRod(
        fy,
        dt
    )

    updateKnuckle(
        mz,
        fx,
        dt
    )

    state.reaction =
        calculateReaction()

    state.friction =
        calculateFriction()

    state.output =
        calculateOutput()

    --------------------------------------------------------
    -- Debug
    --------------------------------------------------------

    M.debug.input =
        steer

    M.debug.rack =
        state.rack

    M.debug.tieRod =
        state.tieRod

    M.debug.knuckle =
        state.knuckle

    M.debug.reaction =
        state.reaction

    M.debug.friction =
        state.friction

    M.debug.output =
        state.output

    M.debug.fy =
        fy

    M.debug.mz =
        mz

    M.debug.fx =
        fx

    --------------------------------------------------------
    -- Export
    --------------------------------------------------------

    exportState()
end

--============================================================
-- Public API
--============================================================

function M.getOutput()
    return state.output
end

function M.getReaction()
    return state.reaction
end

function M.getRack()
    return state.rack
end

function M.getTieRod()
    return state.tieRod
end

function M.getKnuckle()
    return state.knuckle
end

function M.debugStr()
    return string.format(
        "Rack %.3f Tie %.2f\n" ..
        "Knuckle %.2f Reaction %.3f\n" ..
        "Friction %.3f Output %.3f",

        M.debug.rack,
        M.debug.tieRod,

        M.debug.knuckle,
        M.debug.reaction,

        M.debug.friction,
        M.debug.output
    )
end

return M