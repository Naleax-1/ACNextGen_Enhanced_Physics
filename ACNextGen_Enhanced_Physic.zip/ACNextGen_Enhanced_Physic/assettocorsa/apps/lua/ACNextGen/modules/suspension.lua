---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- suspension.lua
-- Phase 4
-- Suspension Compliance + Alignment Approximation
-- サスペンション統合補正 / アライメント近似
--============================================================

local M = {}

--============================================================
-- Dependencies
--============================================================

local okLT, loadTransfer =
    pcall(
        require,
        "modules/load_transfer"
    )

local okAC, armCompliance =
    pcall(
        require,
        "modules/arm_compliance"
    )

--============================================================
-- Parameters
--============================================================

M.params = {
    --------------------------------------------------------
    -- Legacy / compatibility
    --------------------------------------------------------

    damperScale = 600.0,
    maxForce = 1200.0,

    minSuspSpeed = 0.002,

    --------------------------------------------------------
    -- Damper
    --------------------------------------------------------

    slowBumpScale = 600.0,
    fastBumpScale = 1200.0,
    reboundScale  = 900.0,

    bumpThreshold = 0.15,

    --------------------------------------------------------
    -- ARB
    --------------------------------------------------------

    rollBarScale = 250.0,

    frontARB = 3000.0,
    rearARB  = 3000.0,

    arbTau = 0.080,

    --------------------------------------------------------
    -- Alignment
    --------------------------------------------------------

    camberScale = 80.0,
    toeScale    = 120.0,

    armFlexScale = 0.0008,
    bushTau      = 0.080,

    --------------------------------------------------------
    -- Caster
    --------------------------------------------------------

    casterAngle = 6.5,
    casterTrail = 0.035,
    casterScale = 1.2,
    casterTau   = 0.060,

    --------------------------------------------------------
    -- Spring
    --------------------------------------------------------

    springRate = {
        [0] = 35000.0,
        [1] = 35000.0,
        [2] = 45000.0,
        [3] = 45000.0,
    },

    springLimit = 8000.0,

    --------------------------------------------------------
    -- External coupling
    --------------------------------------------------------

    tireHopGain = 0.15,
    loadBiasGain = 120.0,
}

--============================================================
-- State
--============================================================

local prevSusp = {
    [0] = 0.0,
    [1] = 0.0,
    [2] = 0.0,
    [3] = 0.0,
}

local initialized = false

local arbState = {
    front = 0.0,
    rear  = 0.0,
}

local casterState = {
    force = 0.0,
}

M.debug = {
    suspTravel = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    suspSpeed = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    damperForce = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    force = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    springForce = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    camber = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    toe = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    caster = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    arbForce = {
        front = 0.0,
        rear  = 0.0,
    },

    casterTotal = 0.0,

    loadLinked = false,
    armLinked  = false,
}

--============================================================
-- Utility
--============================================================

local function clamp(v, minValue, maxValue)
    if v < minValue then
        return minValue
    end

    if v > maxValue then
        return maxValue
    end

    return v
end

local function safeNumber(value, defaultValue)
    return tonumber(value) or defaultValue
end

local function safeLoad(key, defaultValue)
    local value =
        ac.load(key)

    if value == nil then
        return defaultValue
    end

    return safeNumber(
        value,
        defaultValue
    )
end

local function safeStore(key, value)
    pcall(
        function()
            ac.store(
                key,
                value
            )
        end
    )
end

local function safeCall(func, defaultValue, ...)
    if type(func) ~= "function" then
        return defaultValue
    end

    local ok, result =
        pcall(
            func,
            ...
        )

    if not ok then
        return defaultValue
    end

    if result == nil then
        return defaultValue
    end

    return result
end

local function lowPass(current, target, tau, dt)
    return
        current
        +
        (
            target
            -
            current
        )
        *
        (
            dt
            /
            (
                tau
                +
                dt
            )
        )
end

--============================================================
-- Suspension travel input
--============================================================

local function readSuspensionTravel(car, index)
    local wheel =
        car
        and car.wheels
        and car.wheels[index]

    if wheel then
        local travel =
            wheel.suspensionTravel

        if type(travel) == "number" then
            return travel
        end

        local length =
            wheel.suspensionLength

        if type(length) == "number" then
            return length
        end
    end

    if physics and physics.getExtendedSuspensionTravel then
        local ok, value =
            pcall(
                function()
                    return physics.getExtendedSuspensionTravel(
                        0,
                        index
                    )
                end
            )

        if ok and type(value) == "number" then
            return value
        end
    end

    return prevSusp[index] or 0.0
end

local function initializeSuspension(car)
    for i = 0, 3 do
        prevSusp[i] =
            readSuspensionTravel(
                car,
                i
            )
    end

    initialized = true
end

--============================================================
-- External modules
--============================================================

local function getLoadState()
    if not okLT or not loadTransfer then
        return nil
    end

    return safeCall(
        loadTransfer.getState,
        nil
    )
end

local function getArmCamber(index)
    if not okAC or not armCompliance then
        return 0.0
    end

    return safeNumber(
        safeCall(
            armCompliance.getCamber,
            0.0,
            index
        ),
        0.0
    )
end

local function getArmToe(index)
    if not okAC or not armCompliance then
        return 0.0
    end

    return safeNumber(
        safeCall(
            armCompliance.getToe,
            0.0,
            index
        ),
        0.0
    )
end

--============================================================
-- Core force calculation
--============================================================

local function calculateDamperForce(speed)
    local absSpeed =
        math.abs(
            speed
        )

    local force = 0.0

    if absSpeed < M.params.minSuspSpeed then
        return 0.0
    end

    if speed > 0.0 then
        local bumpScale =
            absSpeed < M.params.bumpThreshold
            and M.params.slowBumpScale
            or M.params.fastBumpScale

        force =
            -speed
            *
            bumpScale
    else
        force =
            -speed
            *
            M.params.reboundScale
    end

    return force
end

local function calculateSpringForce(index, travel)
    local rate =
        M.params.springRate[index]
        or 35000.0

    local force =
        -travel
        *
        rate

    return clamp(
        force,
        -M.params.springLimit,
        M.params.springLimit
    )
end

local function applyTireHop(index, force)
    local hop =
        safeLoad(
            "ngp_tirehop_" .. index,
            0.0
        )

    return
        force
        +
        hop
        *
        M.params.tireHopGain
end

local function applyLoadBias(index, force, loadState)
    if not loadState then
        return force
    end

    local loadBias = 0.0

    if index >= 2 then
        loadBias =
            safeNumber(
                loadState.front,
                0.5
            )
            -
            0.5
    else
        loadBias =
            safeNumber(
                loadState.rear,
                0.5
            )
            -
            0.5
    end

    return
        force
        -
        loadBias
        *
        M.params.loadBiasGain
end

local function updateWheelForces(suspension, loadState, dt)
    local store = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    }

    for i = 0, 3 do
        local speed =
            (
                suspension[i]
                -
                prevSusp[i]
            )
            /
            dt

        local damperForce =
            calculateDamperForce(
                speed
            )

        local springForce =
            calculateSpringForce(
                i,
                suspension[i]
            )

        local force =
            damperForce
            +
            springForce

        force =
            applyTireHop(
                i,
                force
            )

        force =
            applyLoadBias(
                i,
                force,
                loadState
            )

        force =
            clamp(
                force,
                -M.params.maxForce,
                M.params.maxForce
            )

        M.debug.suspTravel[i] =
            suspension[i]

        M.debug.suspSpeed[i] =
            speed

        M.debug.damperForce[i] =
            damperForce

        M.debug.springForce[i] =
            springForce

        M.debug.force[i] =
            force

        store[i] =
            force

        prevSusp[i] =
            suspension[i]
    end

    return store
end

--============================================================
-- Anti-roll bar
--============================================================

local function applyAntiRollBar(suspension, store, dt)
    local frontTwist =
        suspension[0]
        -
        suspension[1]

    local rearTwist =
        suspension[2]
        -
        suspension[3]

    arbState.front =
        lowPass(
            arbState.front,
            frontTwist,
            M.params.arbTau,
            dt
        )

    arbState.rear =
        lowPass(
            arbState.rear,
            rearTwist,
            M.params.arbTau,
            dt
        )

    local rollFront =
        arbState.front
        *
        M.params.frontARB

    local rollRear =
        arbState.rear
        *
        M.params.rearARB

    M.debug.arbForce.front =
        rollFront

    M.debug.arbForce.rear =
        rollRear

    store[0] =
        store[0]
        -
        rollFront

    store[1] =
        store[1]
        +
        rollFront

    store[2] =
        store[2]
        -
        rollRear

    store[3] =
        store[3]
        +
        rollRear

    return rollFront, rollRear
end

--============================================================
-- Caster
--============================================================

local function updateCaster(car, dt)
    local steer =
        safeNumber(
            car.steer,
            0.0
        )

    local target =
        math.rad(
            M.params.casterAngle
        )
        *
        steer
        *
        M.params.casterTrail

    casterState.force =
        lowPass(
            casterState.force,
            target,
            M.params.casterTau,
            dt
        )

    M.debug.casterTotal =
        casterState.force
end

--============================================================
-- Alignment
--============================================================

local function updateAlignment(index, travel)
    local camber =
        -travel
        *
        0.01
        *
        M.params.camberScale
        +
        getArmCamber(
            index
        )

    local toe =
        travel
        *
        0.005
        *
        M.params.toeScale
        +
        getArmToe(
            index
        )

    local caster =
        index < 2
        and casterState.force
            *
            M.params.casterScale
        or 0.0

    M.debug.camber[index] =
        camber

    M.debug.toe[index] =
        toe

    M.debug.caster[index] =
        caster

    return camber, toe, caster
end

--============================================================
-- Export
--============================================================

local function exportWheel(index, force, camber, toe, caster)
    safeStore(
        "ngp_susp_" .. index,
        force
    )

    safeStore(
        "ngp_camber_" .. index,
        camber
    )

    safeStore(
        "ngp_toe_" .. index,
        toe
    )

    safeStore(
        "ngp_caster_" .. index,
        caster
    )
end

local function exportGlobal(rollFront, rollRear)
    safeStore(
        "ngp_roll_front",
        rollFront
    )

    safeStore(
        "ngp_roll_rear",
        rollRear
    )

    safeStore(
        "ngp_caster_total",
        M.debug.casterTotal
    )
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    local car =
        ac.getCar(0)

    if not car then
        return
    end

    if not initialized then
        initializeSuspension(
            car
        )

        return
    end

    --------------------------------------------------------
    -- Read suspension travel
    --------------------------------------------------------

    local suspension = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    }

    for i = 0, 3 do
        suspension[i] =
            readSuspensionTravel(
                car,
                i
            )
    end

    --------------------------------------------------------
    -- External state
    --------------------------------------------------------

    local loadState =
        getLoadState()

    M.debug.loadLinked =
        loadState ~= nil

    M.debug.armLinked =
        okAC
        and armCompliance ~= nil

    --------------------------------------------------------
    -- Wheel force
    --------------------------------------------------------

    local store =
        updateWheelForces(
            suspension,
            loadState,
            dt
        )

    --------------------------------------------------------
    -- ARB
    --------------------------------------------------------

    local rollFront,
          rollRear =
        applyAntiRollBar(
            suspension,
            store,
            dt
        )

    --------------------------------------------------------
    -- Caster / alignment
    --------------------------------------------------------

    updateCaster(
        car,
        dt
    )

    for i = 0, 3 do
        local camber,
              toe,
              caster =
            updateAlignment(
                i,
                suspension[i]
            )

        local finalForce =
            clamp(
                store[i],
                -M.params.maxForce,
                M.params.maxForce
            )

        M.debug.force[i] =
            finalForce

        exportWheel(
            i,
            finalForce,
            camber,
            toe,
            caster
        )
    end

    exportGlobal(
        rollFront,
        rollRear
    )
end

--============================================================
-- Public API
--============================================================

function M.getForce(index)
    return M.debug.force[index] or 0.0
end

function M.getTravel(index)
    return M.debug.suspTravel[index] or 0.0
end

function M.getSpeed(index)
    return M.debug.suspSpeed[index] or 0.0
end

function M.getCamber(index)
    return M.debug.camber[index] or 0.0
end

function M.getToe(index)
    return M.debug.toe[index] or 0.0
end

function M.getCaster(index)
    return M.debug.caster[index] or 0.0
end

function M.debugStr()
    return string.format(
        "Force FL:%+.0f FR:%+.0f RL:%+.0f RR:%+.0f\n" ..
        "ARB F:%+.0f R:%+.0f\n" ..
        "Camber %.3f %.3f %.3f %.3f\n" ..
        "Links LT:%s AC:%s",

        M.debug.force[0],
        M.debug.force[1],
        M.debug.force[2],
        M.debug.force[3],

        M.debug.arbForce.front,
        M.debug.arbForce.rear,

        M.debug.camber[0],
        M.debug.camber[1],
        M.debug.camber[2],
        M.debug.camber[3],

        M.debug.loadLinked and "OK" or "NIL",
        M.debug.armLinked and "OK" or "NIL"
    )
end

return M