---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- caster_effect.lua
-- Phase 4.85
-- Caster Geometry Grip Influence
-- キャスター角によるフロント接地補正モデル
--============================================================

local M = {}

--============================================================
-- Parameters
--============================================================

M.params = {
    casterAngle = 5.5,

    camberGain = 0.012,

    gripLossStart = 0.35,
    maxGripLoss   = 0.18,

    tau = 0.080,
}

--============================================================
-- State
--============================================================

local state = {
    grip = {
        [0] = 1.0,
        [1] = 1.0,
        [2] = 1.0,
        [3] = 1.0,
    },
}

M.debug = state

--============================================================
-- Utility
--============================================================

local function clamp(v, minValue, maxValue)
    if v < minValue then
        return minValue
    end

    if v > maxValue then
        return maxValue
    end

    return v
end

local function lowPass(current, target, alpha)
    return current + (target - current) * alpha
end

--============================================================
-- Core
--============================================================

local function calculateGripLoss(steerAbs)
    if steerAbs <= M.params.gripLossStart then
        return 0.0
    end

    local range =
        1.0
        -
        M.params.gripLossStart

    if range <= 0 then
        return M.params.maxGripLoss
    end

    local ratio =
        (
            steerAbs
            -
            M.params.gripLossStart
        )
        /
        range

    ratio =
        clamp(
            ratio,
            0.0,
            1.0
        )

    return
        ratio
        *
        M.params.maxGripLoss
end

local function calculateCasterCamberGain(steer, side)
    local casterRad =
        math.rad(
            M.params.casterAngle
        )

    local steerAmount = 0.0

    if side == "LEFT" then
        steerAmount =
            math.max(
                steer,
                0.0
            )

    elseif side == "RIGHT" then
        steerAmount =
            math.max(
                -steer,
                0.0
            )
    end

    return
        math.sin(casterRad)
        *
        steerAmount
        *
        M.params.camberGain
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    local car = ac.getCar(0)
    if not car then
        return
    end

    local steer =
        car.steer
        or 0.0

    local steerAbs =
        math.abs(
            steer
        )

    local gripLoss =
        calculateGripLoss(
            steerAbs
        )

    --------------------------------------------------------
    -- Front caster influence
    --------------------------------------------------------

    local camberGainFL =
        calculateCasterCamberGain(
            steer,
            "LEFT"
        )

    local camberGainFR =
        calculateCasterCamberGain(
            steer,
            "RIGHT"
        )

    local targetFL =
        1.0
        -
        gripLoss
        +
        camberGainFL

    local targetFR =
        1.0
        -
        gripLoss
        +
        camberGainFR

    targetFL =
        clamp(
            targetFL,
            0.70,
            1.05
        )

    targetFR =
        clamp(
            targetFR,
            0.70,
            1.05
        )

    --------------------------------------------------------
    -- Filter
    --------------------------------------------------------

    local alpha =
        dt /
        (
            M.params.tau
            +
            dt
        )

    state.grip[0] =
        lowPass(
            state.grip[0],
            targetFL,
            alpha
        )

    state.grip[1] =
        lowPass(
            state.grip[1],
            targetFR,
            alpha
        )

    --------------------------------------------------------
    -- Rear wheels are not affected by caster
    --------------------------------------------------------

    state.grip[2] = 1.0
    state.grip[3] = 1.0

    --------------------------------------------------------
    -- Export
    --------------------------------------------------------

    for i = 0, 3 do
        ac.store(
            "ngp_caster_grip_" .. i,
            state.grip[i]
        )
    end
end

--============================================================
-- Public API
--============================================================

function M.getGrip(i)
    return state.grip[i] or 1.0
end

function M.debugStr()
    return string.format(
        "CasterGrip FL %.3f FR %.3f RL %.3f RR %.3f",
        state.grip[0],
        state.grip[1],
        state.grip[2],
        state.grip[3]
    )
end

return M