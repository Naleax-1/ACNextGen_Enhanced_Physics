---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- brake_system.lua
-- Phase 10.1
-- Brake Thermal Core
-- ブレーキディスク温度モデル
--============================================================

local M = {}

--============================================================
-- Parameters
--============================================================

M.params = {
    ambient = 25.0,

    heatScale = 0.08,

    coolBase  = 0.015,
    coolSpeed = 0.002,

    maxTemp = 900.0,
}

--============================================================
-- State
--============================================================

local state = {
    discTemp = {
        [0] = 25.0,
        [1] = 25.0,
        [2] = 25.0,
        [3] = 25.0,
    },
}

M.debug = {
    brake = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    load = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    heat = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    cool = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    temp = state.discTemp,

    cooling = 0.0,
}

--============================================================
-- Utility
--============================================================

local function clamp(v, minValue, maxValue)
    if v < minValue then
        return minValue
    end

    if v > maxValue then
        return maxValue
    end

    return v
end

local function getWheelLoad(wheel)
    if not wheel then
        return 0.0
    end

    return tonumber(wheel.load) or 0.0
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    local car = ac.getCar(0)
    if not car or not car.wheels then
        return
    end

    local brake =
        car.brake
        or 0.0

    local speedKmh =
        car.speedKmh
        or 0.0

    local cooling =
        M.params.coolBase
        +
        speedKmh
        *
        M.params.coolSpeed

    M.debug.cooling =
        cooling

    for i = 0, 3 do
        local wheel =
            car.wheels[i]

        if wheel then
            local load =
                getWheelLoad(wheel)

            --------------------------------------------------
            -- Heat input
            --------------------------------------------------

            local heat =
                brake
                *
                load
                *
                M.params.heatScale
                *
                dt

            --------------------------------------------------
            -- Cooling
            --------------------------------------------------

            local cool =
                (
                    state.discTemp[i]
                    -
                    M.params.ambient
                )
                *
                cooling
                *
                dt

            --------------------------------------------------
            -- Integrate
            --------------------------------------------------

            state.discTemp[i] =
                state.discTemp[i]
                +
                heat
                -
                cool

            state.discTemp[i] =
                clamp(
                    state.discTemp[i],
                    M.params.ambient,
                    M.params.maxTemp
                )

            --------------------------------------------------
            -- Debug
            --------------------------------------------------

            M.debug.brake[i] =
                brake

            M.debug.load[i] =
                load

            M.debug.heat[i] =
                heat

            M.debug.cool[i] =
                cool

            --------------------------------------------------
            -- Export
            --------------------------------------------------

            ac.store(
                "ngp_brake_temp_" .. i,
                state.discTemp[i]
            )
        else
            M.debug.brake[i] = brake
            M.debug.load[i]  = 0.0
            M.debug.heat[i]  = 0.0
            M.debug.cool[i]  = 0.0

            ac.store(
                "ngp_brake_temp_" .. i,
                state.discTemp[i]
            )
        end
    end
end

--============================================================
-- Public API
--============================================================

function M.getTemp(i)
    return state.discTemp[i] or M.params.ambient
end

function M.debugStr()
    return string.format(
        "BrakeTemp FL %.1f FR %.1f RL %.1f RR %.1f\n" ..
        "Cooling %.3f",

        state.discTemp[0],
        state.discTemp[1],
        state.discTemp[2],
        state.discTemp[3],

        M.debug.cooling
    )
end

return M
