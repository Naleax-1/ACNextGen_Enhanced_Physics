---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- damage_event.lua
-- Phase 11.0
-- Impact Event Recorder
-- 衝撃イベント記録システム
--============================================================

local M = {}

--============================================================
-- Parameters
--============================================================

M.params = {
    gravity = 9.81,

    impactThreshold = 4.0,

    impactGain = 1.0,

    pitRepairSpeed = 5.0,
}

--============================================================
-- State
--============================================================

local state = {
    total = 0.0,

    lastImpact = 0.0,
    lastG      = 0.0,
    lastType   = "NONE",

    front = 0.0,
    rear  = 0.0,

    left  = 0.0,
    right = 0.0,

    repaired = 0,

    wasInPitRepair = false,
}

M.debug = {
    g = 0.0,

    impact = 0.0,

    type = "NONE",

    repaired = 0,
}

--============================================================
-- Utility
--============================================================

local function safeNumber(value, defaultValue)
    return tonumber(value) or defaultValue
end

local function getAccelerationG(car)
    local ax = 0.0
    local ay = 0.0
    local az = 0.0

    if car.acceleration then
        ax =
            safeNumber(
                car.acceleration.x,
                0.0
            )

        ay =
            safeNumber(
                car.acceleration.y,
                0.0
            )

        az =
            safeNumber(
                car.acceleration.z,
                0.0
            )
    end

    local lateralG =
        math.abs(
            ax / M.params.gravity
        )

    local longitudinalG =
        math.abs(
            ay / M.params.gravity
        )

    local verticalG =
        math.abs(
            az / M.params.gravity
        )

    return lateralG, longitudinalG, verticalG
end

local function getImpactType(lateralG, longitudinalG, verticalG)
    if verticalG >= lateralG
    and verticalG >= longitudinalG then
        return "VERTICAL"
    end

    if lateralG > longitudinalG then
        return "SIDE"
    end

    return "FRONT/REAR"
end

local function exportState()
    ac.store(
        "ngp_damage_event_total",
        state.total
    )

    ac.store(
        "ngp_damage_event_last",
        state.lastImpact
    )

    ac.store(
        "ngp_damage_event_g",
        state.lastG
    )

    ac.store(
        "ngp_damage_event_repaired",
        state.repaired
    )
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    local car =
        ac.getCar(0)

    if not car then
        return
    end

    --------------------------------------------------------
    -- Pit repair
    -- ピット停止中に毎フレームresetしないよう一度だけ発火
    --------------------------------------------------------

    local speedKmh =
        safeNumber(
            car.speedKmh,
            0.0
        )

    local inPit =
        car.isInPit
        or false

    local pitRepairActive =
        inPit
        and
        speedKmh < M.params.pitRepairSpeed

    if pitRepairActive
    and not state.wasInPitRepair then
        M.reset()
        state.wasInPitRepair = true
    end

    if not pitRepairActive then
        state.wasInPitRepair = false
    end

    --------------------------------------------------------
    -- G calculation
    --------------------------------------------------------

    local lateralG,
          longitudinalG,
          verticalG =
        getAccelerationG(
            car
        )

    local impactG =
        math.max(
            lateralG,
            longitudinalG,
            verticalG
        )

    M.debug.g =
        impactG

    state.lastG =
        impactG

    --------------------------------------------------------
    -- Event detection
    --------------------------------------------------------

    if impactG > M.params.impactThreshold then
        local strength =
            (
                impactG
                -
                M.params.impactThreshold
            )
            *
            dt
            *
            M.params.impactGain

        state.lastImpact =
            strength

        state.total =
            state.total
            +
            strength

        state.lastType =
            getImpactType(
                lateralG,
                longitudinalG,
                verticalG
            )

    else
        state.lastImpact = 0.0
    end

    --------------------------------------------------------
    -- Debug
    --------------------------------------------------------

    M.debug.impact =
        state.lastImpact

    M.debug.type =
        state.lastType

    M.debug.repaired =
        state.repaired

    --------------------------------------------------------
    -- Export
    --------------------------------------------------------

    exportState()
end

--============================================================
-- Public API
--============================================================

function M.reset()
    state.total = 0.0

    state.lastImpact = 0.0
    state.lastG      = 0.0
    state.lastType   = "NONE"

    state.front = 0.0
    state.rear  = 0.0

    state.left  = 0.0
    state.right = 0.0

    state.repaired =
        state.repaired
        +
        1

    M.debug.g = 0.0
    M.debug.impact = 0.0
    M.debug.type = "NONE"
    M.debug.repaired = state.repaired

    exportState()
end

function M.get()
    return state
end

function M.getTotal()
    return state.total
end

function M.getLastImpact()
    return state.lastImpact
end

function M.debugStr()
    return string.format(
        "Impact G %.2f\n" ..
        "Last %.4f Type %s\n" ..
        "Total %.4f\n" ..
        "Repaired %d",

        M.debug.g,

        M.debug.impact,
        M.debug.type,

        state.total,

        state.repaired
    )
end

return M
