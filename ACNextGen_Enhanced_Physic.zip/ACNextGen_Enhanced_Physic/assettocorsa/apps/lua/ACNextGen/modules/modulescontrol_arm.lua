---@diagnostic disable: undefined-global

-- modulescontrol_arm.lua
-- Phase 9.2
-- Virtual Control Arm + Bush Compliance


local M = {}


M.params = {

    frontTau = 0.070,
    rearTau  = 0.110,

    frontFlex = 0.35,
    rearFlex  = 0.55,

    maxDeflection = 0.25,

}



local state = {

    front = 0,
    rear  = 0,

}



M.debug = {

    rawYaw = 0,

    frontDef = 0,
    rearDef  = 0,

    total = 0,

}



function M.update(dt)

    if dt <= 0 then return end


    local car =
        ac.getCar(0)


    if not car then return end


    local av =
        car.localAngularVelocity


    if not av then return end


    local yaw =
        av.y


    local speed =
        (car.speedKmh or 0)
        /
        3.6


    local input =
        yaw * speed



    local af =
        dt /
        (
            M.params.frontTau
            +
            dt
        )


    local ar =
        dt /
        (
            M.params.rearTau
            +
            dt
        )



    state.front =
        state.front +
        (
            input
            -
            state.front
        )
        *
        af



    state.rear =
        state.rear +
        (
            state.front
            -
            state.rear
        )
        *
        ar



    state.front =
        math.max(
            -M.params.maxDeflection,
            math.min(
                M.params.maxDeflection,
                state.front
            )
        )


    state.rear =
        math.max(
            -M.params.maxDeflection,
            math.min(
                M.params.maxDeflection,
                state.rear
            )
        )



    M.debug.rawYaw =
        input


    M.debug.frontDef =
        state.front
        *
        M.params.frontFlex


    M.debug.rearDef =
        state.rear
        *
        M.params.rearFlex


    M.debug.total =
        M.debug.frontDef
        +
        M.debug.rearDef



    ac.store(
        "ngp_arm_front",
        M.debug.frontDef
    )


    ac.store(
        "ngp_arm_rear",
        M.debug.rearDef
    )

end



function M.debugStr()

return string.format(

"Arm Front %.4f\nArm Rear %.4f\nTotal %.4f",

M.debug.frontDef,

M.debug.rearDef,

M.debug.total

)

end



return M