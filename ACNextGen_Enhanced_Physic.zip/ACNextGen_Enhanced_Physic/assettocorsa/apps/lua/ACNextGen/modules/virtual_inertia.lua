---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- virtual_inertia.lua
-- Phase 7.3
-- Vehicle Rotational Inertia + Couplings
-- 仮想回転慣性 / 車体姿勢連成モデル
--============================================================

local M = {}

--============================================================
-- Dependencies
--============================================================

local okLT, loadTransfer =
    pcall(
        require,
        "modules/load_transfer"
    )

--============================================================
-- Parameters
--============================================================

M.params = {
    --------------------------------------------------------
    -- Base inertia response
    --------------------------------------------------------

    yawTau   = 0.100,
    pitchTau = 0.060,
    rollTau  = 0.050,

    --------------------------------------------------------
    -- Rear yaw lag
    --------------------------------------------------------

    rearTau  = 0.180,
    rearGain = 0.75,

    --------------------------------------------------------
    -- Couplings
    --------------------------------------------------------

    loadYawGain = 0.50,
    bodyYawGain = 0.40,

    frontYawDamp = 0.80,

    --------------------------------------------------------
    -- Output gain
    --------------------------------------------------------

    yawGain   = 1.0,
    pitchGain = 1.0,
    rollGain  = 1.0,

    --------------------------------------------------------
    -- Dynamic CG coupling
    --------------------------------------------------------

    pitchCGYawGain   = 1.20,
    rollCGYawGain    = 0.80,

    pitchCGPitchGain = 1.00,
    rollCGRollGain   = 1.00,

    --------------------------------------------------------
    -- Chassis energy coupling
    --------------------------------------------------------

    energyPitchGain  = 0.08,
    releasePitchGain = 0.12,

    energyRollGain   = 0.12,
    releaseRollGain  = 0.18,

    --------------------------------------------------------
    -- Limits
    --------------------------------------------------------

    maxInertiaShift = 0.35,

    neutralYawThreshold   = 0.05,
    neutralPitchThreshold = 0.03,
    neutralRollThreshold  = 0.03,

    instabilityLimit = 0.80,
}

--============================================================
-- State
--============================================================

local state = {
    yaw   = 0.0,
    pitch = 0.0,
    roll  = 0.0,

    rearYaw = 0.0,

    loadYaw = 0.0,
    bodyYaw = 0.0,

    finalYaw   = 0.0,
    finalPitch = 0.0,
    finalRoll  = 0.0,
}

M.state = {
    yawState   = "NEUTRAL",
    pitchState = "NEUTRAL",
    rollState  = "NEUTRAL",

    transition = "STABLE",
}

M.debug = {
    rawYaw   = 0.0,
    rawPitch = 0.0,
    rawRoll  = 0.0,

    filtYaw   = 0.0,
    filtPitch = 0.0,
    filtRoll  = 0.0,

    rearYaw = 0.0,
    loadYaw = 0.0,
    bodyYaw = 0.0,

    instability = 0.0,

    pitchCG = 0.0,
    rollCG  = 0.0,

    yawInertiaScale   = 1.0,
    pitchInertiaScale = 1.0,
    rollInertiaScale  = 1.0,

    chassisEnergy  = 0.0,
    chassisRelease = 0.0,

    frontBias = 0.5,
    rearBias  = 0.5,

    loadLinked = false,
}

--============================================================
-- Utility
--============================================================

local function clamp(v, minValue, maxValue)
    if v < minValue then
        return minValue
    end

    if v > maxValue then
        return maxValue
    end

    return v
end

local function safeNumber(value, defaultValue)
    return tonumber(value) or defaultValue
end

local function safeLoad(key, defaultValue)
    local value =
        ac.load(key)

    if value == nil then
        return defaultValue
    end

    return safeNumber(
        value,
        defaultValue
    )
end

local function safeStore(key, value)
    pcall(
        function()
            ac.store(
                key,
                value
            )
        end
    )
end

local function safeCall(func, defaultValue, ...)
    if type(func) ~= "function" then
        return defaultValue
    end

    local ok, result =
        pcall(
            func,
            ...
        )

    if not ok or result == nil then
        return defaultValue
    end

    return result
end

local function lowPass(current, target, tau, dt)
    return
        current
        +
        (
            target
            -
            current
        )
        *
        (
            dt
            /
            (
                tau
                +
                dt
            )
        )
end

--============================================================
-- External input
--============================================================

local function getLoadState()
    if not okLT or not loadTransfer then
        return nil
    end

    return safeCall(
        loadTransfer.getState,
        nil
    )
end

local function readAngularVelocity(car)
    local av =
        car.localAngularVelocity

    if not av then
        return 0.0, 0.0, 0.0
    end

    --------------------------------------------------------
    -- AC側軸:
    -- 元コードを維持
    -- yaw   = av.y
    -- pitch = av.x
    -- roll  = av.z
    --------------------------------------------------------

    local rawYaw =
        safeNumber(
            av.y,
            0.0
        )

    local rawPitch =
        safeNumber(
            av.x,
            0.0
        )

    local rawRoll =
        safeNumber(
            av.z,
            0.0
        )

    return rawYaw, rawPitch, rawRoll
end

--============================================================
-- Inertia scale
--============================================================

local function calculateInertiaScales()
    local p =
        M.params

    local pitchCG =
        safeLoad(
            "ngp_pitch_cg",
            0.0
        )

    local rollCG =
        safeLoad(
            "ngp_roll_cg",
            0.0
        )

    local frontBias =
        safeLoad(
            "ngp_front_bias",
            0.50
        )

    local rearBias =
        safeLoad(
            "ngp_rear_bias",
            0.50
        )

    local yawScale =
        1.0
        +
        math.abs(
            pitchCG
        )
        *
        p.pitchCGYawGain
        +
        math.abs(
            rollCG
        )
        *
        p.rollCGYawGain
        +
        (
            frontBias
            -
            rearBias
        )
        *
        0.25

    local pitchScale =
        1.0
        +
        math.abs(
            pitchCG
        )
        *
        p.pitchCGPitchGain

    local rollScale =
        1.0
        +
        math.abs(
            rollCG
        )
        *
        p.rollCGRollGain

    yawScale =
        clamp(
            yawScale,
            1.0 - p.maxInertiaShift,
            1.0 + p.maxInertiaShift
        )

    pitchScale =
        clamp(
            pitchScale,
            1.0 - p.maxInertiaShift,
            1.0 + p.maxInertiaShift
        )

    rollScale =
        clamp(
            rollScale,
            1.0 - p.maxInertiaShift,
            1.0 + p.maxInertiaShift
        )

    M.debug.pitchCG =
        pitchCG

    M.debug.rollCG =
        rollCG

    M.debug.frontBias =
        frontBias

    M.debug.rearBias =
        rearBias

    M.debug.yawInertiaScale =
        yawScale

    M.debug.pitchInertiaScale =
        pitchScale

    M.debug.rollInertiaScale =
        rollScale

    return yawScale, pitchScale, rollScale
end

--============================================================
-- Core inertia update
--============================================================

local function updateFilteredAngularVelocity(
    rawYaw,
    rawPitch,
    rawRoll,
    yawScale,
    pitchScale,
    rollScale,
    dt
)
    local p =
        M.params

    state.yaw =
        lowPass(
            state.yaw,
            rawYaw,
            p.yawTau * yawScale,
            dt
        )

    state.pitch =
        lowPass(
            state.pitch,
            rawPitch,
            p.pitchTau * pitchScale,
            dt
        )

    state.roll =
        lowPass(
            state.roll,
            rawRoll,
            p.rollTau * rollScale,
            dt
        )
end

local function applyChassisEnergy()
    local energy =
        safeLoad(
            "ngp_chassis_energy",
            0.0
        )

    local release =
        safeLoad(
            "ngp_chassis_release",
            0.0
        )

    state.pitch =
        state.pitch
        +
        energy
        *
        M.params.energyPitchGain
        -
        release
        *
        M.params.releasePitchGain

    state.roll =
        state.roll
        +
        energy
        *
        M.params.energyRollGain
        -
        release
        *
        M.params.releaseRollGain

    M.debug.chassisEnergy =
        energy

    M.debug.chassisRelease =
        release
end

local function updateRearYaw(dt)
    state.rearYaw =
        lowPass(
            state.rearYaw,
            state.yaw,
            M.params.rearTau,
            dt
        )
end

local function updateLoadYaw()
    state.loadYaw = 0.0

    local loadState =
        getLoadState()

    M.debug.loadLinked =
        loadState ~= nil

    if not loadState then
        return
    end

    local left =
        safeNumber(
            loadState.left,
            0.5
        )

    local right =
        safeNumber(
            loadState.right,
            0.5
        )

    state.loadYaw =
        (
            left
            -
            right
        )
        *
        M.params.loadYawGain
end

local function updateBodyYaw()
    state.bodyYaw =
        safeLoad(
            "ngp_body_steer",
            0.0
        )
        *
        M.params.bodyYawGain
end

local function calculateFinalOutputs()
    local p =
        M.params

    state.finalYaw =
        state.yaw
        *
        p.yawGain
        +
        state.rearYaw
        *
        p.rearGain
        +
        state.loadYaw
        +
        state.bodyYaw

    state.finalPitch =
        state.pitch
        *
        p.pitchGain

    state.finalRoll =
        state.roll
        *
        p.rollGain
end

local function calculateInstability()
    return
        math.abs(
            state.finalYaw
        )
        +
        math.abs(
            state.finalRoll
        )
        *
        0.5
end

--============================================================
-- State names
--============================================================

local function updateStateNames()
    if math.abs(state.finalYaw) < M.params.neutralYawThreshold then
        M.state.yawState = "NEUTRAL"

    elseif state.finalYaw > 0.0 then
        M.state.yawState = "YAW RIGHT"

    else
        M.state.yawState = "YAW LEFT"
    end

    if math.abs(state.finalPitch) < M.params.neutralPitchThreshold then
        M.state.pitchState = "NEUTRAL"

    elseif state.finalPitch > 0.0 then
        M.state.pitchState = "PITCH UP"

    else
        M.state.pitchState = "PITCH DOWN"
    end

    if math.abs(state.finalRoll) < M.params.neutralRollThreshold then
        M.state.rollState = "NEUTRAL"

    elseif state.finalRoll > 0.0 then
        M.state.rollState = "ROLL RIGHT"

    else
        M.state.rollState = "ROLL LEFT"
    end

    if M.debug.instability > M.params.instabilityLimit then
        M.state.transition = "LIMIT"
    else
        M.state.transition = "STABLE"
    end
end

--============================================================
-- Debug / Export
--============================================================

local function updateDebug(rawYaw, rawPitch, rawRoll)
    M.debug.rawYaw =
        rawYaw

    M.debug.rawPitch =
        rawPitch

    M.debug.rawRoll =
        rawRoll

    M.debug.filtYaw =
        state.yaw

    M.debug.filtPitch =
        state.pitch

    M.debug.filtRoll =
        state.roll

    M.debug.rearYaw =
        state.rearYaw

    M.debug.loadYaw =
        state.loadYaw

    M.debug.bodyYaw =
        state.bodyYaw

    M.debug.instability =
        calculateInstability()
end

local function exportState()
    safeStore(
        "ngp_inertia_yaw",
        state.finalYaw
    )

    safeStore(
        "ngp_inertia_pitch",
        state.finalPitch
    )

    safeStore(
        "ngp_inertia_roll",
        state.finalRoll
    )

    safeStore(
        "ngp_instability",
        M.debug.instability
    )

    safeStore(
        "ngp_inertia_rear_yaw",
        state.rearYaw
    )

    safeStore(
        "ngp_inertia_load_yaw",
        state.loadYaw
    )

    safeStore(
        "ngp_inertia_body_yaw",
        state.bodyYaw
    )

    safeStore(
        "ngp_yaw_inertia_scale",
        M.debug.yawInertiaScale
    )

    safeStore(
        "ngp_pitch_inertia_scale",
        M.debug.pitchInertiaScale
    )

    safeStore(
        "ngp_roll_inertia_scale",
        M.debug.rollInertiaScale
    )
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    local car =
        ac.getCar(0)

    if not car or not car.localAngularVelocity then
        return
    end

    --------------------------------------------------------
    -- Raw angular velocity
    --------------------------------------------------------

    local rawYaw,
          rawPitch,
          rawRoll =
        readAngularVelocity(
            car
        )

    --------------------------------------------------------
    -- Dynamic inertia scale
    --------------------------------------------------------

    local yawScale,
          pitchScale,
          rollScale =
        calculateInertiaScales()

    --------------------------------------------------------
    -- Main filters
    --------------------------------------------------------

    updateFilteredAngularVelocity(
        rawYaw,
        rawPitch,
        rawRoll,
        yawScale,
        pitchScale,
        rollScale,
        dt
    )

    --------------------------------------------------------
    -- Couplings
    --------------------------------------------------------

    applyChassisEnergy()

    updateRearYaw(
        dt
    )

    updateLoadYaw()

    updateBodyYaw()

    --------------------------------------------------------
    -- Output
    --------------------------------------------------------

    calculateFinalOutputs()

    updateDebug(
        rawYaw,
        rawPitch,
        rawRoll
    )

    updateStateNames()

    exportState()
end

--============================================================
-- Public API
--============================================================

function M.getState()
    return M.state
end

function M.getYaw()
    return state.finalYaw
end

function M.getPitch()
    return state.finalPitch
end

function M.getRoll()
    return state.finalRoll
end

function M.getInstability()
    return M.debug.instability
end

function M.debugStr()
    return string.format(
        "Yaw %.3f Rear %.3f Load %.3f Body %.3f\n" ..
        "Pitch %.3f Roll %.3f\n" ..
        "Scale Y %.2f P %.2f R %.2f\n" ..
        "%s %s",

        M.debug.filtYaw,
        M.debug.rearYaw,
        M.debug.loadYaw,
        M.debug.bodyYaw,

        M.debug.filtPitch,
        M.debug.filtRoll,

        M.debug.yawInertiaScale,
        M.debug.pitchInertiaScale,
        M.debug.rollInertiaScale,

        M.state.transition,
        M.debug.loadLinked and "LT:OK" or "LT:NIL"
    )
end

return M
