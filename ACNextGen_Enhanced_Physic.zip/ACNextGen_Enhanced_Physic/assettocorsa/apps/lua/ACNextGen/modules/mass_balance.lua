---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- mass_balance.lua
-- Phase 7
-- Mass & Inertia Correction
-- ac.setExtraMass() による重心・慣性補正
--============================================================

local M = {}

--============================================================
-- Constants
--============================================================

local BASE_MASS = 1310.0

--============================================================
-- Parameters
--============================================================

M.params = {
    --------------------------------------------------------
    -- Mass bias
    --------------------------------------------------------

    rearBias = 30.0,
    frontBias = -10.0,

    --------------------------------------------------------
    -- Yaw inertia
    --------------------------------------------------------

    yawInertia = 20.0,

    --------------------------------------------------------
    -- Extra mass positions
    -- nil の場合は init() で生成
    --------------------------------------------------------

    rearPos  = nil,
    frontPos = nil,

    leftPos  = nil,
    rightPos = nil,

    massBox = nil,
}

--============================================================
-- State
--============================================================

local initialized = false

local state = {
    applied = false,

    rearApplied  = false,
    frontApplied = false,
    yawApplied   = false,
}

M.debug = {
    totalAdded = 0.0,

    rearBias = 0.0,
    frontBias = 0.0,

    yawInertia = 0.0,

    applied = false,
}

--============================================================
-- Utility
--============================================================

local function makeVec3(x, y, z)
    if type(vec3) == "function" then
        return vec3(
            x,
            y,
            z
        )
    end

    return {
        x = x,
        y = y,
        z = z,
    }
end

local function safeNumber(value, defaultValue)
    return tonumber(value) or defaultValue
end

local function safeSetExtraMass(position, mass, box)
    if not ac or not ac.setExtraMass then
        return false
    end

    local ok =
        pcall(
            function()
                ac.setExtraMass(
                    position,
                    mass,
                    box
                )
            end
        )

    return ok
end

local function safeLog(message)
    pcall(
        function()
            if ac and ac.log then
                ac.log(message)
            end
        end
    )
end

--============================================================
-- Setup
--============================================================

local function ensureDefaultPositions()
    local p =
        M.params

    p.rearPos =
        p.rearPos
        or makeVec3(
            0.0,
            -0.3,
            -1.4
        )

    p.frontPos =
        p.frontPos
        or makeVec3(
            0.0,
            -0.3,
            1.4
        )

    p.leftPos =
        p.leftPos
        or makeVec3(
            0.9,
            -0.1,
            0.0
        )

    p.rightPos =
        p.rightPos
        or makeVec3(
            -0.9,
            -0.1,
            0.0
        )

    p.massBox =
        p.massBox
        or makeVec3(
            0.3,
            0.3,
            0.3
        )
end

local function updateDebug()
    local p =
        M.params

    M.debug.totalAdded =
        safeNumber(
            p.rearBias,
            0.0
        )
        +
        safeNumber(
            p.frontBias,
            0.0
        )
        +
        safeNumber(
            p.yawInertia,
            0.0
        )
        *
        2.0

    M.debug.rearBias =
        safeNumber(
            p.rearBias,
            0.0
        )

    M.debug.frontBias =
        safeNumber(
            p.frontBias,
            0.0
        )

    M.debug.yawInertia =
        safeNumber(
            p.yawInertia,
            0.0
        )

    M.debug.applied =
        state.applied
end

--============================================================
-- Public Init
--============================================================

function M.init()
    if initialized then
        return
    end

    ensureDefaultPositions()

    local p =
        M.params

    --------------------------------------------------------
    -- Rear mass bias
    --------------------------------------------------------

    if p.rearBias ~= 0 then
        state.rearApplied =
            safeSetExtraMass(
                p.rearPos,
                p.rearBias,
                p.massBox
            )
    end

    --------------------------------------------------------
    -- Front mass bias
    --------------------------------------------------------

    if p.frontBias ~= 0 then
        state.frontApplied =
            safeSetExtraMass(
                p.frontPos,
                p.frontBias,
                p.massBox
            )
    end

    --------------------------------------------------------
    -- Yaw inertia mass
    --------------------------------------------------------

    if p.yawInertia ~= 0 then
        local okLeft =
            safeSetExtraMass(
                p.leftPos,
                p.yawInertia,
                p.massBox
            )

        local okRight =
            safeSetExtraMass(
                p.rightPos,
                p.yawInertia,
                p.massBox
            )

        state.yawApplied =
            okLeft
            and
            okRight
    end

    state.applied =
        state.rearApplied
        or
        state.frontApplied
        or
        state.yawApplied

    initialized =
        true

    updateDebug()

    safeLog(
        string.format(
            "[NGP Mass] Extra mass configured Rear:%+.0fkg Front:%+.0fkg Yaw:%+.0fkgx2 Applied:%s",
            M.debug.rearBias,
            M.debug.frontBias,
            M.debug.yawInertia,
            tostring(
                state.applied
            )
        )
    )
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if not initialized then
        M.init()
    end
end

--============================================================
-- Public API
--============================================================

function M.isApplied()
    return state.applied
end

function M.debugStr()
    local car =
        ac.getCar(0)

    local baseMass =
        car
        and
        safeNumber(
            car.mass,
            BASE_MASS
        )
        or
        BASE_MASS

    return string.format(
        "BaseMass:%.0f\n" ..
        "Added:%.0fkg Rear:%+.0f Front:%+.0f\n" ..
        "Yaw:%+.0fx2 Applied:%s",

        baseMass,

        M.debug.totalAdded,
        M.debug.rearBias,
        M.debug.frontBias,

        M.debug.yawInertia,
        M.debug.applied and "YES" or "NO"
    )
end

return M
