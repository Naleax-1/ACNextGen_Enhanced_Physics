---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- thermal.lua
-- Phase 5.1
-- Hub / Diff / Gearbox Thermal Simulation
-- ハブ・デフ・ギアボックス熱モデル
--============================================================

local M = {}

--============================================================
-- Parameters
--============================================================

M.params = {
    --------------------------------------------------------
    -- Hub thermal coupling
    --------------------------------------------------------

    brakeToHub = 0.15,
    tyreToHub  = 0.05,

    hubCoolBase  = 0.020,
    hubCoolSpeed = 0.004,

    --------------------------------------------------------
    -- Diff thermal model
    --------------------------------------------------------

    diffHeatScale = 8.0,

    diffLSDHeatGain = 0.06,

    diffCoolBase  = 0.015,
    diffCoolSpeed = 0.003,

    --------------------------------------------------------
    -- Gearbox thermal model
    --------------------------------------------------------

    gearboxHeatScale = 0.80,

    drivetrainHeatGain = 1.0,

    gearboxCoolBase  = 0.010,
    gearboxCoolSpeed = 0.002,

    --------------------------------------------------------
    -- General
    --------------------------------------------------------

    ambientTemp = 25.0,

    rubberMemoryTempGain = 6.0,

    maxTemp = 1600.0,
}

--============================================================
-- State
--============================================================

local state = {
    hubTemp = {
        [0] = 25.0,
        [1] = 25.0,
        [2] = 25.0,
        [3] = 25.0,
    },

    diffTemp = 25.0,

    gearboxTemp = 25.0,

    prevGear = 0,
}

M.debug = {
    hubTemp = state.hubTemp,

    brakeTemp = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    tyreTemp = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    diffTemp = 25.0,
    gearboxTemp = 25.0,

    diffHeat = 0.0,
    gearboxHeat = 0.0,

    speed = 0.0,
}

--============================================================
-- Utility
--============================================================

local function clamp(v, minValue, maxValue)
    if v < minValue then
        return minValue
    end

    if v > maxValue then
        return maxValue
    end

    return v
end

local function safeNumber(value, defaultValue)
    return tonumber(value) or defaultValue
end

local function safeLoad(key, defaultValue)
    local value =
        ac.load(key)

    if value == nil then
        return defaultValue
    end

    return safeNumber(
        value,
        defaultValue
    )
end

local function safeStore(key, value)
    pcall(
        function()
            ac.store(
                key,
                value
            )
        end
    )
end

local function approachThermal(currentTemp, heatInput, coolRate, ambient, dt)
    local nextTemp =
        currentTemp
        +
        heatInput
        *
        dt
        -
        (
            currentTemp
            -
            ambient
        )
        *
        coolRate
        *
        dt

    nextTemp =
        math.max(
            ambient,
            nextTemp
        )

    return clamp(
        nextTemp,
        ambient,
        M.params.maxTemp
    )
end

--============================================================
-- Wheel / hub thermal
--============================================================

local function readBrakeTemperature(wheel, index, ambient)
    local wheelTemp =
        wheel
        and safeNumber(
            wheel.brakeTemperature,
            nil
        )
        or nil

    if wheelTemp ~= nil then
        return wheelTemp
    end

    return safeLoad(
        "ngp_brake_temp_" .. index,
        ambient
    )
end

local function readTyreTemperature(wheel, index, ambient)
    local wheelTemp =
        wheel
        and safeNumber(
            wheel.tyreCoreTemperature,
            nil
        )
        or nil

    if wheelTemp ~= nil then
        return wheelTemp
    end

    return safeLoad(
        "ngp_tyre_temp_" .. index,
        ambient
    )
end

local function updateHubTemperature(car, index, speedKmh, ambient, dt)
    local wheel =
        car.wheels
        and car.wheels[index]
        or nil

    if not wheel then
        return
    end

    local brakeTemp =
        readBrakeTemperature(
            wheel,
            index,
            ambient
        )

    local tyreTemp =
        readTyreTemperature(
            wheel,
            index,
            ambient
        )

    local rubberMemory =
        safeLoad(
            "ngp_rubber_memory_" .. index,
            0.0
        )

    tyreTemp =
        tyreTemp
        +
        rubberMemory
        *
        M.params.rubberMemoryTempGain

    local hubCool =
        M.params.hubCoolBase
        +
        speedKmh
        *
        M.params.hubCoolSpeed

    local hubHeat =
        (
            brakeTemp
            -
            state.hubTemp[index]
        )
        *
        M.params.brakeToHub
        +
        (
            tyreTemp
            -
            state.hubTemp[index]
        )
        *
        M.params.tyreToHub

    state.hubTemp[index] =
        approachThermal(
            state.hubTemp[index],
            hubHeat,
            hubCool,
            ambient,
            dt
        )

    M.debug.brakeTemp[index] =
        brakeTemp

    M.debug.tyreTemp[index] =
        tyreTemp

    safeStore(
        "ngp_hub_temp_" .. index,
        state.hubTemp[index]
    )

    safeStore(
        "ngp_tyre_temp_" .. index,
        tyreTemp
    )
end

--============================================================
-- Diff thermal
--============================================================

local function readRearWheelDiff(car)
    local rearLeft =
        car.wheels
        and car.wheels[2]
        or nil

    local rearRight =
        car.wheels
        and car.wheels[3]
        or nil

    local omegaL =
        rearLeft
        and safeNumber(
            rearLeft.angularSpeed,
            0.0
        )
        or 0.0

    local omegaR =
        rearRight
        and safeNumber(
            rearRight.angularSpeed,
            0.0
        )
        or 0.0

    return math.abs(
        omegaL
        -
        omegaR
    )
end

local function updateDiffTemperature(car, speedKmh, ambient, dt)
    local wheelDiff =
        readRearWheelDiff(
            car
        )

    local lsdDiff =
        safeLoad(
            "ngp_lsd_diff",
            wheelDiff
        )

    local lsdHeat =
        safeLoad(
            "ngp_lsd_heat",
            0.0
        )

    local diffHeat =
        math.max(
            wheelDiff,
            lsdDiff
        )
        *
        M.params.diffHeatScale
        +
        lsdHeat
        *
        M.params.diffLSDHeatGain

    local diffCool =
        M.params.diffCoolBase
        +
        speedKmh
        *
        M.params.diffCoolSpeed

    state.diffTemp =
        approachThermal(
            state.diffTemp,
            diffHeat,
            diffCool,
            ambient,
            dt
        )

    M.debug.diffHeat =
        diffHeat

    M.debug.diffTemp =
        state.diffTemp

    safeStore(
        "ngp_diff_temp",
        state.diffTemp
    )
end

--============================================================
-- Gearbox thermal
--============================================================

local function updateGearboxTemperature(car, speedKmh, ambient, dt)
    local rpm =
        safeNumber(
            car.rpm,
            0.0
        )

    local gas =
        safeNumber(
            car.gas,
            0.0
        )

    local gear =
        safeNumber(
            car.gear,
            0.0
        )

    local rpmRatio =
        clamp(
            rpm / 8000.0,
            0.0,
            1.0
        )

    local gearLoad =
        gas
        *
        math.max(
            math.abs(
                gear
            ),
            1.0
        )
        *
        0.15

    local drivetrainHeat =
        safeLoad(
            "ngp_gearbox_heat",
            20.0
        )
        /
        120.0

    local gearboxHeat =
        (
            rpmRatio
            +
            gearLoad
            +
            drivetrainHeat
            *
            M.params.drivetrainHeatGain
        )
        *
        M.params.gearboxHeatScale

    local gearboxCool =
        M.params.gearboxCoolBase
        +
        speedKmh
        *
        M.params.gearboxCoolSpeed

    state.gearboxTemp =
        approachThermal(
            state.gearboxTemp,
            gearboxHeat,
            gearboxCool,
            ambient,
            dt
        )

    M.debug.gearboxHeat =
        gearboxHeat

    M.debug.gearboxTemp =
        state.gearboxTemp

    safeStore(
        "ngp_gearbox_temp",
        state.gearboxTemp
    )
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    local car =
        ac.getCar(0)

    if not car or not car.wheels then
        return
    end

    local ambient =
        M.params.ambientTemp

    local speedKmh =
        safeNumber(
            car.speedKmh,
            0.0
        )

    M.debug.speed =
        speedKmh

    --------------------------------------------------------
    -- Hub
    --------------------------------------------------------

    for i = 0, 3 do
        updateHubTemperature(
            car,
            i,
            speedKmh,
            ambient,
            dt
        )
    end

    --------------------------------------------------------
    -- Diff
    --------------------------------------------------------

    updateDiffTemperature(
        car,
        speedKmh,
        ambient,
        dt
    )

    --------------------------------------------------------
    -- Gearbox
    --------------------------------------------------------

    updateGearboxTemperature(
        car,
        speedKmh,
        ambient,
        dt
    )
end

--============================================================
-- Public API
--============================================================

function M.getHubTemp(index)
    return state.hubTemp[index] or M.params.ambientTemp
end

function M.getDiffTemp()
    return state.diffTemp
end

function M.getGearboxTemp()
    return state.gearboxTemp
end

function M.debugStr()
    return string.format(
        "Hub %.1f %.1f %.1f %.1f\n" ..
        "Diff %.1f Gearbox %.1f\n" ..
        "Heat D %.2f G %.2f",

        state.hubTemp[0],
        state.hubTemp[1],
        state.hubTemp[2],
        state.hubTemp[3],

        state.diffTemp,
        state.gearboxTemp,

        M.debug.diffHeat,
        M.debug.gearboxHeat
    )
end

return M
