---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- impact_sensor.lua
-- Phase 11.1
-- Impact Sensor
-- G衝撃検出 → damage_stateへ送信
--============================================================

local M = {}

--============================================================
-- Parameters
--============================================================

M.params = {
    gravity = 9.81,

    impactThreshold = 3.0,

    impactGain = 0.05,

    verticalWeight     = 1.00,
    lateralWeight      = 0.70,
    longitudinalWeight = 0.50,

    wheelDamageLoadThreshold = 1000.0,
    wheelDamageScale = 0.50,
}

--============================================================
-- Dependencies
--============================================================

local okDamage, damage =
    pcall(
        require,
        "modules/damage_state"
    )

--============================================================
-- Debug
--============================================================

M.debug = {
    g = 0.0,

    verticalG     = 0.0,
    lateralG      = 0.0,
    longitudinalG = 0.0,

    impact = 0.0,

    type = "NONE",

    damageLinked = okDamage,
}

--============================================================
-- Utility
--============================================================

local function safeNumber(value, defaultValue)
    return tonumber(value) or defaultValue
end

local function safeCall(fn, ...)
    if type(fn) ~= "function" then
        return false
    end

    local ok =
        pcall(
            fn,
            ...
        )

    return ok
end

local function getAcceleration(car)
    local ax = 0.0
    local ay = 0.0
    local az = 0.0

    if car.acceleration then
        ax =
            safeNumber(
                car.acceleration.x,
                0.0
            )

        ay =
            safeNumber(
                car.acceleration.y,
                0.0
            )

        az =
            safeNumber(
                car.acceleration.z,
                0.0
            )
    end

    return ax, ay, az
end

--============================================================
-- Core
--============================================================

local function calculateImpact(ax, ay, az)
    local p =
        M.params

    local verticalG =
        math.abs(
            az / p.gravity
        )

    local lateralG =
        math.abs(
            ax / p.gravity
        )

    local longitudinalG =
        math.abs(
            ay / p.gravity
        )

    --------------------------------------------------------
    -- Impact priority
    -- 着地 > 横衝撃 > 縦衝撃
    --------------------------------------------------------

    local weightedVertical =
        verticalG
        *
        p.verticalWeight

    local weightedLateral =
        lateralG
        *
        p.lateralWeight

    local weightedLongitudinal =
        longitudinalG
        *
        p.longitudinalWeight

    local impactG =
        math.max(
            weightedVertical,
            weightedLateral,
            weightedLongitudinal
        )

    local impactType =
        "NONE"

    if impactG == weightedVertical and impactG > p.impactThreshold then
        impactType = "VERTICAL"

    elseif impactG == weightedLateral and impactG > p.impactThreshold then
        impactType = "LATERAL"

    elseif impactG == weightedLongitudinal and impactG > p.impactThreshold then
        impactType = "LONGITUDINAL"
    end

    local impact = 0.0

    if impactG > p.impactThreshold then
        impact =
            (
                impactG
                -
                p.impactThreshold
            )
            *
            p.impactGain
    end

    return
        impact,
        impactG,
        verticalG,
        lateralG,
        longitudinalG,
        impactType
end

local function applyDamage(car, impact)
    if impact <= 0 then
        return
    end

    if not okDamage or not damage then
        return
    end

    --------------------------------------------------------
    -- Chassis damage
    --------------------------------------------------------

    safeCall(
        damage.damageChassis,
        impact
    )

    --------------------------------------------------------
    -- Wheel damage
    --------------------------------------------------------

    if not car.wheels then
        return
    end

    for i = 0, 3 do
        local wheel =
            car.wheels[i]

        if wheel then
            local load =
                safeNumber(
                    wheel.load,
                    0.0
                )

            if load > M.params.wheelDamageLoadThreshold then
                safeCall(
                    damage.damageWheel,
                    i,
                    impact
                    *
                    M.params.wheelDamageScale
                )
            end
        end
    end
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    local car =
        ac.getCar(0)

    if not car then
        return
    end

    --------------------------------------------------------
    -- Acceleration
    --------------------------------------------------------

    local ax, ay, az =
        getAcceleration(
            car
        )

    --------------------------------------------------------
    -- Impact calculation
    --------------------------------------------------------

    local impact,
          impactG,
          verticalG,
          lateralG,
          longitudinalG,
          impactType =
        calculateImpact(
            ax,
            ay,
            az
        )

    --------------------------------------------------------
    -- Debug
    --------------------------------------------------------

    M.debug.g =
        impactG

    M.debug.verticalG =
        verticalG

    M.debug.lateralG =
        lateralG

    M.debug.longitudinalG =
        longitudinalG

    M.debug.impact =
        impact

    M.debug.type =
        impactType

    M.debug.damageLinked =
        okDamage

    --------------------------------------------------------
    -- Export
    --------------------------------------------------------

    ac.store(
        "ngp_impact_g",
        impactG
    )

    ac.store(
        "ngp_impact_value",
        impact
    )

    --------------------------------------------------------
    -- Damage transfer
    --------------------------------------------------------

    applyDamage(
        car,
        impact
    )
end

--============================================================
-- Public API
--============================================================

function M.getImpact()
    return M.debug.impact
end

function M.getImpactG()
    return M.debug.g
end

function M.debugStr()
    return string.format(
        "Impact %s\n" ..
        "G %.2f\n" ..
        "V %.2f L %.2f T %.2f\n" ..
        "Damage %.5f\n" ..
        "DamageState %s",

        M.debug.type,

        M.debug.g,

        M.debug.verticalG,
        M.debug.lateralG,
        M.debug.longitudinalG,

        M.debug.impact,

        M.debug.damageLinked and "OK" or "NIL"
    )
end

return M
