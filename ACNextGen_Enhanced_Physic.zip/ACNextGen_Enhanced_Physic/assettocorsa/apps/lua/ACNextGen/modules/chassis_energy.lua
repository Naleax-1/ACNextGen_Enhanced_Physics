---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- chassis_energy.lua
-- Phase 16
-- Chassis Energy Storage / Release Model
-- 車体エネルギー蓄積・解放モデル
--============================================================

local M = {}

--============================================================
-- Parameters
--============================================================

M.params = {
    buildTau   = 0.100,
    releaseTau = 0.180,

    yawGain   = 0.65,
    rollGain  = 0.45,
    steerGain = 0.35,

    maxEnergy = 1.00,
}

--============================================================
-- State
--============================================================

local state = {
    yawEnergy   = 0.0,
    rollEnergy  = 0.0,
    steerEnergy = 0.0,

    totalEnergy = 0.0,
    release     = 0.0,

    mode = "STABLE",
}

M.debug = state

--============================================================
-- Utility
--============================================================

local function clamp(v, minValue, maxValue)
    if v < minValue then
        return minValue
    end

    if v > maxValue then
        return maxValue
    end

    return v
end

local function lowPass(current, target, alpha)
    return current + (target - current) * alpha
end

local function safeLoad(key, defaultValue)
    local value =
        ac.load(key)

    if value == nil then
        return defaultValue
    end

    return tonumber(value) or defaultValue
end

--============================================================
-- Core
--============================================================

local function calculateTargetEnergy(car)
    local yawRate =
        math.abs(
            (
                car.localAngularVelocity
                and
                car.localAngularVelocity.y
            )
            or 0.0
        )

    local rollCG =
        math.abs(
            safeLoad(
                "ngp_roll_cg",
                0.0
            )
        )

    local steer =
        math.abs(
            car.steer
            or 0.0
        )

    state.yawEnergy =
        yawRate
        *
        M.params.yawGain

    state.rollEnergy =
        rollCG
        *
        M.params.rollGain

    state.steerEnergy =
        steer
        *
        M.params.steerGain

    local target =
        state.yawEnergy
        +
        state.rollEnergy
        +
        state.steerEnergy

    return clamp(
        target,
        0.0,
        M.params.maxEnergy
    )
end

local function updateMode()
    if state.totalEnergy < 0.15 then
        state.mode = "STABLE"
        return
    end

    if state.release > 0.03 then
        state.mode = "RELEASE"
        return
    end

    if state.totalEnergy < 0.45 then
        state.mode = "LOADING"
        return
    end

    state.mode = "STORED"
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    local car =
        ac.getCar(0)

    if not car then
        return
    end

    --------------------------------------------------------
    -- Target energy
    --------------------------------------------------------

    local targetEnergy =
        calculateTargetEnergy(
            car
        )

    --------------------------------------------------------
    -- Build / release response
    --------------------------------------------------------

    local previousEnergy =
        state.totalEnergy

    local tau =
        targetEnergy > state.totalEnergy
        and M.params.buildTau
        or M.params.releaseTau

    local alpha =
        dt /
        (
            tau
            +
            dt
        )

    state.totalEnergy =
        lowPass(
            state.totalEnergy,
            targetEnergy,
            alpha
        )

    --------------------------------------------------------
    -- Release amount
    --------------------------------------------------------

    state.release =
        math.max(
            0.0,
            previousEnergy
            -
            state.totalEnergy
        )

    --------------------------------------------------------
    -- Mode
    --------------------------------------------------------

    updateMode()

    --------------------------------------------------------
    -- Export
    --------------------------------------------------------

    ac.store(
        "ngp_chassis_energy",
        state.totalEnergy
    )

    ac.store(
        "ngp_chassis_release",
        state.release
    )

    ac.store(
        "ngp_chassis_energy_mode",
        state.mode
    )
end

--============================================================
-- Public API
--============================================================

function M.getEnergy()
    return state.totalEnergy
end

function M.getRelease()
    return state.release
end

function M.getMode()
    return state.mode
end

function M.debugStr()
    return string.format(
        "Energy %.3f\n" ..
        "Release %.3f\n" ..
        "Yaw %.3f Roll %.3f Steer %.3f\n" ..
        "%s",

        state.totalEnergy,
        state.release,

        state.yawEnergy,
        state.rollEnergy,
        state.steerEnergy,

        state.mode
    )
end

return M
