---@diagnostic disable: undefined-global


--============================================================
-- observer.lua
-- ACNeXtGen Complete Observer / Safe UI
--============================================================
local M={}; local frameCount=0; local logTimer=0; local LOG_INTERVAL=1.0
local okWA,wheelAudit=pcall(require,'modules/wheel_audit')
local SECTIONS={'tire_state','tire_force','tire_contact','tire_dynamics','tire_memory','diff_lsd','drivetrain','suspension','steering_mechanism','steering_dynamics','arm_compliance','tire_hop','damper_model','caster_effect','progressive_spring','thermal','load_transfer','sprung_mass','weight_distribution','virtual_inertia','chassis_flex','chassis_roll','chassis_energy','tire_compliance','control_arm','brake_system','brake_fade','brake_lock','damage_event','impact_sensor','vehicle_condition','mass_balance'}
local TITLES={tire_state='PHASE 1: TIRE RELAXATION',tire_force='PHASE 1: TIRE FORCE',tire_contact='PHASE 1.5: CONTACT PATCH',tire_dynamics='PHASE 1.8: TIRE DYNAMICS',tire_memory='PHASE 17: TIRE MEMORY',diff_lsd='PHASE 2.5: ADVANCED LSD',drivetrain='PHASE 3: DRIVETRAIN',suspension='PHASE 4: SUSPENSION',steering_mechanism='PHASE 4.6: STEERING MECH',steering_dynamics='PHASE 4.5: STEERING FFB',arm_compliance='PHASE 4.6: ARM COMPLIANCE',tire_hop='PHASE 4.7: TIRE HOP',damper_model='PHASE 4.8: DAMPER',caster_effect='PHASE 4.85: CASTER EFFECT',progressive_spring='PHASE 4.9: PROGRESSIVE SPRING',thermal='PHASE 5: THERMAL',load_transfer='PHASE 6: LOAD TRANSFER',sprung_mass='PHASE 13: SPRUNG MASS',weight_distribution='PHASE 15.4: WEIGHT DISTRIBUTION',virtual_inertia='PHASE 7: VIRTUAL INERTIA',chassis_flex='PHASE 8: CHASSIS FLEX',chassis_roll='PHASE 8.1: BODY ROLL',chassis_energy='PHASE 16: CHASSIS ENERGY',tire_compliance='PHASE 9: TIRE COMPLIANCE',control_arm='PHASE 9.2: CONTROL ARM',brake_system='PHASE 10.1: BRAKE SYSTEM',brake_fade='PHASE 10.2: BRAKE FADE',brake_lock='PHASE 10.3: BRAKE LOCK',damage_event='PHASE 11: DAMAGE EVENT',impact_sensor='PHASE 11.1: IMPACT SENSOR',vehicle_condition='PHASE 12: VEHICLE CONDITION',mass_balance='PHASE 7: MASS BALANCE'}
local function hasField(obj,field) local ok,r=pcall(function() return obj[field] end); return ok and r~=nil end
local function drawModule(name)
    local ok,mod=pcall(require,'modules/'..name); if not ok or not mod or type(mod.debugStr)~='function' then return end
    ui.separator(); ui.text('=== '..(TITLES[name] or name)..' ===')
    if name=='tire_state' or name=='tire_force' or name=='tire_contact' or name=='tire_dynamics' or name=='tire_memory' then
        local names={'FL','FR','RL','RR'}; for i=0,3 do local okS,s=pcall(function() return mod.debugStr(i) end); ui.text(names[i+1]..' '..(okS and s or 'debug error')) end
    else
        local okS,s=pcall(function() return mod.debugStr() end); ui.text(okS and tostring(s) or 'debug error: '..tostring(s))
    end
end
function M.init() if ac and ac.log then ac.log('[ACNeXtGen] Complete Observer Loaded') end end
function M.update(dt) local car=ac.getCar(0); if not car then return end; frameCount=frameCount+1; logTimer=logTimer+dt; if logTimer>=LOG_INTERVAL then logTimer=0; if ac and ac.log then ac.log(string.format('[NGP] RPM=%.0f Gear=%d Speed=%.1f',car.rpm or 0,car.gear or 0,car.speedKmh or 0)) end end end
function M.drawUI()
 local car=ac.getCar(0); if not car then ui.text('Vehicle not found'); return end
 ui.text('=== ACNeXtGen Complete Fixed ==='); ui.separator(); ui.text(string.format('RPM      : %.0f',car.rpm or 0)); ui.text(string.format('Gear     : %d',car.gear or 0)); ui.text(string.format('Speed    : %.1f km/h',car.speedKmh or 0)); if hasField(car,'localAngularVelocity') then ui.text(string.format('YawRate  : %.5f',car.localAngularVelocity.y or 0)) end; ui.text(string.format('PhysicsAlive %.3f',ac.load('ngp_physics_alive') or 0))
 ui.separator(); ui.text('=== INPUTS ==='); for _,f in ipairs({'steer','gas','brake','clutch','handbrake'}) do if hasField(car,f) then ui.text(string.format('%-10s: %.3f',f,car[f] or 0)) end end
 ui.separator(); ui.text('=== API AUDIT ==='); for _,f in ipairs({'steer','gas','brake','clutch','handbrake','wheels','acceleration','localVelocity','localAngularVelocity'}) do ui.text(f..' : '..(hasField(car,f) and 'OK' or 'NIL')) end
 ui.separator(); ui.text('=== STORE TEST ==='); ui.text(string.format('DriveTorque %.3f',ac.load('ngp_drive_torque') or 0)); ui.text(string.format('LSDLock %.3f',ac.load('ngp_lsd_lock') or 0)); ui.text(string.format('Lat0 %.3f',ac.load('ngp_lat_0') or 0)); ui.text(string.format('CPLat0 %.3f',ac.load('ngp_cp_lat_0') or 0))
 if okWA and wheelAudit.draw then ui.separator(); wheelAudit.draw(car) end
 for _,name in ipairs(SECTIONS) do drawModule(name) end
end
return M
