---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- control_arm.lua
-- Phase 9.2
-- Virtual Control Arm + Bush Compliance
-- 仮想コントロールアーム / ブッシュたわみモデル
--============================================================

local M = {}

--============================================================
-- Parameters
--============================================================

M.params = {
    frontTau = 0.070,
    rearTau  = 0.110,

    frontFlex = 0.35,
    rearFlex  = 0.55,

    maxDeflection = 0.25,
}

--============================================================
-- State
--============================================================

local state = {
    front = 0.0,
    rear  = 0.0,
}

M.debug = {
    rawYaw = 0.0,

    frontDef = 0.0,
    rearDef  = 0.0,

    total = 0.0,
}

--============================================================
-- Utility
--============================================================

local function clamp(v, minValue, maxValue)
    if v < minValue then
        return minValue
    end

    if v > maxValue then
        return maxValue
    end

    return v
end

local function lowPass(current, target, alpha)
    return current + (target - current) * alpha
end

local function safeNumber(value, defaultValue)
    return tonumber(value) or defaultValue
end

--============================================================
-- Core
--============================================================

local function getYawInput(car)
    if not car.localAngularVelocity then
        return 0.0
    end

    local yawRate =
        safeNumber(
            car.localAngularVelocity.y,
            0.0
        )

    local speedMs =
        safeNumber(
            car.speedKmh,
            0.0
        )
        /
        3.6

    return yawRate * speedMs
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    local car =
        ac.getCar(0)

    if not car then
        return
    end

    --------------------------------------------------------
    -- Input
    --------------------------------------------------------

    local input =
        getYawInput(
            car
        )

    --------------------------------------------------------
    -- Filter
    --------------------------------------------------------

    local frontAlpha =
        dt /
        (
            M.params.frontTau
            +
            dt
        )

    local rearAlpha =
        dt /
        (
            M.params.rearTau
            +
            dt
        )

    state.front =
        lowPass(
            state.front,
            input,
            frontAlpha
        )

    state.rear =
        lowPass(
            state.rear,
            state.front,
            rearAlpha
        )

    --------------------------------------------------------
    -- Clamp deflection
    --------------------------------------------------------

    state.front =
        clamp(
            state.front,
            -M.params.maxDeflection,
            M.params.maxDeflection
        )

    state.rear =
        clamp(
            state.rear,
            -M.params.maxDeflection,
            M.params.maxDeflection
        )

    --------------------------------------------------------
    -- Output deflection
    --------------------------------------------------------

    M.debug.rawYaw =
        input

    M.debug.frontDef =
        state.front
        *
        M.params.frontFlex

    M.debug.rearDef =
        state.rear
        *
        M.params.rearFlex

    M.debug.total =
        M.debug.frontDef
        +
        M.debug.rearDef

    --------------------------------------------------------
    -- Export
    --------------------------------------------------------

    ac.store(
        "ngp_arm_front",
        M.debug.frontDef
    )

    ac.store(
        "ngp_arm_rear",
        M.debug.rearDef
    )

    ac.store(
        "ngp_arm_total",
        M.debug.total
    )

    ac.store(
        "ngp_arm_raw_yaw",
        M.debug.rawYaw
    )
end

--============================================================
-- Public API
--============================================================

function M.getFront()
    return M.debug.frontDef
end

function M.getRear()
    return M.debug.rearDef
end

function M.getTotal()
    return M.debug.total
end

function M.debugStr()
    return string.format(
        "Arm Front %.4f\n" ..
        "Arm Rear %.4f\n" ..
        "Total %.4f\n" ..
        "RawYaw %.4f",

        M.debug.frontDef,
        M.debug.rearDef,
        M.debug.total,
        M.debug.rawYaw
    )
end

return M
