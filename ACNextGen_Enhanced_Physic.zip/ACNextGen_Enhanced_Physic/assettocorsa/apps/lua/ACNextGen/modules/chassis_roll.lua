---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- chassis_roll.lua
-- Phase 8.1
-- Body Roll Compliance Model
-- 仮想ボディロール遅れモデル
--============================================================

local M = {}

--============================================================
-- Parameters
--============================================================

M.params = {
    rollTau  = 0.150,
    rollGain = 0.250,

    maxRoll = 1.000,
}

--============================================================
-- State
--============================================================

local state = {
    roll = 0.0,
    output = 0.0,
}

M.debug = {
    raw      = 0.0,
    filtered = 0.0,
    output   = 0.0,
}

--============================================================
-- Utility
--============================================================

local function clamp(v, minValue, maxValue)
    if v < minValue then
        return minValue
    end

    if v > maxValue then
        return maxValue
    end

    return v
end

local function lowPass(current, target, alpha)
    return current + (target - current) * alpha
end

local function safeNumber(value, defaultValue)
    return tonumber(value) or defaultValue
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    local car =
        ac.getCar(0)

    if not car then
        return
    end

    --------------------------------------------------------
    -- Raw roll angular velocity
    --------------------------------------------------------

    local rawRoll = 0.0

    if car.localAngularVelocity then
        rawRoll =
            safeNumber(
                car.localAngularVelocity.z,
                0.0
            )
    end

    --------------------------------------------------------
    -- Filter
    --------------------------------------------------------

    local alpha =
        dt /
        (
            M.params.rollTau
            +
            dt
        )

    state.roll =
        lowPass(
            state.roll,
            rawRoll,
            alpha
        )

    state.roll =
        clamp(
            state.roll,
            -M.params.maxRoll,
            M.params.maxRoll
        )

    --------------------------------------------------------
    -- Output
    --------------------------------------------------------

    state.output =
        state.roll
        *
        M.params.rollGain

    --------------------------------------------------------
    -- Debug
    --------------------------------------------------------

    M.debug.raw =
        rawRoll

    M.debug.filtered =
        state.roll

    M.debug.output =
        state.output

    --------------------------------------------------------
    -- Export
    --------------------------------------------------------

    ac.store(
        "ngp_body_roll",
        state.output
    )

    ac.store(
        "ngp_body_roll_raw",
        rawRoll
    )

    ac.store(
        "ngp_body_roll_filtered",
        state.roll
    )
end

--============================================================
-- Public API
--============================================================

function M.getRoll()
    return state.roll
end

function M.getOutput()
    return state.output
end

function M.debugStr()
    return string.format(
        "BodyRoll %.3f -> %.3f\nOutput %.3f",
        M.debug.raw,
        M.debug.filtered,
        M.debug.output
    )
end

return M
