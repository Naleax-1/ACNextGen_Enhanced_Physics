---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- steering_mechanism.lua
-- Phase 8.5
-- Steering Knuckle / FFB Assist Model
-- ステアリングナックル反力・仮想FFB補助モデル
--============================================================

local M = {}

--============================================================
-- Parameters
--============================================================

M.params = {
    mzScale = 0.00065,

    fxScale = 0.00020,
    fyScale = 0.00020,

    bumpScale = 0.25,
    dampingScale = 0.30,

    maxSpeedFactor = 1.80,

    maxFFB = 2.50,
    minFFB = -2.50,

    minSpeed = 3.0,

    knuckleTau = 0.050,

    mzLimit = 1.20,
    fxLimit = 0.80,
    fyLimit = 1.00,

    bumpLimit = 0.50,
    dampLimit = 0.80,
}

--============================================================
-- State
--============================================================

local state = {
    prevSteer = 0.0,

    prevSusp = {
        [0] = 0.0,
        [1] = 0.0,
    },

    knuckle = {
        fx = 0.0,
        fy = 0.0,
        mz = 0.0,
    },

    initialized = false,
}

M.debug = {
    mzForce = 0.0,
    fxForce = 0.0,
    fyForce = 0.0,

    bumpForce = 0.0,
    dampForce = 0.0,

    finalFFB = 0.0,

    knuckleFX = 0.0,
    knuckleFY = 0.0,
    knuckleMZ = 0.0,

    speedFactor = 0.0,
    active = false,
}

--============================================================
-- Utility
--============================================================

local function clamp(v, minValue, maxValue)
    if v < minValue then
        return minValue
    end

    if v > maxValue then
        return maxValue
    end

    return v
end

local function safeNumber(value, defaultValue)
    return tonumber(value) or defaultValue
end

local function lowPass(current, target, tau, dt)
    return
        current
        +
        (
            target
            -
            current
        )
        *
        (
            dt
            /
            (
                tau
                +
                dt
            )
        )
end

local function safeStore(key, value)
    pcall(
        function()
            ac.store(
                key,
                value
            )
        end
    )
end

local function safeSetSteeringFFB(value)
    if not ac or not ac.setSteeringFFB then
        return false
    end

    local ok =
        pcall(
            function()
                ac.setSteeringFFB(
                    value
                )
            end
        )

    return ok
end

--============================================================
-- Wheel input
--============================================================

local function readFrontWheels(car)
    if not car.wheels then
        return nil, nil
    end

    return car.wheels[0], car.wheels[1]
end

local function readWheelForces(frontLeft, frontRight)
    local mz =
        (
            safeNumber(
                frontLeft.mz,
                0.0
            )
            +
            safeNumber(
                frontRight.mz,
                0.0
            )
        )
        *
        0.5

    local fx =
        (
            safeNumber(
                frontLeft.fx,
                0.0
            )
            +
            safeNumber(
                frontRight.fx,
                0.0
            )
        )
        *
        0.5

    local fy =
        (
            safeNumber(
                frontLeft.fy,
                0.0
            )
            +
            safeNumber(
                frontRight.fy,
                0.0
            )
        )
        *
        0.5

    return fx, fy, mz
end

--============================================================
-- Core
--============================================================

local function updateKnuckleFilter(fx, fy, mz, dt)
    state.knuckle.fx =
        lowPass(
            state.knuckle.fx,
            fx,
            M.params.knuckleTau,
            dt
        )

    state.knuckle.fy =
        lowPass(
            state.knuckle.fy,
            fy,
            M.params.knuckleTau,
            dt
        )

    state.knuckle.mz =
        lowPass(
            state.knuckle.mz,
            mz,
            M.params.knuckleTau,
            dt
        )
end

local function calculateForceComponents(steer)
    local mzForce =
        clamp(
            state.knuckle.mz
            *
            M.params.mzScale,
            -M.params.mzLimit,
            M.params.mzLimit
        )

    local fxForce =
        clamp(
            state.knuckle.fx
            *
            M.params.fxScale
            *
            math.abs(
                steer
                +
                0.01
            ),
            -M.params.fxLimit,
            M.params.fxLimit
        )

    local fyForce =
        clamp(
            -state.knuckle.fy
            *
            M.params.fyScale,
            -M.params.fyLimit,
            M.params.fyLimit
        )

    return mzForce, fxForce, fyForce
end

local function calculateBumpForce(frontLeft, frontRight, dt)
    local suspFL =
        safeNumber(
            frontLeft.suspensionTravel,
            state.prevSusp[0]
        )

    local suspFR =
        safeNumber(
            frontRight.suspensionTravel,
            state.prevSusp[1]
        )

    if not state.initialized then
        state.prevSusp[0] = suspFL
        state.prevSusp[1] = suspFR
        return 0.0
    end

    local velFL =
        (
            suspFL
            -
            state.prevSusp[0]
        )
        /
        dt

    local velFR =
        (
            suspFR
            -
            state.prevSusp[1]
        )
        /
        dt

    state.prevSusp[0] =
        suspFL

    state.prevSusp[1] =
        suspFR

    local bumpForce =
        (
            velFL
            +
            velFR
        )
        *
        0.5
        *
        M.params.bumpScale
        *
        0.1

    return clamp(
        bumpForce,
        -M.params.bumpLimit,
        M.params.bumpLimit
    )
end

local function calculateSteerDamping(steer, dt)
    if not state.initialized then
        state.prevSteer = steer
        return 0.0
    end

    local steerVelocity =
        (
            steer
            -
            state.prevSteer
        )
        /
        dt

    state.prevSteer =
        steer

    local dampForce =
        -steerVelocity
        *
        M.params.dampingScale

    return clamp(
        dampForce,
        -M.params.dampLimit,
        M.params.dampLimit
    )
end

local function calculateSpeedFactor(speedKmh)
    local speedMs =
        speedKmh
        /
        3.6

    return math.min(
        speedMs
        *
        0.03,
        M.params.maxSpeedFactor
    )
end

local function exportState()
    safeStore(
        "ngp_steering_ffb",
        M.debug.finalFFB
    )

    safeStore(
        "ngp_steering_mz_force",
        M.debug.mzForce
    )

    safeStore(
        "ngp_steering_fx_force",
        M.debug.fxForce
    )

    safeStore(
        "ngp_steering_fy_force",
        M.debug.fyForce
    )

    safeStore(
        "ngp_steering_bump_force",
        M.debug.bumpForce
    )

    safeStore(
        "ngp_steering_damp_force",
        M.debug.dampForce
    )
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    local car =
        ac.getCar(0)

    if not car then
        return
    end

    local speedKmh =
        safeNumber(
            car.speedKmh,
            0.0
        )

    --------------------------------------------------------
    -- Low speed disable
    --------------------------------------------------------

    if speedKmh < M.params.minSpeed then
        M.debug.finalFFB = 0.0
        M.debug.speedFactor = 0.0
        M.debug.active = false

        safeSetSteeringFFB(nil)
        exportState()

        return
    end

    local frontLeft,
          frontRight =
        readFrontWheels(
            car
        )

    if not frontLeft or not frontRight then
        return
    end

    local steer =
        safeNumber(
            car.steer,
            0.0
        )

    --------------------------------------------------------
    -- Raw wheel forces
    --------------------------------------------------------

    local fx,
          fy,
          mz =
        readWheelForces(
            frontLeft,
            frontRight
        )

    updateKnuckleFilter(
        fx,
        fy,
        mz,
        dt
    )

    --------------------------------------------------------
    -- Force components
    --------------------------------------------------------

    local mzForce,
          fxForce,
          fyForce =
        calculateForceComponents(
            steer
        )

    local bumpForce =
        calculateBumpForce(
            frontLeft,
            frontRight,
            dt
        )

    local dampForce =
        calculateSteerDamping(
            steer,
            dt
        )

    --------------------------------------------------------
    -- Final FFB
    --------------------------------------------------------

    local speedFactor =
        calculateSpeedFactor(
            speedKmh
        )

    local finalFFB =
        (
            mzForce
            +
            fxForce
            +
            fyForce
            +
            bumpForce
            +
            dampForce
        )
        *
        speedFactor

    finalFFB =
        clamp(
            finalFFB,
            M.params.minFFB,
            M.params.maxFFB
        )

    --------------------------------------------------------
    -- Debug
    --------------------------------------------------------

    M.debug.mzForce =
        mzForce

    M.debug.fxForce =
        fxForce

    M.debug.fyForce =
        fyForce

    M.debug.bumpForce =
        bumpForce

    M.debug.dampForce =
        dampForce

    M.debug.finalFFB =
        finalFFB

    M.debug.knuckleFX =
        state.knuckle.fx

    M.debug.knuckleFY =
        state.knuckle.fy

    M.debug.knuckleMZ =
        state.knuckle.mz

    M.debug.speedFactor =
        speedFactor

    M.debug.active =
        true

    state.initialized =
        true

    --------------------------------------------------------
    -- Apply / Export
    --------------------------------------------------------

    safeSetSteeringFFB(
        finalFFB
    )

    exportState()
end

--============================================================
-- Public API
--============================================================

function M.getFFB()
    return M.debug.finalFFB
end

function M.getMZForce()
    return M.debug.mzForce
end

function M.getFXForce()
    return M.debug.fxForce
end

function M.getFYForce()
    return M.debug.fyForce
end

function M.debugStr()
    return string.format(
        "FFB %.3f Active:%s\n" ..
        "MZ %.3f FX %.3f FY %.3f\n" ..
        "Bump %.3f Damp %.3f",

        M.debug.finalFFB,
        M.debug.active and "YES" or "NO",

        M.debug.mzForce,
        M.debug.fxForce,
        M.debug.fyForce,

        M.debug.bumpForce,
        M.debug.dampForce
    )
end

return M
