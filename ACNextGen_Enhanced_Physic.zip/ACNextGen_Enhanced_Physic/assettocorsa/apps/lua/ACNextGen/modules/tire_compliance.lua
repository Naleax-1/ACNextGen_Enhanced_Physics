---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- tire_compliance.lua
-- Phase 1.8
-- Tire Compliance / Response Delay Model
-- タイヤコンプライアンス・応答遅れモデル
--============================================================

local M = {}

--============================================================
-- Parameters
--============================================================

M.params = {
    complianceTau = 0.120,

    loadReference = 3500.0,

    frontGain = 1.0,
    rearGain  = 1.0,

    maxDeflection = 1.0,

    maxComplianceDrop = 0.40,

    loadDropGain = 0.35,

    minCompliance = 0.50,
    maxCompliance = 1.20,
}

--============================================================
-- State
--============================================================

M.state = {
    frontCompliance = 1.0,
    rearCompliance  = 1.0,

    frontDeflection = 0.0,
    rearDeflection  = 0.0,

    responseDelay = 0.0,
}

M.debug = {
    frontLoad = 0.0,
    rearLoad  = 0.0,

    frontCompliance = 1.0,
    rearCompliance  = 1.0,

    frontDeflection = 0.0,
    rearDeflection  = 0.0,

    responseDelay = 0.0,

    loadLinked = false,
}

--============================================================
-- Utility
--============================================================

local function clamp(v, minValue, maxValue)
    if v < minValue then
        return minValue
    end

    if v > maxValue then
        return maxValue
    end

    return v
end

local function safeNumber(value, defaultValue)
    return tonumber(value) or defaultValue
end

local function safeLoad(key, defaultValue)
    local value =
        ac.load(key)

    if value == nil then
        return defaultValue
    end

    return safeNumber(
        value,
        defaultValue
    )
end

local function safeStore(key, value)
    pcall(
        function()
            ac.store(
                key,
                value
            )
        end
    )
end

local function lowPass(current, target, tau, dt)
    return
        current
        +
        (
            target
            -
            current
        )
        *
        (
            dt
            /
            (
                tau
                +
                dt
            )
        )
end

--============================================================
-- Wheel load input
--============================================================

local function getWheelLoad(car, index)
    local wheel =
        car
        and car.wheels
        and car.wheels[index]

    if wheel then
        local wheelLoad =
            safeNumber(
                wheel.load,
                nil
            )

        if wheelLoad ~= nil then
            return wheelLoad, false
        end

        local normalLoad =
            safeNumber(
                wheel.normalLoad,
                nil
            )

        if normalLoad ~= nil then
            return normalLoad, false
        end
    end

    --------------------------------------------------------
    -- Fallback:
    -- load_transfer.lua の動的荷重差を補助値として読む
    --------------------------------------------------------

    local dynamicLoad =
        safeLoad(
            "ngp_dlt_load_" .. index,
            0.0
        )

    return
        M.params.loadReference
        +
        dynamicLoad,
        true
end

local function readAxleLoads(car)
    local loadFL, linkedFL =
        getWheelLoad(
            car,
            0
        )

    local loadFR, linkedFR =
        getWheelLoad(
            car,
            1
        )

    local loadRL, linkedRL =
        getWheelLoad(
            car,
            2
        )

    local loadRR, linkedRR =
        getWheelLoad(
            car,
            3
        )

    local frontLoad =
        (
            loadFL
            +
            loadFR
        )
        *
        0.5

    local rearLoad =
        (
            loadRL
            +
            loadRR
        )
        *
        0.5

    local usingFallback =
        linkedFL
        or linkedFR
        or linkedRL
        or linkedRR

    return frontLoad, rearLoad, usingFallback
end

--============================================================
-- Core
--============================================================

local function calculateTargetCompliance(load, gain)
    local loadRatio =
        load
        /
        math.max(
            M.params.loadReference,
            1.0
        )

    local overload =
        math.max(
            0.0,
            loadRatio
            -
            1.0
        )

    local drop =
        overload
        *
        M.params.loadDropGain
        *
        gain

    drop =
        clamp(
            drop,
            0.0,
            M.params.maxComplianceDrop
        )

    local compliance =
        1.0
        -
        drop

    return clamp(
        compliance,
        M.params.minCompliance,
        M.params.maxCompliance
    )
end

local function updateDeflection()
    M.state.frontDeflection =
        clamp(
            (
                1.0
                -
                M.state.frontCompliance
            )
            *
            M.params.frontGain,
            0.0,
            M.params.maxDeflection
        )

    M.state.rearDeflection =
        clamp(
            (
                1.0
                -
                M.state.rearCompliance
            )
            *
            M.params.rearGain,
            0.0,
            M.params.maxDeflection
        )

    M.state.responseDelay =
        (
            M.state.frontDeflection
            +
            M.state.rearDeflection
        )
        *
        0.5
end

--============================================================
-- Export
--============================================================

local function exportState()
    safeStore(
        "ngp_tire_comp_front",
        M.state.frontCompliance
    )

    safeStore(
        "ngp_tire_comp_rear",
        M.state.rearCompliance
    )

    safeStore(
        "ngp_tire_def_front",
        M.state.frontDeflection
    )

    safeStore(
        "ngp_tire_def_rear",
        M.state.rearDeflection
    )

    safeStore(
        "ngp_tire_response_delay",
        M.state.responseDelay
    )
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    local car =
        ac.getCar(0)

    if not car or not car.wheels then
        return
    end

    --------------------------------------------------------
    -- Load input
    --------------------------------------------------------

    local frontLoad,
          rearLoad,
          usingFallback =
        readAxleLoads(
            car
        )

    --------------------------------------------------------
    -- Target compliance
    --------------------------------------------------------

    local targetFront =
        calculateTargetCompliance(
            frontLoad,
            M.params.frontGain
        )

    local targetRear =
        calculateTargetCompliance(
            rearLoad,
            M.params.rearGain
        )

    --------------------------------------------------------
    -- Filter
    --------------------------------------------------------

    M.state.frontCompliance =
        lowPass(
            M.state.frontCompliance,
            targetFront,
            M.params.complianceTau,
            dt
        )

    M.state.rearCompliance =
        lowPass(
            M.state.rearCompliance,
            targetRear,
            M.params.complianceTau,
            dt
        )

    --------------------------------------------------------
    -- Deflection / response delay
    --------------------------------------------------------

    updateDeflection()

    --------------------------------------------------------
    -- Debug
    --------------------------------------------------------

    M.debug.frontLoad =
        frontLoad

    M.debug.rearLoad =
        rearLoad

    M.debug.frontCompliance =
        M.state.frontCompliance

    M.debug.rearCompliance =
        M.state.rearCompliance

    M.debug.frontDeflection =
        M.state.frontDeflection

    M.debug.rearDeflection =
        M.state.rearDeflection

    M.debug.responseDelay =
        M.state.responseDelay

    M.debug.loadLinked =
        usingFallback

    --------------------------------------------------------
    -- Export
    --------------------------------------------------------

    exportState()
end

--============================================================
-- Public API
--============================================================

function M.getFrontCompliance()
    return M.state.frontCompliance
end

function M.getRearCompliance()
    return M.state.rearCompliance
end

function M.getResponseDelay()
    return M.state.responseDelay
end

function M.getFrontDeflection()
    return M.state.frontDeflection
end

function M.getRearDeflection()
    return M.state.rearDeflection
end

function M.debugStr()
    return string.format(
        "FrontLoad %.0f Comp %.3f Def %.3f\n" ..
        "RearLoad %.0f Comp %.3f Def %.3f\n" ..
        "Delay %.3f Fallback:%s",

        M.debug.frontLoad,
        M.debug.frontCompliance,
        M.debug.frontDeflection,

        M.debug.rearLoad,
        M.debug.rearCompliance,
        M.debug.rearDeflection,

        M.debug.responseDelay,
        M.debug.loadLinked and "YES" or "NO"
    )
end

return M
