---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- tire_hop.lua
-- Phase 4.7
-- Tire Hop / Unsprung Oscillation Model
-- タイヤホップ / バネ下振動モデル
--============================================================

local M = {}

--============================================================
-- Parameters
--============================================================

M.params = {
    --------------------------------------------------------
    -- Energy response
    --------------------------------------------------------

    tauBuild = 0.035,
    tauDecay = 0.090,

    --------------------------------------------------------
    -- Slip trigger
    --------------------------------------------------------

    slipStart = 0.12,
    slipFull  = 0.45,

    --------------------------------------------------------
    -- Load trigger
    --------------------------------------------------------

    loadRef = 3000.0,
    loadDropGain = 0.45,

    --------------------------------------------------------
    -- Drive / brake / LSD coupling
    --------------------------------------------------------

    driveGain = 0.75,
    brakeGain = 0.55,
    lsdGain   = 0.35,

    --------------------------------------------------------
    -- Suspension velocity coupling
    --------------------------------------------------------

    suspVelGain = 0.18,

    --------------------------------------------------------
    -- Oscillator
    --------------------------------------------------------

    oscFreq = 42.0,
    oscDamp = 0.92,

    --------------------------------------------------------
    -- Limits
    --------------------------------------------------------

    maxHop = 1.0,
    maxLoadPulse = 1800.0,

    --------------------------------------------------------
    -- Balance
    --------------------------------------------------------

    rearHopBias = 1.25,

    --------------------------------------------------------
    -- Memory coupling
    --------------------------------------------------------

    memoryGain = 0.35,
}

--============================================================
-- State
--============================================================

local state = {
    energy = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    osc = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    phase = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    loadPulse = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    mode = {
        [0] = "STABLE",
        [1] = "STABLE",
        [2] = "STABLE",
        [3] = "STABLE",
    },

    prevSusp = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    initialized = {
        [0] = false,
        [1] = false,
        [2] = false,
        [3] = false,
    },
}

M.debug = state

--============================================================
-- Utility
--============================================================

local function clamp(v, minValue, maxValue)
    if v < minValue then
        return minValue
    end

    if v > maxValue then
        return maxValue
    end

    return v
end

local function safeNumber(value, defaultValue)
    return tonumber(value) or defaultValue
end

local function safeLoad(key, defaultValue)
    local value =
        ac.load(key)

    if value == nil then
        return defaultValue
    end

    return safeNumber(
        value,
        defaultValue
    )
end

local function safeStore(key, value)
    pcall(
        function()
            ac.store(
                key,
                value
            )
        end
    )
end

local function lowPass(current, target, tau, dt)
    return
        current
        +
        (
            target
            -
            current
        )
        *
        (
            dt
            /
            (
                tau
                +
                dt
            )
        )
end

--============================================================
-- Input helpers
--============================================================

local function getWheelLoad(wheel, index)
    local load =
        safeNumber(
            wheel.load,
            nil
        )

    if load ~= nil then
        return load
    end

    local normalLoad =
        safeNumber(
            wheel.normalLoad,
            nil
        )

    if normalLoad ~= nil then
        return normalLoad
    end

    local dynamicLoad =
        safeLoad(
            "ngp_dlt_load_" .. index,
            0.0
        )

    return
        M.params.loadRef
        +
        dynamicLoad
end

local function getSuspensionTravel(wheel, index)
    local travel =
        safeNumber(
            wheel.suspensionTravel,
            nil
        )

    if travel ~= nil then
        return travel
    end

    local length =
        safeNumber(
            wheel.suspensionLength,
            nil
        )

    if length ~= nil then
        return length
    end

    return state.prevSusp[index]
end

local function getSuspensionVelocity(wheel, index, dt)
    local susp =
        getSuspensionTravel(
            wheel,
            index
        )

    if not state.initialized[index] then
        state.prevSusp[index] =
            susp

        state.initialized[index] =
            true

        return 0.0
    end

    local suspVel =
        (
            susp
            -
            state.prevSusp[index]
        )
        /
        dt

    state.prevSusp[index] =
        susp

    return suspVel
end

local function getMemory(index)
    local memory =
        safeLoad(
            "ngp_memory_" .. index,
            nil
        )

    if memory ~= nil then
        return clamp(
            memory,
            0.0,
            1.0
        )
    end

    return clamp(
        safeLoad(
            "ngp_rubber_memory_" .. index,
            0.0
        ),
        0.0,
        1.0
    )
end

--============================================================
-- Core calculation
--============================================================

local function calculateSlipFactor(slipRatio)
    local range =
        M.params.slipFull
        -
        M.params.slipStart

    if range <= 0.001 then
        return 0.0
    end

    return clamp(
        (
            slipRatio
            -
            M.params.slipStart
        )
        /
        range,
        0.0,
        1.0
    )
end

local function calculateLoadFactor(load)
    return clamp(
        1.0
        -
        load
        /
        math.max(
            M.params.loadRef,
            1.0
        ),
        0.0,
        1.0
    )
end

local function calculateTargetHop(index, wheel, drive, brake, lsd, dt)
    local slip =
        math.abs(
            safeNumber(
                wheel.slipRatio,
                0.0
            )
        )

    local load =
        getWheelLoad(
            wheel,
            index
        )

    local suspVel =
        getSuspensionVelocity(
            wheel,
            index,
            dt
        )

    local slipFactor =
        calculateSlipFactor(
            slip
        )

    local loadFactor =
        calculateLoadFactor(
            load
        )

    local driveFactor =
        clamp(
            drive
            *
            M.params.driveGain,
            0.0,
            1.0
        )

    local brakeFactor =
        clamp(
            brake
            *
            M.params.brakeGain,
            0.0,
            1.0
        )

    local lsdFactor =
        clamp(
            lsd
            *
            M.params.lsdGain,
            0.0,
            1.0
        )

    local suspFactor =
        clamp(
            math.abs(
                suspVel
            )
            *
            M.params.suspVelGain,
            0.0,
            1.0
        )

    local target =
        slipFactor
        *
        0.45
        +
        loadFactor
        *
        M.params.loadDropGain
        +
        driveFactor
        *
        0.25
        +
        brakeFactor
        *
        0.20
        +
        lsdFactor
        *
        0.20
        +
        suspFactor
        *
        0.25

    if index >= 2 then
        target =
            target
            *
            M.params.rearHopBias
    end

    local memory =
        getMemory(
            index
        )

    target =
        target
        *
        (
            1.0
            +
            memory
            *
            M.params.memoryGain
        )

    return clamp(
        target,
        0.0,
        M.params.maxHop
    )
end

local function updateOscillator(index, dt)
    state.phase[index] =
        state.phase[index]
        +
        M.params.oscFreq
        *
        dt

    --------------------------------------------------------
    -- phaseが巨大化しすぎないように循環
    --------------------------------------------------------

    if state.phase[index] > 1.0 then
        state.phase[index] =
            state.phase[index]
            -
            math.floor(
                state.phase[index]
            )
    end

    state.osc[index] =
        math.sin(
            state.phase[index]
            *
            math.pi
            *
            2.0
        )
        *
        state.energy[index]
        *
        M.params.oscDamp

    state.loadPulse[index] =
        clamp(
            state.osc[index]
            *
            M.params.maxLoadPulse,
            -M.params.maxLoadPulse,
            M.params.maxLoadPulse
        )
end

local function updateMode(index)
    if state.energy[index] > 0.25 then
        state.mode[index] = "HOP"
    else
        state.mode[index] = "STABLE"
    end
end

--============================================================
-- Export
--============================================================

local function exportWheel(index)
    safeStore(
        "ngp_tirehop_" .. index,
        state.loadPulse[index]
    )

    safeStore(
        "ngp_tirehop_energy_" .. index,
        state.energy[index]
    )

    safeStore(
        "ngp_tirehop_osc_" .. index,
        state.osc[index]
    )

    safeStore(
        "ngp_tirehop_mode_" .. index,
        state.mode[index] == "HOP" and 1.0 or 0.0
    )
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    local car =
        ac.getCar(0)

    if not car or not car.wheels then
        return
    end

    local drive =
        math.abs(
            safeLoad(
                "ngp_drive_torque",
                0.0
            )
        )

    local lsd =
        safeLoad(
            "ngp_lsd_lock",
            0.0
        )

    local brake =
        safeNumber(
            car.brake,
            0.0
        )

    for i = 0, 3 do
        local wheel =
            car.wheels[i]

        if wheel then
            ------------------------------------------------
            -- Target hop energy
            ------------------------------------------------

            local target =
                calculateTargetHop(
                    i,
                    wheel,
                    drive,
                    brake,
                    lsd,
                    dt
                )

            ------------------------------------------------
            -- Energy response
            ------------------------------------------------

            local tau =
                target > state.energy[i]
                and M.params.tauBuild
                or M.params.tauDecay

            state.energy[i] =
                lowPass(
                    state.energy[i],
                    target,
                    tau,
                    dt
                )

            state.energy[i] =
                clamp(
                    state.energy[i],
                    0.0,
                    M.params.maxHop
                )

            ------------------------------------------------
            -- Oscillator / load pulse
            ------------------------------------------------

            updateOscillator(
                i,
                dt
            )

            updateMode(
                i
            )

            ------------------------------------------------
            -- Export
            ------------------------------------------------

            exportWheel(
                i
            )
        else
            state.energy[i] = 0.0
            state.osc[i] = 0.0
            state.loadPulse[i] = 0.0
            state.mode[i] = "NIL"

            exportWheel(
                i
            )
        end
    end
end

--============================================================
-- Public API
--============================================================

function M.getEnergy(index)
    return state.energy[index] or 0.0
end

function M.getPulse(index)
    return state.loadPulse[index] or 0.0
end

function M.getOsc(index)
    return state.osc[index] or 0.0
end

function M.getMode(index)
    return state.mode[index] or "NIL"
end

function M.debugStr()
    return string.format(
        "HopE %.2f %.2f %.2f %.2f\n" ..
        "Pulse %.0f %.0f %.0f %.0f\n" ..
        "Mode %s %s %s %s",

        state.energy[0],
        state.energy[1],
        state.energy[2],
        state.energy[3],

        state.loadPulse[0],
        state.loadPulse[1],
        state.loadPulse[2],
        state.loadPulse[3],

        state.mode[0],
        state.mode[1],
        state.mode[2],
        state.mode[3]
    )
end

return M
