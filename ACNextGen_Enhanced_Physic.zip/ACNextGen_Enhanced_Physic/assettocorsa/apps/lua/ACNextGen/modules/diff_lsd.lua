---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- diff_lsd.lua
-- Phase 2.5
-- Advanced LSD State Model
-- 2way LSD 仮想ロック率・差回転・発熱モデル
--============================================================

local M = {}

--============================================================
-- Parameters
--============================================================

M.params = {
    preloadLock = 0.15,

    powerGain = 1.00,
    coastGain = 0.45,

    diffForFullLock = 8.0,

    tauLock   = 0.05,
    tauUnlock = 0.10,

    heatGain = 10.0,

    lowSpeedKmh = 2.0,
    lowOmegaThreshold = 0.20,

    loadDiffReference = 2000.0,
    loadUnlockGain    = 0.25,

    rearBiasGain = 0.40,

    memoryUnlockGain = 0.12,

    brakeLockGain = 0.15,
}

--============================================================
-- State
--============================================================

local state = {
    lockRatio = 0.0,
    targetLock = 0.0,

    heat = 0.0,

    diff = 0.0,
    signedDiff = 0.0,

    mode = "COAST",

    loadRL = 0.0,
    loadRR = 0.0,
    loadDiff = 0.0,
}

local debug = {
    omegaL = 0.0,
    omegaR = 0.0,

    rawOmegaL = 0.0,
    rawOmegaR = 0.0,

    rearBias = 0.50,
    driveTorque = 0.0,
    rearMemory = 0.0,
}

M.debug = state

--============================================================
-- Utility
--============================================================

local function clamp(v, minValue, maxValue)
    if v < minValue then
        return minValue
    end

    if v > maxValue then
        return maxValue
    end

    return v
end

local function safeNumber(value, defaultValue)
    return tonumber(value) or defaultValue
end

local function safeLoad(key, defaultValue)
    local value =
        ac.load(key)

    if value == nil then
        return defaultValue
    end

    return safeNumber(
        value,
        defaultValue
    )
end

local function lowPass(current, target, tau, dt)
    return
        current
        +
        (
            target
            -
            current
        )
        *
        (
            dt
            /
            (
                tau
                +
                dt
            )
        )
end

--============================================================
-- Wheel helpers
--============================================================

local function readRearWheelOmega(car)
    local rl =
        car.wheels[2]

    local rr =
        car.wheels[3]

    if not rl or not rr then
        return nil
    end

    local omegaL =
        safeNumber(
            rl.angularSpeed,
            0.0
        )

    local omegaR =
        safeNumber(
            rr.angularSpeed,
            0.0
        )

    return omegaL, omegaR
end

local function stabilizeLowSpeedOmega(speedKmh, omegaL, omegaR)
    debug.rawOmegaL =
        omegaL

    debug.rawOmegaR =
        omegaR

    local omegaSum =
        math.abs(
            omegaL
        )
        +
        math.abs(
            omegaR
        )

    if speedKmh < M.params.lowSpeedKmh
    and omegaSum < M.params.lowOmegaThreshold then
        return debug.omegaL, debug.omegaR
    end

    return omegaL, omegaR
end

--============================================================
-- Load / memory helpers
--============================================================

local function updateLoadState()
    state.loadRL =
        safeLoad(
            "ngp_dlt_load_2",
            0.0
        )

    state.loadRR =
        safeLoad(
            "ngp_dlt_load_3",
            0.0
        )

    state.loadDiff =
        math.abs(
            state.loadRL
            -
            state.loadRR
        )
end

local function getRearMemory()
    local memRL =
        safeLoad(
            "ngp_rubber_memory_2",
            0.0
        )

    local memRR =
        safeLoad(
            "ngp_rubber_memory_3",
            0.0
        )

    return clamp(
        (
            memRL
            +
            memRR
        )
        *
        0.5,
        0.0,
        1.0
    )
end

--============================================================
-- Core LSD calculation
--============================================================

local function calculateBaseLock()
    local diffRatio =
        clamp(
            state.diff
            /
            M.params.diffForFullLock,
            0.0,
            1.0
        )

    return
        M.params.preloadLock
        +
        (
            1.0
            -
            M.params.preloadLock
        )
        *
        diffRatio
end

local function applyWeightDistribution(targetLock)
    local rearBias =
        safeLoad(
            "ngp_rear_bias",
            0.50
        )

    debug.rearBias =
        rearBias

    local weightLock =
        (
            rearBias
            -
            0.50
        )
        *
        M.params.rearBiasGain

    return
        targetLock
        *
        (
            1.0
            +
            weightLock
        )
end

local function applyLoadTransfer(targetLock)
    local loadRatio =
        clamp(
            state.loadDiff
            /
            M.params.loadDiffReference,
            0.0,
            1.0
        )

    return
        targetLock
        *
        (
            1.0
            -
            loadRatio
            *
            M.params.loadUnlockGain
        )
end

local function applyDriveTorque(targetLock)
    local driveTorque =
        safeLoad(
            "ngp_drive_torque",
            0.0
        )

    debug.driveTorque =
        driveTorque

    local torqueRatio =
        clamp(
            math.abs(
                driveTorque
            ),
            0.0,
            1.0
        )

    return
        targetLock
        *
        (
            0.60
            +
            torqueRatio
            *
            0.40
        )
end

local function applyRubberMemory(targetLock)
    local rearMemory =
        getRearMemory()

    debug.rearMemory =
        rearMemory

    return
        targetLock
        *
        (
            1.0
            -
            rearMemory
            *
            M.params.memoryUnlockGain
        )
end

local function applyPowerCoast(targetLock, gas, powerMode)
    if powerMode then
        return
            targetLock
            *
            (
                0.5
                +
                gas
                *
                0.5
            )
            *
            M.params.powerGain
    end

    return
        targetLock
        *
        M.params.coastGain
end

local function calculateTargetLock(car)
    local gas =
        safeNumber(
            car.gas,
            0.0
        )

    local brake =
        safeNumber(
            car.brake,
            0.0
        )

    local powerMode =
        gas > 0.05

    state.mode =
        powerMode
        and "POWER"
        or "COAST"

    local target =
        calculateBaseLock()

    target =
        applyWeightDistribution(
            target
        )

    target =
        applyLoadTransfer(
            target
        )

    target =
        applyDriveTorque(
            target
        )

    target =
        applyRubberMemory(
            target
        )

    target =
        applyPowerCoast(
            target,
            gas,
            powerMode
        )

    target =
        target
        +
        brake
        *
        M.params.brakeLockGain

    return clamp(
        target,
        0.0,
        1.0
    )
end

local function updateHeat(dt)
    local heatRate =
        state.diff
        *
        state.lockRatio
        *
        M.params.heatGain

    state.heat =
        state.heat
        *
        0.995
        +
        heatRate
        *
        dt

    state.heat =
        math.max(
            0.0,
            state.heat
        )
end

--============================================================
-- Export
--============================================================

local function exportState()
    ac.store(
        "ngp_lsd_lock",
        state.lockRatio
    )

    ac.store(
        "ngp_lsd_diff",
        state.diff
    )

    ac.store(
        "ngp_lsd_sdiff",
        state.signedDiff
    )

    ac.store(
        "ngp_lsd_heat",
        state.heat
    )

    ac.store(
        "ngp_lsd_mode",
        state.mode
    )

    ac.store(
        "ngp_lsd_target",
        state.targetLock
    )

    ac.store(
        "ngp_lsd_omega_l",
        debug.omegaL
    )

    ac.store(
        "ngp_lsd_omega_r",
        debug.omegaR
    )

    ac.store(
        "ngp_lsd_raw_omega_l",
        debug.rawOmegaL
    )

    ac.store(
        "ngp_lsd_raw_omega_r",
        debug.rawOmegaR
    )

    ac.store(
        "ngp_lsd_load_diff",
        state.loadDiff
    )
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    local car =
        ac.getCar(0)

    if not car or not car.wheels then
        return
    end

    local omegaL,
          omegaR =
        readRearWheelOmega(
            car
        )

    if omegaL == nil or omegaR == nil then
        return
    end

    local speedKmh =
        safeNumber(
            car.speedKmh,
            0.0
        )

    --------------------------------------------------------
    -- Low speed omega stabilization
    --------------------------------------------------------

    omegaL,
    omegaR =
        stabilizeLowSpeedOmega(
            speedKmh,
            omegaL,
            omegaR
        )

    debug.omegaL =
        omegaL

    debug.omegaR =
        omegaR

    --------------------------------------------------------
    -- Diff state
    --------------------------------------------------------

    state.signedDiff =
        omegaL
        -
        omegaR

    state.diff =
        math.abs(
            state.signedDiff
        )

    --------------------------------------------------------
    -- Load state
    --------------------------------------------------------

    updateLoadState()

    --------------------------------------------------------
    -- Target lock
    --------------------------------------------------------

    state.targetLock =
        calculateTargetLock(
            car
        )

    --------------------------------------------------------
    -- Lock response
    --------------------------------------------------------

    local tau =
        state.targetLock > state.lockRatio
        and M.params.tauLock
        or M.params.tauUnlock

    state.lockRatio =
        lowPass(
            state.lockRatio,
            state.targetLock,
            tau,
            dt
        )

    state.lockRatio =
        clamp(
            state.lockRatio,
            0.0,
            1.0
        )

    --------------------------------------------------------
    -- Heat
    --------------------------------------------------------

    updateHeat(
        dt
    )

    --------------------------------------------------------
    -- Export
    --------------------------------------------------------

    exportState()
end

--============================================================
-- Public API
--============================================================

function M.getLock()
    return state.lockRatio
end

function M.getTargetLock()
    return state.targetLock
end

function M.getDiff()
    return state.diff
end

function M.getSignedDiff()
    return state.signedDiff
end

function M.getHeat()
    return state.heat
end

function M.getMode()
    return state.mode
end

function M.debugStr()
    return string.format(
        "Lock %.1f%% Target %.1f%% Mode %s\n" ..
        "Diff %.3f Signed %.3f Heat %.1f\n" ..
        "OmegaL %.2f OmegaR %.2f LoadDiff %.0f",

        state.lockRatio
        *
        100.0,

        state.targetLock
        *
        100.0,

        state.mode,

        state.diff,
        state.signedDiff,
        state.heat,

        debug.omegaL,
        debug.omegaR,

        state.loadDiff
    )
end

return M