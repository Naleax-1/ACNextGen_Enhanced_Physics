---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- progressive_spring.lua
-- Phase 4.9
-- Nonlinear Suspension Spring
-- プログレッシブスプリング近似モデル
--============================================================

local M = {}

--============================================================
-- Parameters
--============================================================

M.params = {
    baseRate = 30000.0,

    progressiveRate = 90000.0,

    startTravel = 0.35,

    maxForce = 25000.0,

    tau = 0.050,
}

--============================================================
-- State
--============================================================

local state = {
    force = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    travel = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    rate = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },
}

M.debug = state

--============================================================
-- Utility
--============================================================

local function clamp(v, minValue, maxValue)
    if v < minValue then
        return minValue
    end

    if v > maxValue then
        return maxValue
    end

    return v
end

local function safeNumber(value, defaultValue)
    return tonumber(value) or defaultValue
end

local function lowPass(current, target, alpha)
    return
        current
        +
        (
            target
            -
            current
        )
        *
        alpha
end

--============================================================
-- Core
--============================================================

local function calculateSpringRate(absTravel)
    local rate =
        M.params.baseRate

    if absTravel <= M.params.startTravel then
        return rate
    end

    local range =
        1.0
        -
        M.params.startTravel

    if range <= 0.001 then
        return
            M.params.baseRate
            +
            M.params.progressiveRate
    end

    local progress =
        (
            absTravel
            -
            M.params.startTravel
        )
        /
        range

    progress =
        clamp(
            progress,
            0.0,
            1.0
        )

    rate =
        rate
        +
        progress
        *
        M.params.progressiveRate

    return rate
end

local function calculateSpringForce(travel, rate)
    local force =
        -travel
        *
        rate

    return clamp(
        force,
        -M.params.maxForce,
        M.params.maxForce
    )
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    local car =
        ac.getCar(0)

    if not car or not car.wheels then
        return
    end

    local alpha =
        dt
        /
        (
            M.params.tau
            +
            dt
        )

    for i = 0, 3 do
        local wheel =
            car.wheels[i]

        if wheel then
            ------------------------------------------------
            -- Suspension travel
            ------------------------------------------------

            local rawTravel =
                safeNumber(
                    wheel.suspensionTravel,
                    state.travel[i]
                )

            state.travel[i] =
                lowPass(
                    state.travel[i],
                    rawTravel,
                    alpha
                )

            ------------------------------------------------
            -- Progressive rate
            ------------------------------------------------

            local absTravel =
                math.abs(
                    state.travel[i]
                )

            state.rate[i] =
                calculateSpringRate(
                    absTravel
                )

            ------------------------------------------------
            -- Spring force
            ------------------------------------------------

            state.force[i] =
                calculateSpringForce(
                    state.travel[i],
                    state.rate[i]
                )

            ------------------------------------------------
            -- Export
            ------------------------------------------------

            ac.store(
                "ngp_progressive_spring_" .. i,
                state.force[i]
            )

            ac.store(
                "ngp_progressive_rate_" .. i,
                state.rate[i]
            )
        else
            state.force[i] = 0.0
            state.rate[i]  = M.params.baseRate

            ac.store(
                "ngp_progressive_spring_" .. i,
                state.force[i]
            )

            ac.store(
                "ngp_progressive_rate_" .. i,
                state.rate[i]
            )
        end
    end
end

--============================================================
-- Public API
--============================================================

function M.getForce(i)
    return state.force[i] or 0.0
end

function M.getTravel(i)
    return state.travel[i] or 0.0
end

function M.getRate(i)
    return state.rate[i] or M.params.baseRate
end

function M.debugStr()
    return string.format(
        "Spring FL:%+.0f FR:%+.0f RL:%+.0f RR:%+.0f\n" ..
        "Rate   FL:%.0f FR:%.0f RL:%.0f RR:%.0f",

        state.force[0],
        state.force[1],
        state.force[2],
        state.force[3],

        state.rate[0],
        state.rate[1],
        state.rate[2],
        state.rate[3]
    )
end

return M
