---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- chassis_flex.lua
-- Phase 8
-- Virtual Chassis Compliance
-- 仮想シャシーたわみモデル
--============================================================

local M = {}

--============================================================
-- Parameters
--============================================================

M.params = {
    flexTau = 0.120,

    frontCompliance = 0.65,
    rearCompliance  = 0.35,

    bodyFrontMix = 0.70,
    bodyRearMix  = 0.30,
}

--============================================================
-- State
--============================================================

local state = {
    steer = 0.0,

    front = 0.0,
    rear  = 0.0,

    bodySteer = 0.0,
}

M.debug = {
    rawSteer = 0.0,

    frontSteer = 0.0,
    rearSteer  = 0.0,

    bodySteer = 0.0,

    delay = 0.0,
}

--============================================================
-- Utility
--============================================================

local function lowPass(current, target, alpha)
    return current + (target - current) * alpha
end

local function safeNumber(value, defaultValue)
    return tonumber(value) or defaultValue
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    local car =
        ac.getCar(0)

    if not car then
        return
    end

    local steer =
        safeNumber(
            car.steer,
            0.0
        )

    state.steer =
        steer

    local alpha =
        dt /
        (
            M.params.flexTau
            +
            dt
        )

    --------------------------------------------------------
    -- Front chassis compliance
    --------------------------------------------------------

    local frontAlpha =
        alpha
        *
        M.params.frontCompliance

    state.front =
        lowPass(
            state.front,
            steer,
            frontAlpha
        )

    --------------------------------------------------------
    -- Rear chassis compliance
    --------------------------------------------------------

    local rearAlpha =
        alpha
        *
        M.params.rearCompliance

    state.rear =
        lowPass(
            state.rear,
            state.front,
            rearAlpha
        )

    --------------------------------------------------------
    -- Body steer synthesis
    --------------------------------------------------------

    state.bodySteer =
        state.front
        *
        M.params.bodyFrontMix
        +
        state.rear
        *
        M.params.bodyRearMix

    --------------------------------------------------------
    -- Debug
    --------------------------------------------------------

    M.debug.rawSteer =
        steer

    M.debug.frontSteer =
        state.front

    M.debug.rearSteer =
        state.rear

    M.debug.bodySteer =
        state.bodySteer

    M.debug.delay =
        steer
        -
        state.bodySteer

    --------------------------------------------------------
    -- Export
    --------------------------------------------------------

    ac.store(
        "ngp_body_steer",
        state.bodySteer
    )

    ac.store(
        "ngp_chassis_flex_delay",
        M.debug.delay
    )
end

--============================================================
-- Public API
--============================================================

function M.getSteer()
    return state.bodySteer
end

function M.getDelay()
    return M.debug.delay
end

function M.debugStr()
    return string.format(
        "Input %.3f\n" ..
        "Front %.3f Rear %.3f\n" ..
        "Body %.3f Flex %.3f",

        M.debug.rawSteer,

        M.debug.frontSteer,
        M.debug.rearSteer,

        M.debug.bodySteer,
        M.debug.delay
    )
end

return M
