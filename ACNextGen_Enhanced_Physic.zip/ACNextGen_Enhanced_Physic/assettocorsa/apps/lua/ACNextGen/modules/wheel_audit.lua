---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- wheel_audit.lua
-- Small UI helper for AC wheel API inspection
-- Strict-struct safe version
--============================================================

local M = {}

local WHEEL_NAME = {
    [0] = "FL",
    [1] = "FR",
    [2] = "RL",
    [3] = "RR",
}

--============================================================
-- Utility
--============================================================

local function num(value, defaultValue)
    return tonumber(value) or defaultValue or 0.0
end

local function drawLine(line)
    if ui and ui.text then
        ui.text(line)
    end
end

------------------------------------------------------------
-- IMPORTANT:
-- AC/CSP wheel object can be strict-struct.
-- Accessing a missing member directly can crash the app.
------------------------------------------------------------

local function safeField(obj, key, defaultValue)
    if not obj then
        return defaultValue
    end

    local ok, value =
        pcall(
            function()
                return obj[key]
            end
        )

    if not ok or value == nil then
        return defaultValue
    end

    return value
end

local function fmt(value, format)
    if value == nil then
        return "NIL"
    end

    return string.format(
        format,
        num(value, 0.0)
    )
end

local function getWheel(car, index)
    if not car then
        return nil
    end

    local wheels =
        safeField(
            car,
            "wheels",
            nil
        )

    if not wheels then
        return nil
    end

    local ok, wheel =
        pcall(
            function()
                return wheels[index]
            end
        )

    if not ok then
        return nil
    end

    return wheel
end

--============================================================
-- Draw
--============================================================

function M.draw(car)
    if not car then
        drawLine("Wheel audit: car NIL")
        return
    end

    local wheels =
        safeField(
            car,
            "wheels",
            nil
        )

    if not wheels then
        drawLine("Wheel audit: wheels NIL")
        return
    end

    drawLine("=== WHEEL AUDIT ===")

    for i = 0, 3 do
        local wheel =
            getWheel(
                car,
                i
            )

        local name =
            WHEEL_NAME[i]
            or tostring(i)

        if not wheel then
            drawLine(
                name .. " NIL"
            )
        else
            ------------------------------------------------
            -- Safe fields
            ------------------------------------------------

            local load =
                safeField(
                    wheel,
                    "load",
                    nil
                )

            local slipRatio =
                safeField(
                    wheel,
                    "slipRatio",
                    nil
                )

            local slipAngle =
                safeField(
                    wheel,
                    "slipAngle",
                    nil
                )

            local angularSpeed =
                safeField(
                    wheel,
                    "angularSpeed",
                    nil
                )

            local suspensionTravel =
                safeField(
                    wheel,
                    "suspensionTravel",
                    nil
                )

            local suspensionLength =
                safeField(
                    wheel,
                    "suspensionLength",
                    nil
                )

            local surfaceGrip =
                safeField(
                    wheel,
                    "surfaceGrip",
                    nil
                )

            local tyreRadius =
                safeField(
                    wheel,
                    "tyreRadius",
                    nil
                )

            local tyreWidth =
                safeField(
                    wheel,
                    "tyreWidth",
                    nil
                )

            local tyrePressure =
                safeField(
                    wheel,
                    "tyrePressure",
                    nil
                )

            ------------------------------------------------
            -- Display
            ------------------------------------------------

            drawLine(
                string.format(
                    "%s load %s slipR %s slipA %s omega %s",
                    name,
                    fmt(load, "%.0f"),
                    fmt(slipRatio, "%.4f"),
                    fmt(slipAngle, "%.4f"),
                    fmt(angularSpeed, "%.2f")
                )
            )

            drawLine(
                string.format(
                    "   suspTravel %s suspLength %s",
                    fmt(suspensionTravel, "%.4f"),
                    fmt(suspensionLength, "%.4f")
                )
            )

            drawLine(
                string.format(
                    "   grip %s radius %s width %s pressure %s",
                    fmt(surfaceGrip, "%.3f"),
                    fmt(tyreRadius, "%.3f"),
                    fmt(tyreWidth, "%.3f"),
                    fmt(tyrePressure, "%.2f")
                )
            )
        end
    end
end

--============================================================
-- Debug string
--============================================================

function M.debugStr(car)
    if not car then
        return "Wheel audit: car NIL"
    end

    local wheels =
        safeField(
            car,
            "wheels",
            nil
        )

    if not wheels then
        return "Wheel audit: wheels NIL"
    end

    local out = {}

    for i = 0, 3 do
        local wheel =
            getWheel(
                car,
                i
            )

        local name =
            WHEEL_NAME[i]
            or tostring(i)

        if wheel then
            local load =
                safeField(
                    wheel,
                    "load",
                    nil
                )

            local slipRatio =
                safeField(
                    wheel,
                    "slipRatio",
                    nil
                )

            local slipAngle =
                safeField(
                    wheel,
                    "slipAngle",
                    nil
                )

            local angularSpeed =
                safeField(
                    wheel,
                    "angularSpeed",
                    nil
                )

            out[#out + 1] =
                string.format(
                    "%s L:%s SR:%s SA:%s W:%s",
                    name,
                    fmt(load, "%.0f"),
                    fmt(slipRatio, "%.3f"),
                    fmt(slipAngle, "%.3f"),
                    fmt(angularSpeed, "%.2f")
                )
        else
            out[#out + 1] =
                name .. " NIL"
        end
    end

    return table.concat(
        out,
        "\n"
    )
end

return M
