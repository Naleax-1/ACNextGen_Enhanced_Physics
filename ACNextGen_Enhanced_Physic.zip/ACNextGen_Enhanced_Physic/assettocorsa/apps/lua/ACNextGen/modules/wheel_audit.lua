---@diagnostic disable: undefined-global

--============================================================
-- ACNextGen
-- wheel_audit.lua
-- Small UI helper for AC wheel API inspection
-- V1.1.5 stable strict-struct version
--============================================================

local M = {}

local WHEEL_NAME = {
    [0] = "FL",
    [1] = "FR",
    [2] = "RL",
    [3] = "RR",
}

local FIELD_GROUPS = {
    load = {
        "load",
        "normalLoad",
        "wheelLoad",
        "verticalLoad",
        "fZ",
    },

    slip = {
        "slipRatio",
        "slipAngle",
    },

    rotation = {
        "angularSpeed",
        "omega",
    },

    suspension = {
        "suspensionTravel",
        "suspensionTravelM",
        "suspensionLength",
        "travel",
        "damperTravel",
        "suspensionPosition",
        "rideHeight",
        "compression",
    },

    surface = {
        "surfaceGrip",
        "surfaceType",
    },

    shape = {
        "tyreRadius",
        "tireRadius",
        "radius",
        "tyreWidth",
        "tireWidth",
        "width",
        "tyrePressure",
        "tirePressure",
        "pressure",
    },

    temperature = {
        "brakeTemperature",
        "discTemperature",
        "tyreCoreTemperature",
        "tireCoreTemperature",
        "tyreTemperature",
        "tireTemperature",
        "coreTemperature",
        "surfaceTemperature",
    },

    force = {
        "fx",
        "fy",
        "fz",
        "mz",
        "loadForce",
    },
}

local ALL_FIELDS = {}
do
    local seen = {}
    for _, fields in pairs(FIELD_GROUPS) do
        for _, key in ipairs(fields) do
            if not seen[key] then
                seen[key] = true
                ALL_FIELDS[#ALL_FIELDS + 1] = key
            end
        end
    end
end

local state = {
    status = "INIT",
    updateCount = 0,
    drawCount = 0,

    carValid = false,
    wheelsValid = false,
    storeOnly = false,

    wheelExists = {
        [0] = false,
        [1] = false,
        [2] = false,
        [3] = false,
    },

    wheel = {},
    available = {},

    availableCount = { [0] = 0, [1] = 0, [2] = 0, [3] = 0 },
    strictReadErrors = { [0] = 0, [1] = 0, [2] = 0, [3] = 0 },

    loadSource = { [0] = "INIT", [1] = "INIT", [2] = "INIT", [3] = "INIT" },
    slipSource = { [0] = "INIT", [1] = "INIT", [2] = "INIT", [3] = "INIT" },
    omegaSource = { [0] = "INIT", [1] = "INIT", [2] = "INIT", [3] = "INIT" },

    avgLoad = 0.0,
    maxLoad = 0.0,
    avgSlipRatio = 0.0,
    avgSlipAngle = 0.0,
    avgAbsOmega = 0.0,

    debugStoreTimer = 999.0,
    debugStoreNow = true,
}

for i = 0, 3 do
    state.wheel[i] = {
        load = nil,
        normalLoad = nil,
        wheelLoad = nil,
        verticalLoad = nil,
        fZ = nil,

        slipRatio = nil,
        slipAngle = nil,

        angularSpeed = nil,
        omega = nil,

        suspensionTravel = nil,
        suspensionTravelM = nil,
        suspensionLength = nil,
        travel = nil,
        damperTravel = nil,
        suspensionPosition = nil,
        rideHeight = nil,
        compression = nil,

        surfaceGrip = nil,
        surfaceType = nil,

        tyreRadius = nil,
        tireRadius = nil,
        radius = nil,

        tyreWidth = nil,
        tireWidth = nil,
        width = nil,

        tyrePressure = nil,
        tirePressure = nil,
        pressure = nil,

        brakeTemperature = nil,
        discTemperature = nil,
        tyreCoreTemperature = nil,
        tireCoreTemperature = nil,
        tyreTemperature = nil,
        tireTemperature = nil,
        coreTemperature = nil,
        surfaceTemperature = nil,

        fx = nil,
        fy = nil,
        fz = nil,
        mz = nil,
        loadForce = nil,

        resolvedLoad = 0.0,
        resolvedSlipRatio = 0.0,
        resolvedSlipAngle = 0.0,
        resolvedOmega = 0.0,
        resolvedSuspensionTravel = 0.0,
        resolvedTyreRadius = 0.0,
        resolvedTyreWidth = 0.0,
        resolvedPressure = 0.0,
        resolvedBrakeTemp = 0.0,
        resolvedTyreTemp = 0.0,
    }

    state.available[i] = {}
    for _, key in ipairs(ALL_FIELDS) do
        state.available[i][key] = false
    end
end

M.state = state
M.debug = state

M.params = {
    debugStoreInterval = 0.25,
}

--============================================================
-- Utility
--============================================================

local function num(value, defaultValue)
    local n = tonumber(value)

    if n == nil or n ~= n or n == math.huge or n == -math.huge then
        if defaultValue == nil then
            return nil
        end

        return defaultValue
    end

    return n
end

local function bool01(value)
    return value and 1 or 0
end

local function abs(value)
    value = num(value, 0.0)

    if value < 0.0 then
        return -value
    end

    return value
end

local function safeCall(fn, fallback)
    local ok, value = pcall(fn)

    if not ok then
        return fallback, false
    end

    if value == nil then
        return fallback, true
    end

    return value, true
end

local function safeStore(key, value)
    if not ac or not ac.store then
        return
    end

    pcall(function()
        ac.store(key, value)
    end)
end

local function safeLoadRaw(key)
    if not ac or not ac.load then
        return nil
    end

    local ok, value = pcall(function()
        return ac.load(key)
    end)

    if not ok then
        return nil
    end

    return value
end

local function safeLoadNumber(key, defaultValue)
    local value = safeLoadRaw(key)

    if value == nil then
        return defaultValue
    end

    return num(value, defaultValue)
end

local function safeField(obj, key, defaultValue, index)
    if not obj then
        return defaultValue, false
    end

    local ok, value = pcall(function()
        return obj[key]
    end)

    if not ok then
        if index ~= nil then
            state.strictReadErrors[index] =
                (state.strictReadErrors[index] or 0) + 1
        end

        return defaultValue, false
    end

    if value == nil then
        return defaultValue, true
    end

    return value, true
end

local function hasField(obj, key, index)
    if not obj then
        return false
    end

    local ok, value = pcall(function()
        return obj[key]
    end)

    if not ok then
        if index ~= nil then
            state.strictReadErrors[index] =
                (state.strictReadErrors[index] or 0) + 1
        end

        return false
    end

    return value ~= nil
end

local function fmt(value, format)
    if value == nil then
        return "NIL"
    end

    return string.format(format, num(value, 0.0))
end

local function drawLine(line)
    if ui and ui.text then
        ui.text(tostring(line))
    end
end

local function updateDebugGate(dt)
    state.debugStoreTimer =
        (state.debugStoreTimer or 0.0)
        +
        (dt or 0.0)

    if state.debugStoreTimer >= (M.params.debugStoreInterval or 0.25) then
        state.debugStoreTimer = 0.0
        state.debugStoreNow = true
    else
        state.debugStoreNow = false
    end
end

local function safeGetCar(car)
    if car ~= nil then
        return car
    end

    if not ac or not ac.getCar then
        return nil
    end

    local value = safeCall(function()
        return ac.getCar(0)
    end, nil)

    return value
end

local function getWheels(car)
    if not car then
        return nil
    end

    local wheels = safeField(car, "wheels", nil)

    return wheels
end

local function getWheelFromWheels(wheels, index)
    if not wheels then
        return nil
    end

    local wheel = safeCall(function()
        return wheels[index]
    end, nil)

    if wheel ~= nil then
        return wheel
    end

    wheel = safeCall(function()
        return wheels[index + 1]
    end, nil)

    return wheel
end

local function getWheel(car, index)
    local wheels = getWheels(car)
    return getWheelFromWheels(wheels, index)
end

local function clearWheel(index)
    state.wheelExists[index] = false

    local w = state.wheel[index]

    for key, _ in pairs(w) do
        if key:sub(1, 8) == "resolved" then
            w[key] = 0.0
        else
            w[key] = nil
        end
    end

    local a = state.available[index]
    for key, _ in pairs(a) do
        a[key] = false
    end

    state.availableCount[index] = 0
    state.loadSource[index] = "NIL"
    state.slipSource[index] = "NIL"
    state.omegaSource[index] = "NIL"
end

--============================================================
-- Field reading
--============================================================

local function readFieldSet(wheel, index)
    local w = state.wheel[index]

    for _, key in ipairs(ALL_FIELDS) do
        w[key] = safeField(wheel, key, nil, index)
    end
end

local function updateAvailability(wheel, index)
    local a = state.available[index]
    local count = 0

    for _, key in ipairs(ALL_FIELDS) do
        local ok = hasField(wheel, key, index)
        a[key] = ok

        if ok then
            count = count + 1
        end
    end

    state.availableCount[index] = count
end

local function firstNumber(w, keys)
    for _, key in ipairs(keys) do
        local value = num(w[key], nil)

        if value ~= nil then
            return value, key
        end
    end

    return nil, nil
end

local function loadFromStores(index)
    local keys = {
        "ngp_wheel_load_" .. index,
        "ngp_load_wheel_" .. index,
        "ngp_tire_load_" .. index,
        "ngp_tire_state_load_" .. index,
        "ngp_contact_load_" .. index,
        "ngp_tire_force_load_" .. index,
    }

    for _, key in ipairs(keys) do
        local value = safeLoadNumber(key, nil)

        if value ~= nil then
            return value, key
        end
    end

    local dlt = safeLoadNumber("ngp_dlt_load_" .. index, nil)

    if dlt ~= nil then
        return 3000.0 + dlt, "ngp_dlt_load_" .. index
    end

    return nil, nil
end

local function slipFromStores(index)
    local slipRatio =
        safeLoadNumber("ngp_tire_slip_ratio_" .. index, nil)
        or
        safeLoadNumber("ngp_slip_ratio_" .. index, nil)
        or
        safeLoadNumber("ngp_filtered_slip_ratio_" .. index, nil)

    local slipAngle =
        safeLoadNumber("ngp_tire_slip_angle_" .. index, nil)
        or
        safeLoadNumber("ngp_slip_angle_" .. index, nil)
        or
        safeLoadNumber("ngp_filtered_slip_angle_" .. index, nil)

    return slipRatio, slipAngle
end

local function omegaFromStores(index)
    return
        safeLoadNumber("ngp_wheel_omega_" .. index, nil)
        or
        safeLoadNumber("ngp_hub_omega_" .. index, nil)
        or
        safeLoadNumber("ngp_diff_omega_" .. index, nil)
end

local function resolveWheel(index)
    local w = state.wheel[index]

    local load, loadSource = firstNumber(w, {
        "load",
        "normalLoad",
        "wheelLoad",
        "verticalLoad",
        "fZ",
        "fz",
        "loadForce",
    })

    if load == nil then
        load, loadSource = loadFromStores(index)
    end

    if load == nil then
        load = 0.0
        loadSource = "NONE"
    end

    local slipRatio, slipRatioSource =
        firstNumber(w, { "slipRatio" })

    local slipAngle, slipAngleSource =
        firstNumber(w, { "slipAngle" })

    if slipRatio == nil or slipAngle == nil then
        local storeSR, storeSA = slipFromStores(index)

        if slipRatio == nil and storeSR ~= nil then
            slipRatio = storeSR
            slipRatioSource = "STORE"
        end

        if slipAngle == nil and storeSA ~= nil then
            slipAngle = storeSA
            slipAngleSource = "STORE"
        end
    end

    local omega, omegaSource =
        firstNumber(w, { "angularSpeed", "omega" })

    if omega == nil then
        omega = omegaFromStores(index)
        if omega ~= nil then
            omegaSource = "STORE"
        end
    end

    local suspensionTravel =
        firstNumber(w, {
            "suspensionTravel",
            "suspensionTravelM",
            "travel",
            "damperTravel",
            "suspensionPosition",
            "compression",
        })

    local tyreRadius =
        firstNumber(w, {
            "tyreRadius",
            "tireRadius",
            "radius",
        })

    local tyreWidth =
        firstNumber(w, {
            "tyreWidth",
            "tireWidth",
            "width",
        })

    local pressure =
        firstNumber(w, {
            "tyrePressure",
            "tirePressure",
            "pressure",
        })

    local brakeTemp =
        firstNumber(w, {
            "brakeTemperature",
            "discTemperature",
        })

    local tyreTemp =
        firstNumber(w, {
            "tyreCoreTemperature",
            "tireCoreTemperature",
            "tyreTemperature",
            "tireTemperature",
            "coreTemperature",
            "surfaceTemperature",
        })

    w.resolvedLoad = num(load, 0.0)
    w.resolvedSlipRatio = num(slipRatio, 0.0)
    w.resolvedSlipAngle = num(slipAngle, 0.0)
    w.resolvedOmega = num(omega, 0.0)
    w.resolvedSuspensionTravel = num(suspensionTravel, 0.0)
    w.resolvedTyreRadius = num(tyreRadius, 0.0)
    w.resolvedTyreWidth = num(tyreWidth, 0.0)
    w.resolvedPressure = num(pressure, 0.0)
    w.resolvedBrakeTemp = num(brakeTemp, 0.0)
    w.resolvedTyreTemp = num(tyreTemp, 0.0)

    state.loadSource[index] = loadSource or "NONE"
    state.slipSource[index] = slipRatioSource or slipAngleSource or "NONE"
    state.omegaSource[index] = omegaSource or "NONE"
end

local function updateWheel(index, wheel)
    if not wheel then
        clearWheel(index)
        return
    end

    state.wheelExists[index] = true

    readFieldSet(wheel, index)
    updateAvailability(wheel, index)
    resolveWheel(index)
end

local function updateSummary()
    local sumLoad = 0.0
    local maxLoad = 0.0
    local sumSlipRatio = 0.0
    local sumSlipAngle = 0.0
    local sumOmega = 0.0
    local count = 0

    for i = 0, 3 do
        local w = state.wheel[i]

        if state.wheelExists[i] then
            count = count + 1
        end

        local load = w.resolvedLoad or 0.0

        sumLoad = sumLoad + load
        maxLoad = math.max(maxLoad, load)
        sumSlipRatio = sumSlipRatio + abs(w.resolvedSlipRatio or 0.0)
        sumSlipAngle = sumSlipAngle + abs(w.resolvedSlipAngle or 0.0)
        sumOmega = sumOmega + abs(w.resolvedOmega or 0.0)
    end

    state.avgLoad = sumLoad * 0.25
    state.maxLoad = maxLoad
    state.avgSlipRatio = sumSlipRatio * 0.25
    state.avgSlipAngle = sumSlipAngle * 0.25
    state.avgAbsOmega = sumOmega * 0.25
    state.activeWheelCount = count
end

--============================================================
-- Export
--============================================================

local function exportAvailability(index)
    if not state.debugStoreNow then
        return
    end

    local a = state.available[index]

    for _, key in ipairs(ALL_FIELDS) do
        safeStore(
            "ngp_wheel_audit_has_" .. key .. "_" .. index,
            bool01(a[key])
        )
    end
end

local function exportWheel(index)
    local w = state.wheel[index]

    safeStore("ngp_wheel_audit_exists_" .. index, bool01(state.wheelExists[index]))

    safeStore("ngp_wheel_audit_load_" .. index, num(w.load, 0.0))
    safeStore("ngp_wheel_audit_normal_load_" .. index, num(w.normalLoad, 0.0))
    safeStore("ngp_wheel_audit_wheel_load_" .. index, num(w.wheelLoad, 0.0))

    safeStore("ngp_wheel_audit_slip_ratio_" .. index, num(w.slipRatio, 0.0))
    safeStore("ngp_wheel_audit_slip_angle_" .. index, num(w.slipAngle, 0.0))
    safeStore("ngp_wheel_audit_angular_speed_" .. index, num(w.angularSpeed or w.omega, 0.0))

    safeStore("ngp_wheel_audit_suspension_travel_" .. index, num(w.suspensionTravel or w.suspensionTravelM or w.travel or w.damperTravel, 0.0))
    safeStore("ngp_wheel_audit_suspension_length_" .. index, num(w.suspensionLength, 0.0))
    safeStore("ngp_wheel_audit_surface_grip_" .. index, num(w.surfaceGrip, 0.0))
    safeStore("ngp_wheel_audit_tyre_pressure_" .. index, num(w.tyrePressure or w.tirePressure or w.pressure, 0.0))

    safeStore("ngp_wheel_audit_resolved_load_" .. index, w.resolvedLoad or 0.0)
    safeStore("ngp_wheel_audit_resolved_slip_ratio_" .. index, w.resolvedSlipRatio or 0.0)
    safeStore("ngp_wheel_audit_resolved_slip_angle_" .. index, w.resolvedSlipAngle or 0.0)
    safeStore("ngp_wheel_audit_resolved_omega_" .. index, w.resolvedOmega or 0.0)
    safeStore("ngp_wheel_audit_resolved_travel_" .. index, w.resolvedSuspensionTravel or 0.0)
    safeStore("ngp_wheel_audit_resolved_radius_" .. index, w.resolvedTyreRadius or 0.0)
    safeStore("ngp_wheel_audit_resolved_width_" .. index, w.resolvedTyreWidth or 0.0)
    safeStore("ngp_wheel_audit_resolved_brake_temp_" .. index, w.resolvedBrakeTemp or 0.0)
    safeStore("ngp_wheel_audit_resolved_tire_temp_" .. index, w.resolvedTyreTemp or 0.0)

    safeStore("ngp_wa_exists_" .. index, bool01(state.wheelExists[index]))
    safeStore("ngp_wa_load_" .. index, w.resolvedLoad or 0.0)
    safeStore("ngp_wa_slip_ratio_" .. index, w.resolvedSlipRatio or 0.0)
    safeStore("ngp_wa_slip_angle_" .. index, w.resolvedSlipAngle or 0.0)
    safeStore("ngp_wa_omega_" .. index, w.resolvedOmega or 0.0)

    if state.debugStoreNow then
        safeStore("ngp_wheel_audit_available_count_" .. index, state.availableCount[index] or 0)
        safeStore("ngp_wheel_audit_strict_errors_" .. index, state.strictReadErrors[index] or 0)
        safeStore("ngp_wheel_audit_load_source_" .. index, state.loadSource[index] or "NONE")
        safeStore("ngp_wheel_audit_slip_source_" .. index, state.slipSource[index] or "NONE")
        safeStore("ngp_wheel_audit_omega_source_" .. index, state.omegaSource[index] or "NONE")
    end

    exportAvailability(index)
end

local function exportGlobal()
    safeStore("ngp_wheel_audit_status", state.status or "UNKNOWN")
    safeStore("ngp_wheel_audit_update_count", state.updateCount or 0)
    safeStore("ngp_wheel_audit_draw_count", state.drawCount or 0)

    safeStore("ngp_wheel_audit_car_valid", bool01(state.carValid))
    safeStore("ngp_wheel_audit_wheels_valid", bool01(state.wheelsValid))
    safeStore("ngp_wheel_audit_store_only", bool01(state.storeOnly))

    safeStore("ngp_wheel_audit_avg_load", state.avgLoad or 0.0)
    safeStore("ngp_wheel_audit_max_load", state.maxLoad or 0.0)
    safeStore("ngp_wheel_audit_avg_slip_ratio", state.avgSlipRatio or 0.0)
    safeStore("ngp_wheel_audit_avg_slip_angle", state.avgSlipAngle or 0.0)
    safeStore("ngp_wheel_audit_avg_abs_omega", state.avgAbsOmega or 0.0)
    safeStore("ngp_wheel_audit_active_wheel_count", state.activeWheelCount or 0)

    safeStore("ngp_wa_status", state.status or "UNKNOWN")
    safeStore("ngp_wa_count", state.updateCount or 0)
    safeStore("ngp_wa_wheels_valid", bool01(state.wheelsValid))
    safeStore("ngp_wa_avg_load", state.avgLoad or 0.0)
end

local function exportState()
    for i = 0, 3 do
        exportWheel(i)
    end

    exportGlobal()
end

--============================================================
-- Update
--============================================================

function M.init()
    state.status = "INIT"
    exportState()
end

function M.update(dt, car, runtime)
    state.updateCount = (state.updateCount or 0) + 1

    dt = num(dt, 0.0)

    if dt <= 0.0 then
        state.status = "BAD DT"
        updateSummary()
        exportState()
        return
    end

    updateDebugGate(dt)

    car = safeGetCar(car)

    if not car then
        state.status = "NO CAR"
        state.carValid = false
        state.wheelsValid = false
        state.storeOnly = true

        for i = 0, 3 do
            clearWheel(i)
            resolveWheel(i)
        end

        updateSummary()
        exportState()
        return
    end

    state.carValid = true

    local wheels = getWheels(car)

    if not wheels then
        state.status = "NO WHEELS"
        state.wheelsValid = false
        state.storeOnly = true

        for i = 0, 3 do
            clearWheel(i)
            resolveWheel(i)
        end

        updateSummary()
        exportState()
        return
    end

    state.wheelsValid = true
    state.storeOnly = false
    state.status = "RUNNING"

    for i = 0, 3 do
        local wheel = getWheelFromWheels(wheels, i)
        updateWheel(i, wheel)
    end

    updateSummary()
    exportState()
end

--============================================================
-- Draw
--============================================================

local function drawWheel(index)
    local name = WHEEL_NAME[index] or tostring(index)
    local w = state.wheel[index]

    if not state.wheelExists[index] then
        drawLine(name .. " NIL")
        return
    end

    drawLine(string.format(
        "%s load %s nLoad %s wLoad %s src %s",
        name,
        fmt(w.load, "%.0f"),
        fmt(w.normalLoad, "%.0f"),
        fmt(w.wheelLoad, "%.0f"),
        tostring(state.loadSource[index] or "NIL")
    ))

    drawLine(string.format(
        "   slipR %s slipA %s omega %s",
        fmt(w.slipRatio, "%.4f"),
        fmt(w.slipAngle, "%.4f"),
        fmt(w.angularSpeed or w.omega, "%.2f")
    ))

    drawLine(string.format(
        "   travel %s/%s damper %s length %s",
        fmt(w.suspensionTravel, "%.4f"),
        fmt(w.suspensionTravelM, "%.4f"),
        fmt(w.damperTravel, "%.4f"),
        fmt(w.suspensionLength, "%.4f")
    ))

    drawLine(string.format(
        "   grip %s radius %s/%s width %s/%s pressure %s/%s",
        fmt(w.surfaceGrip, "%.3f"),
        fmt(w.tyreRadius, "%.3f"),
        fmt(w.tireRadius, "%.3f"),
        fmt(w.tyreWidth, "%.3f"),
        fmt(w.tireWidth, "%.3f"),
        fmt(w.tyrePressure, "%.2f"),
        fmt(w.tirePressure, "%.2f")
    ))

    drawLine(string.format(
        "   brakeT %s discT %s tireT %s/%s fields %.0f err %.0f",
        fmt(w.brakeTemperature, "%.1f"),
        fmt(w.discTemperature, "%.1f"),
        fmt(w.tyreCoreTemperature or w.tyreTemperature, "%.1f"),
        fmt(w.tireCoreTemperature or w.tireTemperature, "%.1f"),
        state.availableCount[index] or 0,
        state.strictReadErrors[index] or 0
    ))
end

function M.draw(car)
    state.drawCount = (state.drawCount or 0) + 1

    car = safeGetCar(car)

    M.update(0.016, car)

    if not car then
        drawLine("Wheel audit: car NIL")
        return
    end

    if not getWheels(car) then
        drawLine("Wheel audit: wheels NIL")
        return
    end

    drawLine("=== WHEEL AUDIT ===")
    drawLine(string.format(
        "Status %s / Count %.0f / Wheels %s / AvgLoad %.0f",
        tostring(state.status),
        state.updateCount or 0,
        state.wheelsValid and "OK" or "NIL",
        state.avgLoad or 0.0
    ))

    for i = 0, 3 do
        drawWheel(i)
    end
end

function M.drawUI(car)
    M.draw(car)
end

--============================================================
-- Public API
--============================================================

function M.getState()
    return state
end

function M.getWheel(index)
    return state.wheel[index]
end

function M.getAvailable(index)
    return state.available[index]
end

function M.hasWheel(index)
    return state.wheelExists[index] and true or false
end

function M.hasField(index, key)
    local a = state.available[index]

    if not a then
        return false
    end

    return a[key] and true or false
end

function M.getResolvedLoad(index)
    local w = state.wheel[index]

    if not w then
        return 0.0
    end

    return w.resolvedLoad or 0.0
end

function M.getResolvedSlip(index)
    local w = state.wheel[index]

    if not w then
        return 0.0, 0.0
    end

    return w.resolvedSlipAngle or 0.0, w.resolvedSlipRatio or 0.0
end

function M.debugStr(car)
    if car ~= false then
        local safeCar = safeGetCar(car)
        if safeCar then
            M.update(0.016, safeCar)
        end
    end

    if not state.carValid then
        return "Wheel audit: car NIL"
    end

    if not state.wheelsValid then
        return "Wheel audit: wheels NIL"
    end

    local out = {}

    out[#out + 1] = string.format(
        "Status %s / Count %.0f / Wheels %s / AvgLoad %.0f MaxLoad %.0f",
        tostring(state.status),
        state.updateCount or 0,
        state.wheelsValid and "OK" or "NIL",
        state.avgLoad or 0.0,
        state.maxLoad or 0.0
    )

    for i = 0, 3 do
        local name = WHEEL_NAME[i] or tostring(i)
        local w = state.wheel[i]

        if state.wheelExists[i] then
            out[#out + 1] = string.format(
                "%s L:%s NL:%s SR:%s SA:%s W:%s F:%d E:%d",
                name,
                fmt(w.load, "%.0f"),
                fmt(w.normalLoad, "%.0f"),
                fmt(w.slipRatio, "%.3f"),
                fmt(w.slipAngle, "%.3f"),
                fmt(w.angularSpeed or w.omega, "%.2f"),
                state.availableCount[i] or 0,
                state.strictReadErrors[i] or 0
            )
        else
            out[#out + 1] = name .. " NIL"
        end
    end

    return table.concat(out, "\n")
end

return M
