---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- tire_contact.lua
-- Phase 1.5
-- Tire Contact Patch Model
-- タイヤ接地面・接地グリップ補正モデル
--============================================================

local M = {}

--============================================================
-- Dependencies
--============================================================

local okTS, tireState =
    pcall(
        require,
        "modules/tire_state"
    )

local okLT, loadTransfer =
    pcall(
        require,
        "modules/load_transfer"
    )

--============================================================
-- Parameters
--============================================================

M.params = {
    nominalLoad = 3000.0,

    loadSensitivity = 0.25,

    patchLateralScale = 0.8,
    patchLongScale    = 0.6,

    patchInfluence = 0.12,

    minLoad = 100.0,

    defaultRadius   = 0.33,
    defaultWidth    = 0.225,
    defaultPressure = 1.8,

    minPressure = 0.5,

    minGripScale = 0.50,
    maxGripScale = 1.20,
}

--============================================================
-- Debug
--============================================================

M.debug = {
    area = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    gripScale = {
        [0] = 1.0,
        [1] = 1.0,
        [2] = 1.0,
        [3] = 1.0,
    },

    latCorr = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    longCorr = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    load = {
        [0] = 0.0,
        [1] = 0.0,
        [2] = 0.0,
        [3] = 0.0,
    },

    linkedTireState = false,
    linkedLoadState = false,
}

--============================================================
-- Utility
--============================================================

local function clamp(v, minValue, maxValue)
    if v < minValue then
        return minValue
    end

    if v > maxValue then
        return maxValue
    end

    return v
end

local function safeNumber(value, defaultValue)
    return tonumber(value) or defaultValue
end

local function safeLoad(key, defaultValue)
    local value =
        ac.load(key)

    if value == nil then
        return defaultValue
    end

    return safeNumber(
        value,
        defaultValue
    )
end

local function safeStore(key, value)
    pcall(
        function()
            ac.store(
                key,
                value
            )
        end
    )
end

local function safeCall(func, defaultValue, ...)
    if type(func) ~= "function" then
        return defaultValue
    end

    local ok, result =
        pcall(
            func,
            ...
        )

    if not ok then
        return defaultValue
    end

    if result == nil then
        return defaultValue
    end

    return result
end

--============================================================
-- External state
--============================================================

local function getLoadState()
    if not okLT or not loadTransfer then
        return nil
    end

    return safeCall(
        loadTransfer.getState,
        nil
    )
end

local function getTireSlipState(index, wheel)
    if okTS
    and tireState
    and tireState.state
    and tireState.state[index] then
        return tireState.state[index], true
    end

    return {
        filteredSlipAngle =
            safeNumber(
                wheel.slipAngle,
                0.0
            ),

        filteredSlipRatio =
            safeNumber(
                wheel.slipRatio,
                0.0
            ),
    }, false
end

--============================================================
-- Wheel input
--============================================================

local function getWheelLoad(wheel)
    local load =
        safeNumber(
            wheel.load,
            nil
        )

    if load ~= nil then
        return load
    end

    local normalLoad =
        safeNumber(
            wheel.normalLoad,
            nil
        )

    if normalLoad ~= nil then
        return normalLoad
    end

    return 0.0
end

local function calculateContactArea(wheel, load)
    local radius =
        safeNumber(
            wheel.tyreRadius,
            M.params.defaultRadius
        )

    local width =
        safeNumber(
            wheel.tyreWidth,
            M.params.defaultWidth
        )

    local pressure =
        safeNumber(
            wheel.tyrePressure,
            M.params.defaultPressure
        )

    pressure =
        math.max(
            pressure,
            M.params.minPressure
        )

    width =
        math.max(
            width,
            0.001
        )

    --------------------------------------------------------
    -- Approx contact patch area
    -- 元コードの式を維持しつつ、安全化
    --------------------------------------------------------

    local denominator =
        pressure
        *
        100000.0
        *
        width
        +
        1.0

    local area =
        2.0
        *
        math.sqrt(
            math.max(
                load
                *
                radius,
                0.0
            )
            /
            denominator
        )
        *
        width

    return area
end

local function calculateLoadGripScale(wheel, load)
    local loadRatio =
        load
        /
        math.max(
            M.params.nominalLoad,
            1.0
        )

    local gripScale =
        1.0
        -
        M.params.loadSensitivity
        *
        (
            loadRatio
            -
            1.0
        )

    gripScale =
        clamp(
            gripScale,
            M.params.minGripScale,
            M.params.maxGripScale
        )

    local surfaceGrip =
        safeNumber(
            wheel.surfaceGrip,
            1.0
        )

    return
        gripScale
        *
        surfaceGrip
end

local function applyLoadTransferGrip(index, gripScale, loadState)
    if not loadState then
        return gripScale
    end

    local factor = 0.5

    if index <= 1 then
        factor =
            safeNumber(
                loadState.front,
                0.5
            )
    else
        factor =
            safeNumber(
                loadState.rear,
                0.5
            )
    end

    return
        gripScale
        *
        (
            0.92
            +
            factor
            *
            0.16
        )
end

local function applyCasterGrip(index, gripScale)
    local casterGrip =
        safeLoad(
            "ngp_caster_grip_" .. index,
            1.0
        )

    return
        gripScale
        *
        casterGrip
end

local function calculatePatchCorrections(slipState)
    local slipAngle =
        safeNumber(
            slipState.filteredSlipAngle,
            0.0
        )

    local slipRatio =
        safeNumber(
            slipState.filteredSlipRatio,
            0.0
        )

    local lat =
        math.cos(
            math.min(
                math.rad(
                    math.abs(
                        slipAngle
                    )
                )
                *
                M.params.patchLateralScale,
                math.pi / 4.0
            )
        )

    local long =
        1.0
        /
        (
            1.0
            +
            math.abs(
                slipRatio
            )
            *
            M.params.patchLongScale
        )

    return lat, long
end

local function clearWheel(index)
    M.debug.area[index] = 0.0
    M.debug.gripScale[index] = 0.0
    M.debug.latCorr[index] = 0.0
    M.debug.longCorr[index] = 0.0
    M.debug.load[index] = 0.0

    safeStore(
        "ngp_cp_area_" .. index,
        0.0
    )

    safeStore(
        "ngp_cp_grip_" .. index,
        0.0
    )

    safeStore(
        "ngp_cp_lat_" .. index,
        0.0
    )

    safeStore(
        "ngp_cp_long_" .. index,
        0.0
    )
end

local function exportWheel(index)
    safeStore(
        "ngp_cp_area_" .. index,
        M.debug.area[index]
    )

    safeStore(
        "ngp_cp_grip_" .. index,
        M.debug.gripScale[index]
    )

    safeStore(
        "ngp_cp_lat_" .. index,
        M.debug.latCorr[index]
    )

    safeStore(
        "ngp_cp_long_" .. index,
        M.debug.longCorr[index]
    )

    safeStore(
        "ngp_cp_load_" .. index,
        M.debug.load[index]
    )
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    local car =
        ac.getCar(0)

    if not car or not car.wheels then
        return
    end

    local loadState =
        getLoadState()

    M.debug.linkedLoadState =
        loadState ~= nil

    local anyTireState =
        false

    for i = 0, 3 do
        local wheel =
            car.wheels[i]

        if wheel then
            local load =
                getWheelLoad(
                    wheel
                )

            M.debug.load[i] =
                load

            if load < M.params.minLoad then
                clearWheel(
                    i
                )
            else
                ------------------------------------------------
                -- Contact patch area
                ------------------------------------------------

                local area =
                    calculateContactArea(
                        wheel,
                        load
                    )

                ------------------------------------------------
                -- Grip scale
                ------------------------------------------------

                local gripScale =
                    calculateLoadGripScale(
                        wheel,
                        load
                    )

                gripScale =
                    applyLoadTransferGrip(
                        i,
                        gripScale,
                        loadState
                    )

                gripScale =
                    applyCasterGrip(
                        i,
                        gripScale
                    )

                ------------------------------------------------
                -- Slip state
                ------------------------------------------------

                local slipState,
                      tireLinked =
                    getTireSlipState(
                        i,
                        wheel
                    )

                anyTireState =
                    anyTireState
                    or tireLinked

                ------------------------------------------------
                -- Patch correction
                ------------------------------------------------

                local latCorr,
                      longCorr =
                    calculatePatchCorrections(
                        slipState
                    )

                ------------------------------------------------
                -- Debug
                ------------------------------------------------

                M.debug.area[i] =
                    area

                M.debug.gripScale[i] =
                    gripScale

                M.debug.latCorr[i] =
                    latCorr

                M.debug.longCorr[i] =
                    longCorr

                ------------------------------------------------
                -- Export
                ------------------------------------------------

                exportWheel(
                    i
                )
            end
        else
            clearWheel(
                i
            )
        end
    end

    M.debug.linkedTireState =
        anyTireState
end

--============================================================
-- Public API
--============================================================

function M.getArea(index)
    return M.debug.area[index] or 0.0
end

function M.getGripScale(index)
    return M.debug.gripScale[index] or 0.0
end

function M.getLateralCorrection(index)
    return M.debug.latCorr[index] or 0.0
end

function M.getLongitudinalCorrection(index)
    return M.debug.longCorr[index] or 0.0
end

function M.debugStr(index)
    if index ~= nil then
        return string.format(
            "Area %.4f Grip %.3f Lat %.3f Long %.3f",
            M.debug.area[index] or 0.0,
            M.debug.gripScale[index] or 0.0,
            M.debug.latCorr[index] or 0.0,
            M.debug.longCorr[index] or 0.0
        )
    end

    return string.format(
        "CP Grip FL %.3f FR %.3f RL %.3f RR %.3f\n" ..
        "Area    FL %.4f FR %.4f RL %.4f RR %.4f\n" ..
        "Links TS:%s LT:%s",

        M.debug.gripScale[0],
        M.debug.gripScale[1],
        M.debug.gripScale[2],
        M.debug.gripScale[3],

        M.debug.area[0],
        M.debug.area[1],
        M.debug.area[2],
        M.debug.area[3],

        M.debug.linkedTireState and "OK" or "NIL",
        M.debug.linkedLoadState and "OK" or "NIL"
    )
end

return M