---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- weight_distribution.lua
-- Phase 15.4
-- Dynamic Weight Distribution
-- 動的重量配分モデル
--============================================================

local M = {}

--============================================================
-- Parameters
--============================================================

M.params = {
    pitchGain = 1.50,
    rollGain  = 1.50,

    minBias = 0.35,
    maxBias = 0.65,

    neutralThreshold = 0.01,
}

--============================================================
-- State
--============================================================

M.state = {
    frontBias = 0.50,
    rearBias  = 0.50,

    leftBias  = 0.50,
    rightBias = 0.50,

    pitchCG = 0.0,
    rollCG  = 0.0,

    stateName = "NEUTRAL",
    rollName  = "NEUTRAL",
}

M.debug = M.state

--============================================================
-- Utility
--============================================================

local function clamp(v, minValue, maxValue)
    if v < minValue then
        return minValue
    end

    if v > maxValue then
        return maxValue
    end

    return v
end

local function safeNumber(value, defaultValue)
    return tonumber(value) or defaultValue
end

local function safeLoad(key, defaultValue)
    local value =
        ac.load(key)

    if value == nil then
        return defaultValue
    end

    return safeNumber(
        value,
        defaultValue
    )
end

local function safeStore(key, value)
    pcall(
        function()
            ac.store(
                key,
                value
            )
        end
    )
end

--============================================================
-- Core
--============================================================

local function updatePitchBias(pitchCG)
    M.state.frontBias =
        clamp(
            0.50
            +
            pitchCG
            *
            M.params.pitchGain,
            M.params.minBias,
            M.params.maxBias
        )

    M.state.rearBias =
        1.0
        -
        M.state.frontBias
end

local function updateRollBias(rollCG)
    M.state.leftBias =
        clamp(
            0.50
            +
            rollCG
            *
            M.params.rollGain,
            M.params.minBias,
            M.params.maxBias
        )

    M.state.rightBias =
        1.0
        -
        M.state.leftBias
end

local function updateStateNames(pitchCG, rollCG)
    if math.abs(pitchCG) < M.params.neutralThreshold then
        M.state.stateName = "BALANCED"

    elseif pitchCG > 0.0 then
        M.state.stateName = "FRONT LOADED"

    else
        M.state.stateName = "REAR LOADED"
    end

    if math.abs(rollCG) < M.params.neutralThreshold then
        M.state.rollName = "CENTERED"

    elseif rollCG > 0.0 then
        M.state.rollName = "LEFT LOADED"

    else
        M.state.rollName = "RIGHT LOADED"
    end
end

--============================================================
-- Export
--============================================================

local function exportState()
    safeStore(
        "ngp_front_bias",
        M.state.frontBias
    )

    safeStore(
        "ngp_rear_bias",
        M.state.rearBias
    )

    safeStore(
        "ngp_left_bias",
        M.state.leftBias
    )

    safeStore(
        "ngp_right_bias",
        M.state.rightBias
    )

    safeStore(
        "ngp_weight_pitch_cg",
        M.state.pitchCG
    )

    safeStore(
        "ngp_weight_roll_cg",
        M.state.rollCG
    )
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    local pitchCG =
        safeLoad(
            "ngp_pitch_cg",
            0.0
        )

    local rollCG =
        safeLoad(
            "ngp_roll_cg",
            0.0
        )

    M.state.pitchCG =
        pitchCG

    M.state.rollCG =
        rollCG

    updatePitchBias(
        pitchCG
    )

    updateRollBias(
        rollCG
    )

    updateStateNames(
        pitchCG,
        rollCG
    )

    exportState()
end

--============================================================
-- Public API
--============================================================

function M.getState()
    return M.state
end

function M.getFrontBias()
    return M.state.frontBias
end

function M.getRearBias()
    return M.state.rearBias
end

function M.getLeftBias()
    return M.state.leftBias
end

function M.getRightBias()
    return M.state.rightBias
end

function M.debugStr()
    return string.format(
        "Front %.1f%% Rear %.1f%%\n" ..
        "Left %.1f%% Right %.1f%%\n" ..
        "%s / %s",

        M.state.frontBias * 100.0,
        M.state.rearBias  * 100.0,

        M.state.leftBias  * 100.0,
        M.state.rightBias * 100.0,

        M.state.stateName,
        M.state.rollName
    )
end

return M
