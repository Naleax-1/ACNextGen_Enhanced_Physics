---@diagnostic disable: undefined-global


--============================================================
-- tire_dynamics.lua
-- Phase 1.x: Tire Dynamics Core
--============================================================

local M = {}
M.state = { wheels = {} }
for i=0,3 do M.state.wheels[i] = { grip=1, limit=0, memory=0, tempGrip=1 } end
M.debug = M.state

local function clamp(v,a,b) if v<a then return a elseif v>b then return b else return v end end

---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- tire_dynamics.lua
-- Phase 1.x
-- Tire Dynamics Core
-- タイヤ動的グリップ / 限界 / メモリ / 温度補正
--============================================================

local M = {}

--============================================================
-- Parameters
--============================================================

M.params = {
    --------------------------------------------------------
    -- Slip model
    --------------------------------------------------------

    slipRatioRef = 0.12,
    slipAngleRef = 10.0,

    postLimitGripDrop = 0.40,

    --------------------------------------------------------
    -- Bias coupling
    --------------------------------------------------------

    biasBase = 0.85,

    --------------------------------------------------------
    -- Rubber memory
    --------------------------------------------------------

    memoryBuildStart = 0.75,
    memoryBuildGain  = 0.80,
    memoryDecayGain  = 0.25,

    rubberMemoryGripLoss = 0.08,
    rubberMemoryLimitGain = 0.20,

    --------------------------------------------------------
    -- Temperature
    --------------------------------------------------------

    ambientTemp = 25.0,
    warmTemp    = 45.0,
    optimumTemp = 95.0,

    tempRange = 70.0,

    coldGripBase = 0.88,
    coldGripGain = 0.18,

    optimumGrip = 1.02,

    overheatGripLoss = 0.008,

    minTempGrip = 0.72,
    maxTempGrip = 1.05,

    --------------------------------------------------------
    -- Hop
    --------------------------------------------------------

    hopGripLoss = 0.10,

    --------------------------------------------------------
    -- Output limits
    --------------------------------------------------------

    maxGrip  = 1.20,
    maxLimit = 2.00,
}

--============================================================
-- State
--============================================================

M.state = {
    wheels = {},
}

for i = 0, 3 do
    M.state.wheels[i] = {
        grip = 1.0,
        limit = 0.0,

        memory = 0.0,
        tempGrip = 1.0,

        slipRatio = 0.0,
        slipAngle = 0.0,

        normalizedSlip = 0.0,

        bias = 0.50,
        memoryGrip = 1.0,
        hopEnergy = 0.0,

        rubberLag = 0.0,
    }
end

M.debug = M.state

--============================================================
-- Utility
--============================================================

local function clamp(v, minValue, maxValue)
    if v < minValue then
        return minValue
    end

    if v > maxValue then
        return maxValue
    end

    return v
end

local function safeNumber(value, defaultValue)
    return tonumber(value) or defaultValue
end

local function safeLoad(key, defaultValue)
    local value =
        ac.load(key)

    if value == nil then
        return defaultValue
    end

    return safeNumber(
        value,
        defaultValue
    )
end

local function safeStore(key, value)
    pcall(
        function()
            ac.store(
                key,
                value
            )
        end
    )
end

--============================================================
-- Wheel input
--============================================================

local function readSlip(wheel)
    local slipRatio =
        math.abs(
            safeNumber(
                wheel.slipRatio,
                0.0
            )
        )

    local slipAngle =
        math.abs(
            safeNumber(
                wheel.slipAngle,
                0.0
            )
        )

    return slipRatio, slipAngle
end

local function getAxleBias(index)
    if index <= 1 then
        return safeLoad(
            "ngp_front_bias",
            0.50
        )
    end

    return safeLoad(
        "ngp_rear_bias",
        0.50
    )
end

--============================================================
-- Core grip calculation
--============================================================

local function calculateSlipGrip(slipRatio)
    local normalizedSlip =
        slipRatio
        /
        math.max(
            M.params.slipRatioRef,
            0.001
        )

    local grip

    if normalizedSlip <= 1.0 then
        grip =
            normalizedSlip
    else
        grip =
            1.0
            -
            (
                normalizedSlip
                -
                1.0
            )
            *
            M.params.postLimitGripDrop
    end

    grip =
        clamp(
            grip,
            0.0,
            1.0
        )

    return grip, normalizedSlip
end

local function calculateLimit(slipRatio, slipAngle)
    return math.max(
        slipRatio,
        slipAngle
        /
        math.max(
            M.params.slipAngleRef,
            0.001
        )
    )
end

local function updateRubberMemory(index, currentMemory, limit, dt)
    local rubberMemory =
        currentMemory

    local build =
        math.max(
            0.0,
            limit
            -
            M.params.memoryBuildStart
        )
        *
        dt
        *
        M.params.memoryBuildGain

    local decay =
        rubberMemory
        *
        dt
        *
        M.params.memoryDecayGain

    rubberMemory =
        rubberMemory
        +
        build
        -
        decay

    rubberMemory =
        clamp(
            rubberMemory,
            0.0,
            1.0
        )

    safeStore(
        "ngp_rubber_memory_" .. index,
        rubberMemory
    )

    return rubberMemory
end

local function calculateTemperatureGrip(tyreTemp)
    local tempNorm =
        clamp(
            (
                tyreTemp
                -
                M.params.ambientTemp
            )
            /
            math.max(
                M.params.tempRange,
                1.0
            ),
            0.0,
            1.0
        )

    local heatGrip =
        1.0

    if tyreTemp < M.params.warmTemp then
        heatGrip =
            M.params.coldGripBase
            +
            tempNorm
            *
            M.params.coldGripGain

    elseif tyreTemp < M.params.optimumTemp then
        heatGrip =
            M.params.optimumGrip

    else
        heatGrip =
            M.params.optimumGrip
            -
            (
                tyreTemp
                -
                M.params.optimumTemp
            )
            *
            M.params.overheatGripLoss
    end

    heatGrip =
        clamp(
            heatGrip,
            M.params.minTempGrip,
            M.params.maxTempGrip
        )

    return heatGrip, tempNorm
end

local function calculateRubberLag(tempNorm)
    return
        (
            0.85
            +
            tempNorm
            *
            0.30
            -
            1.0
        )
        *
        0.15
end

local function applyExternalModifiers(index, grip, heatGrip, rubberMemory)
    local memoryGrip =
        safeLoad(
            "ngp_memory_grip_" .. index,
            1.0
        )

    local hopEnergy =
        safeLoad(
            "ngp_tirehop_energy_" .. index,
            0.0
        )

    local finalGrip =
        grip
        *
        memoryGrip
        *
        heatGrip
        *
        (
            1.0
            -
            rubberMemory
            *
            M.params.rubberMemoryGripLoss
        )
        *
        (
            1.0
            -
            hopEnergy
            *
            M.params.hopGripLoss
        )

    return finalGrip, memoryGrip, hopEnergy
end

--============================================================
-- Export
--============================================================

local function exportWheel(index, wheelState)
    safeStore(
        "ngp_tire_grip_" .. index,
        wheelState.grip
    )

    safeStore(
        "ngp_tire_limit_" .. index,
        wheelState.limit
    )

    safeStore(
        "ngp_rubber_lag_" .. index,
        wheelState.rubberLag
    )

    safeStore(
        "ngp_tire_temp_grip_" .. index,
        wheelState.tempGrip
    )

    safeStore(
        "ngp_tire_norm_slip_" .. index,
        wheelState.normalizedSlip
    )
end

--============================================================
-- Update
--============================================================

function M.update(dt, car)
    if dt <= 0 then
        return
    end

    car =
        car
        or
        ac.getCar(0)

    if not car or not car.wheels then
        return
    end

    for i = 0, 3 do
        local wheel =
            car.wheels[i]

        if wheel then
            local wheelState =
                M.state.wheels[i]

            ------------------------------------------------
            -- Slip input
            ------------------------------------------------

            local slipRatio,
                  slipAngle =
                readSlip(
                    wheel
                )

            wheelState.slipRatio =
                slipRatio

            wheelState.slipAngle =
                slipAngle

            ------------------------------------------------
            -- Base grip / limit
            ------------------------------------------------

            local grip,
                  normalizedSlip =
                calculateSlipGrip(
                    slipRatio
                )

            local limit =
                calculateLimit(
                    slipRatio,
                    slipAngle
                )

            wheelState.normalizedSlip =
                normalizedSlip

            ------------------------------------------------
            -- Front / rear bias
            ------------------------------------------------

            local bias =
                getAxleBias(
                    i
                )

            wheelState.bias =
                bias

            grip =
                grip
                *
                (
                    M.params.biasBase
                    +
                    bias
                )

            ------------------------------------------------
            -- Rubber memory
            ------------------------------------------------

            local rubberMemory =
                safeLoad(
                    "ngp_rubber_memory_" .. i,
                    0.0
                )

            rubberMemory =
                updateRubberMemory(
                    i,
                    rubberMemory,
                    limit,
                    dt
                )

            ------------------------------------------------
            -- Temperature grip
            ------------------------------------------------

            local tyreTemp =
                safeLoad(
                    "ngp_tyre_temp_" .. i,
                    M.params.ambientTemp
                )

            local heatGrip,
                  tempNorm =
                calculateTemperatureGrip(
                    tyreTemp
                )

            ------------------------------------------------
            -- External modifiers
            ------------------------------------------------

            local finalGrip,
                  memoryGrip,
                  hopEnergy =
                applyExternalModifiers(
                    i,
                    grip,
                    heatGrip,
                    rubberMemory
                )

            ------------------------------------------------
            -- Limit correction
            ------------------------------------------------

            limit =
                (
                    limit
                    +
                    rubberMemory
                    *
                    M.params.rubberMemoryLimitGain
                )
                *
                (
                    0.85
                    +
                    tempNorm
                    *
                    0.30
                )

            ------------------------------------------------
            -- Store state
            ------------------------------------------------

            wheelState.grip =
                clamp(
                    finalGrip,
                    0.0,
                    M.params.maxGrip
                )

            wheelState.limit =
                clamp(
                    limit,
                    0.0,
                    M.params.maxLimit
                )

            wheelState.memory =
                rubberMemory

            wheelState.tempGrip =
                heatGrip

            wheelState.memoryGrip =
                memoryGrip

            wheelState.hopEnergy =
                hopEnergy

            wheelState.rubberLag =
                calculateRubberLag(
                    tempNorm
                )

            ------------------------------------------------
            -- Export
            ------------------------------------------------

            exportWheel(
                i,
                wheelState
            )
        end
    end
end

--============================================================
-- Public API
--============================================================

function M.getWheel(index)
    return M.state.wheels[index]
end

function M.getGrip(index)
    local wheelState =
        M.state.wheels[index]

    if not wheelState then
        return 1.0
    end

    return wheelState.grip
end

function M.getLimit(index)
    local wheelState =
        M.state.wheels[index]

    if not wheelState then
        return 0.0
    end

    return wheelState.limit
end

function M.getMemory(index)
    local wheelState =
        M.state.wheels[index]

    if not wheelState then
        return 0.0
    end

    return wheelState.memory
end

function M.debugStr(index)
    local wheelState =
        M.state.wheels[index or 0]
        or
        M.state.wheels[0]

    return string.format(
        "Grip %.3f Limit %.3f Mem %.3f TempGrip %.3f\n" ..
        "Slip %.3f Angle %.3f Bias %.3f",

        wheelState.grip,
        wheelState.limit,
        wheelState.memory,
        wheelState.tempGrip,

        wheelState.slipRatio,
        wheelState.slipAngle,
        wheelState.bias
    )
end

return M