---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- tire_force.lua
-- Phase 1
-- Tire Transient Force
-- タイヤ過渡力モデル
--============================================================

local M = {}

--============================================================
-- Dependencies
--============================================================

local okTS, tireState =
    pcall(
        require,
        "modules/tire_state"
    )

--============================================================
-- Parameters
--============================================================

M.params = {
    lateralScale = 300.0,
    longitudinalScale = 105.0,

    maxForce = 2500.0,

    loadReference = 4000.0,
    defaultLoad = 3000.0,

    minLoadScale = 0.0,
    maxLoadScale = 1.5,

    contactGripInfluence = 0.20,
    dynamicsGripInfluence = 0.15,
}

--============================================================
-- State
--============================================================

M.lastForce = {}

for i = 0, 3 do
    M.lastForce[i] = {
        lateral = 0.0,
        longitudinal = 0.0,

        dSlipAngle = 0.0,
        dSlipRatio = 0.0,

        loadScale = 0.0,

        contactGrip = 1.0,
        tireGrip = 1.0,
    }
end

M.debug = {
    force = M.lastForce,

    tireStateLinked = false,
}

--============================================================
-- Utility
--============================================================

local function clamp(v, minValue, maxValue)
    if v < minValue then
        return minValue
    end

    if v > maxValue then
        return maxValue
    end

    return v
end

local function safeNumber(value, defaultValue)
    return tonumber(value) or defaultValue
end

local function safeLoad(key, defaultValue)
    local value =
        ac.load(key)

    if value == nil then
        return defaultValue
    end

    return safeNumber(
        value,
        defaultValue
    )
end

local function safeStore(key, value)
    pcall(
        function()
            ac.store(
                key,
                value
            )
        end
    )
end

--============================================================
-- Input helpers
--============================================================

local function getTireState(index)
    if not okTS
    or not tireState
    or not tireState.state
    or not tireState.state[index] then
        return nil
    end

    return tireState.state[index]
end

local function getWheelLoad(wheel, index)
    local load =
        safeNumber(
            wheel.load,
            nil
        )

    if load ~= nil then
        return load
    end

    local normalLoad =
        safeNumber(
            wheel.normalLoad,
            nil
        )

    if normalLoad ~= nil then
        return normalLoad
    end

    local dynamicLoad =
        safeLoad(
            "ngp_dlt_load_" .. index,
            0.0
        )

    return
        M.params.defaultLoad
        +
        dynamicLoad
end

local function calculateLoadScale(load)
    local scale =
        load
        /
        math.max(
            M.params.loadReference,
            1.0
        )

    return clamp(
        scale,
        M.params.minLoadScale,
        M.params.maxLoadScale
    )
end

local function getContactGrip(index)
    return safeLoad(
        "ngp_cp_grip_" .. index,
        1.0
    )
end

local function getTireGrip(index)
    return safeLoad(
        "ngp_tire_grip_" .. index,
        1.0
    )
end

local function applyExternalGrip(force, contactGrip, tireGrip)
    local contactFactor =
        1.0
        +
        (
            contactGrip
            -
            1.0
        )
        *
        M.params.contactGripInfluence

    local tireFactor =
        1.0
        +
        (
            tireGrip
            -
            1.0
        )
        *
        M.params.dynamicsGripInfluence

    return
        force
        *
        contactFactor
        *
        tireFactor
end

--============================================================
-- Core
--============================================================

local function calculateTransientForce(index, wheel, state)
    local force =
        M.lastForce[index]

    local slipAngle =
        safeNumber(
            wheel.slipAngle,
            0.0
        )

    local slipRatio =
        safeNumber(
            wheel.slipRatio,
            0.0
        )

    local filteredSlipAngle =
        safeNumber(
            state.filteredSlipAngle,
            slipAngle
        )

    local filteredSlipRatio =
        safeNumber(
            state.filteredSlipRatio,
            slipRatio
        )

    local dSlipAngle =
        slipAngle
        -
        filteredSlipAngle

    local dSlipRatio =
        slipRatio
        -
        filteredSlipRatio

    local load =
        getWheelLoad(
            wheel,
            index
        )

    local loadScale =
        calculateLoadScale(
            load
        )

    local lateral =
        dSlipAngle
        *
        M.params.lateralScale
        *
        loadScale

    local longitudinal =
        dSlipRatio
        *
        M.params.longitudinalScale
        *
        loadScale

    local contactGrip =
        getContactGrip(
            index
        )

    local tireGrip =
        getTireGrip(
            index
        )

    lateral =
        applyExternalGrip(
            lateral,
            contactGrip,
            tireGrip
        )

    longitudinal =
        applyExternalGrip(
            longitudinal,
            contactGrip,
            tireGrip
        )

    force.lateral =
        clamp(
            lateral,
            -M.params.maxForce,
            M.params.maxForce
        )

    force.longitudinal =
        clamp(
            longitudinal,
            -M.params.maxForce,
            M.params.maxForce
        )

    force.dSlipAngle =
        dSlipAngle

    force.dSlipRatio =
        dSlipRatio

    force.loadScale =
        loadScale

    force.contactGrip =
        contactGrip

    force.tireGrip =
        tireGrip
end

local function clearWheel(index)
    local force =
        M.lastForce[index]

    force.lateral = 0.0
    force.longitudinal = 0.0

    force.dSlipAngle = 0.0
    force.dSlipRatio = 0.0

    force.loadScale = 0.0

    force.contactGrip = 1.0
    force.tireGrip = 1.0
end

--============================================================
-- Export
--============================================================

local function exportWheel(index)
    local force =
        M.lastForce[index]

    safeStore(
        "ngp_lat_" .. index,
        force.lateral
    )

    safeStore(
        "ngp_long_" .. index,
        force.longitudinal
    )

    safeStore(
        "ngp_tire_dsa_" .. index,
        force.dSlipAngle
    )

    safeStore(
        "ngp_tire_dsr_" .. index,
        force.dSlipRatio
    )

    safeStore(
        "ngp_tire_force_loadscale_" .. index,
        force.loadScale
    )
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    local car =
        ac.getCar(0)

    if not car or not car.wheels then
        return
    end

    local linked =
        false

    for i = 0, 3 do
        local wheel =
            car.wheels[i]

        local state =
            getTireState(
                i
            )

        if wheel and state then
            linked = true

            calculateTransientForce(
                i,
                wheel,
                state
            )
        else
            clearWheel(
                i
            )
        end

        exportWheel(
            i
        )
    end

    M.debug.tireStateLinked =
        linked
end

--============================================================
-- Public API
--============================================================

function M.getLateral(index)
    local force =
        M.lastForce[index]

    if not force then
        return 0.0
    end

    return force.lateral
end

function M.getLongitudinal(index)
    local force =
        M.lastForce[index]

    if not force then
        return 0.0
    end

    return force.longitudinal
end

function M.getForce(index)
    return M.lastForce[index]
end

function M.debugStr(index)
    if index ~= nil then
        local force =
            M.lastForce[index]
            or
            M.lastForce[0]

        return string.format(
            "Lat %+7.1f Long %+7.1f\n" ..
            "dSA %.4f dSR %.4f LS %.2f",

            force.lateral,
            force.longitudinal,

            force.dSlipAngle,
            force.dSlipRatio,
            force.loadScale
        )
    end

    return string.format(
        "Lat FL:%+.0f FR:%+.0f RL:%+.0f RR:%+.0f\n" ..
        "Lng FL:%+.0f FR:%+.0f RL:%+.0f RR:%+.0f\n" ..
        "TireState:%s",

        M.lastForce[0].lateral,
        M.lastForce[1].lateral,
        M.lastForce[2].lateral,
        M.lastForce[3].lateral,

        M.lastForce[0].longitudinal,
        M.lastForce[1].longitudinal,
        M.lastForce[2].longitudinal,
        M.lastForce[3].longitudinal,

        M.debug.tireStateLinked and "OK" or "NIL"
    )
end

return M
