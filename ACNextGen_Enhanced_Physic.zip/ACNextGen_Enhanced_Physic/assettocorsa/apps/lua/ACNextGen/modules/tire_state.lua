---@diagnostic disable: undefined-global

--============================================================
-- ACNeXtGen
-- tire_state.lua
-- Phase 1
-- Tire Relaxation Length Model
-- タイヤ緩和長 / スリップ状態フィルタ
--============================================================

local M = {}

--============================================================
-- Parameters
--============================================================

M.params = {
    relaxLateral = 0.18,
    relaxLongitudinal = 0.20,

    minSpeed = 0.5,

    minRelaxLength = 0.001,

    memoryLagGain = 0.20,

    defaultLoad = 3000.0,
}

--============================================================
-- State
--============================================================

M.state = {}

for i = 0, 3 do
    M.state[i] = {
        filteredSlipAngle = 0.0,
        filteredSlipRatio = 0.0,

        rawSlipAngle = 0.0,
        rawSlipRatio = 0.0,

        load = 0.0,

        lag = 0.0,

        lateralRelaxLength = M.params.relaxLateral,
        longitudinalRelaxLength = M.params.relaxLongitudinal,
    }
end

M.debug = M.state

--============================================================
-- Utility
--============================================================

local function clamp(v, minValue, maxValue)
    if v < minValue then
        return minValue
    end

    if v > maxValue then
        return maxValue
    end

    return v
end

local function safeNumber(value, defaultValue)
    return tonumber(value) or defaultValue
end

local function safeLoad(key, defaultValue)
    local value =
        ac.load(key)

    if value == nil then
        return defaultValue
    end

    return safeNumber(
        value,
        defaultValue
    )
end

local function safeStore(key, value)
    pcall(
        function()
            ac.store(
                key,
                value
            )
        end
    )
end

--============================================================
-- Input helpers
--============================================================

local function getWheelLoad(wheel, index)
    local load =
        safeNumber(
            wheel.load,
            nil
        )

    if load ~= nil then
        return load
    end

    local normalLoad =
        safeNumber(
            wheel.normalLoad,
            nil
        )

    if normalLoad ~= nil then
        return normalLoad
    end

    local dynamicLoad =
        safeLoad(
            "ngp_dlt_load_" .. index,
            0.0
        )

    return
        M.params.defaultLoad
        +
        dynamicLoad
end

local function getRubberLag(index)
    local rubberLag =
        safeLoad(
            "ngp_rubber_lag_" .. index,
            0.0
        )

    local memory =
        safeLoad(
            "ngp_memory_" .. index,
            0.0
        )

    return
        rubberLag
        +
        memory
        *
        M.params.memoryLagGain
end

--============================================================
-- Relaxation model
--============================================================

local function relaxation(current, target, speed, length, dt)
    if speed < M.params.minSpeed then
        return target
    end

    local sigma =
        (
            speed
            *
            dt
        )
        /
        math.max(
            length,
            M.params.minRelaxLength
        )

    sigma =
        clamp(
            sigma,
            0.0,
            1.0
        )

    return
        current
        +
        (
            target
            -
            current
        )
        *
        sigma
end

local function updateWheelState(index, wheel, speedMs, dt)
    local state =
        M.state[index]

    --------------------------------------------------------
    -- External lag
    --------------------------------------------------------

    local lag =
        getRubberLag(
            index
        )

    local lateralLength =
        M.params.relaxLateral
        *
        (
            1.0
            +
            lag
        )

    local longitudinalLength =
        M.params.relaxLongitudinal
        *
        (
            1.0
            +
            lag
        )

    --------------------------------------------------------
    -- Raw input
    --------------------------------------------------------

    state.rawSlipAngle =
        safeNumber(
            wheel.slipAngle,
            0.0
        )

    state.rawSlipRatio =
        safeNumber(
            wheel.slipRatio,
            0.0
        )

    state.load =
        getWheelLoad(
            wheel,
            index
        )

    --------------------------------------------------------
    -- Relaxation
    --------------------------------------------------------

    state.filteredSlipAngle =
        relaxation(
            state.filteredSlipAngle,
            state.rawSlipAngle,
            speedMs,
            lateralLength,
            dt
        )

    state.filteredSlipRatio =
        relaxation(
            state.filteredSlipRatio,
            state.rawSlipRatio,
            speedMs,
            longitudinalLength,
            dt
        )

    --------------------------------------------------------
    -- Debug
    --------------------------------------------------------

    state.lag =
        lag

    state.lateralRelaxLength =
        lateralLength

    state.longitudinalRelaxLength =
        longitudinalLength
end

--============================================================
-- Export
--============================================================

local function exportWheel(index)
    local state =
        M.state[index]

    safeStore(
        "ngp_slip_angle_" .. index,
        state.filteredSlipAngle
    )

    safeStore(
        "ngp_slip_ratio_" .. index,
        state.filteredSlipRatio
    )

    safeStore(
        "ngp_raw_slip_angle_" .. index,
        state.rawSlipAngle
    )

    safeStore(
        "ngp_raw_slip_ratio_" .. index,
        state.rawSlipRatio
    )

    safeStore(
        "ngp_tire_state_load_" .. index,
        state.load
    )

    safeStore(
        "ngp_tire_relax_lat_" .. index,
        state.lateralRelaxLength
    )

    safeStore(
        "ngp_tire_relax_long_" .. index,
        state.longitudinalRelaxLength
    )
end

--============================================================
-- Update
--============================================================

function M.update(dt)
    if dt <= 0 then
        return
    end

    local car =
        ac.getCar(0)

    if not car or not car.wheels then
        return
    end

    local speedMs =
        safeNumber(
            car.speedKmh,
            0.0
        )
        /
        3.6

    for i = 0, 3 do
        local wheel =
            car.wheels[i]

        if wheel then
            updateWheelState(
                i,
                wheel,
                speedMs,
                dt
            )

            exportWheel(
                i
            )
        end
    end
end

--============================================================
-- Public API
--============================================================

function M.getState(index)
    return M.state[index]
end

function M.getSlipAngle(index)
    local state =
        M.state[index]

    if not state then
        return 0.0
    end

    return state.filteredSlipAngle
end

function M.getSlipRatio(index)
    local state =
        M.state[index]

    if not state then
        return 0.0
    end

    return state.filteredSlipRatio
end

function M.getRawSlipAngle(index)
    local state =
        M.state[index]

    if not state then
        return 0.0
    end

    return state.rawSlipAngle
end

function M.getRawSlipRatio(index)
    local state =
        M.state[index]

    if not state then
        return 0.0
    end

    return state.rawSlipRatio
end

function M.debugStr(index)
    if index ~= nil then
        local state =
            M.state[index]
            or
            M.state[0]

        return string.format(
            "SA %.3f->%.3f SR %.3f->%.3f\n" ..
            "Load %.0f Lag %.3f",

            state.rawSlipAngle,
            state.filteredSlipAngle,

            state.rawSlipRatio,
            state.filteredSlipRatio,

            state.load,
            state.lag
        )
    end

    return string.format(
        "SA FL %.3f FR %.3f RL %.3f RR %.3f\n" ..
        "SR FL %.3f FR %.3f RL %.3f RR %.3f",

        M.state[0].filteredSlipAngle,
        M.state[1].filteredSlipAngle,
        M.state[2].filteredSlipAngle,
        M.state[3].filteredSlipAngle,

        M.state[0].filteredSlipRatio,
        M.state[1].filteredSlipRatio,
        M.state[2].filteredSlipRatio,
        M.state[3].filteredSlipRatio
    )
end

return M
