ACNeXtGen Complete Fixed Package
================================

English

Español

日本語



# ACNeXtGen Complete Fixed Package

## Overview

ACNeXtGen is an attempt to enhance and reinterpret part of Assetto Corsa’s physics and calculation behavior through Lua scripting.

This package is placed in:

```text
apps/lua/ACNextGen/
  ACNextGen.lua
  manifest.ini
  modules/*.lua
```

Its purpose is not to decorate the surface of the simulation, nor to simply add visual or force-feedback effects.
ACNeXtGen was created as a “root and trunk” approach: a project that studies the behavior of the car itself, then reshapes the way grip, load, compliance, drivetrain response, suspension input, tire memory, yaw behavior, and road information are interpreted.

By analyzing and editing the Lua scripts, anyone can touch the behavior of Assetto Corsa not only from the vehicle data folder, but from a more physical and systemic layer.

This project also works without placing `script.lua` inside each individual car.
That point is important. ACNeXtGen is intended to remain universal, modular, and independent from per-car edits as much as possible.

## Philosophy

ACNeXtGen was born from one belief:

A simulator should not only move a car.
It should give the driver a reason to understand the car.

The goal of this project is to help Assetto Corsa express more of the hidden work happening beneath the surface: the contact patch, the tire carcass, the load path, the driveline windup, the suspension delay, the recovery from slip, the yaw moment budget, and the dialogue between road, tire, chassis, and driver.

This is not a claim that ACNeXtGen is perfect.
Rather, it is a completed step — one possible contribution toward better physics, deeper vehicle behavior, and a more honest driving experience.

## Message

The One Point One Plan is now complete.

To everyone who opens these Lua files, reads them, edits them, breaks them, repairs them, and improves them:

Please do not treat physics as a closed box.

Please question it.
Please analyze it.
Please improve it.
Please search for what the car is really trying to say.

I sincerely hope this project becomes a small aid for those who pursue better physics, better simulation, and the truth hidden inside vehicle behavior.

May every user keep the power to seek truth.

## Credits

I took part in the creation and direction of this project, while the overall construction and refinement were supported with GPT-5.5.

Thank you for walking with ACNeXtGen.
And from here on as well — I look forward to what we will build next.



# ACNeXtGen Complete Fixed Package

## Descripción general

ACNeXtGen es un intento de mejorar y reinterpretar parte del comportamiento físico y de cálculo de Assetto Corsa mediante scripts Lua.

Este paquete se coloca en:

```text
apps/lua/ACNextGen/
  ACNextGen.lua
  manifest.ini
  modules/*.lua
```

Su objetivo no es decorar la superficie de la simulación, ni limitarse a añadir efectos visuales o de force feedback.
ACNeXtGen fue creado como un enfoque de “raíz y tronco”: un proyecto que estudia el comportamiento del coche en sí mismo y después redefine cómo se interpretan el agarre, la carga, la flexibilidad, la respuesta de la transmisión, la entrada de la suspensión, la memoria del neumático, el comportamiento de guiñada y la información que llega desde la carretera.

Al analizar y editar los scripts Lua, cualquier persona puede modificar el comportamiento de Assetto Corsa no solo desde la carpeta de datos del vehículo, sino también desde una capa más física y sistémica.

Este proyecto también funciona sin colocar `script.lua` dentro de cada coche individual.
Ese punto es importante. ACNeXtGen busca mantenerse universal, modular e independiente de las ediciones específicas de cada vehículo tanto como sea posible.

## Filosofía

ACNeXtGen nació de una convicción:

Un simulador no debería limitarse a mover un coche.
Debería darle al conductor una razón para comprenderlo.

El objetivo de este proyecto es ayudar a Assetto Corsa a expresar más del trabajo oculto que ocurre bajo la superficie: la huella de contacto, la carcasa del neumático, el recorrido de la carga, la torsión de la transmisión, el retardo de la suspensión, la recuperación del deslizamiento, el presupuesto del momento de guiñada y el diálogo entre carretera, neumático, chasis y conductor.

Esto no es una declaración de que ACNeXtGen sea perfecto.
Más bien, es un paso completado: una posible contribución hacia una física mejor, un comportamiento vehicular más profundo y una experiencia de conducción más honesta.

## Mensaje

El Plan One Point One ha llegado a su final.

A todos los que abran estos archivos Lua, los lean, los editen, los rompan, los reparen y los mejoren:

No traten la física como una caja cerrada.

Cuestiónenla.
Analícenla.
Mejórenla.
Busquen lo que el coche realmente intenta decir.

Espero sinceramente que este proyecto se convierta en una pequeña ayuda para quienes persiguen una física mejor, una simulación mejor y la verdad escondida dentro del comportamiento del vehículo.

Que cada usuario conserve la fuerza para buscar la verdad.

## Créditos

Participé en la creación y dirección de este proyecto, mientras que la construcción y el refinamiento general fueron apoyados por GPT-5.5.

Gracias por caminar junto a ACNeXtGen.
Y de aquí en adelante también — espero con entusiasmo lo que construiremos después.



# ACNeXtGen Complete Fixed Package

## 概要

ACNeXtGenは、Assetto Corsaの物理挙動と演算をLuaスクリプトによって部分的に強化し、再解釈する試みです。

配置は以下の通りです。

```text
apps/lua/ACNextGen/
  ACNextGen.lua
  manifest.ini
  modules/*.lua
```

これは単なる演出追加ではありません。
画面上の揺れ、見た目の補正、FFB風の味付けだけを目的としたものでもありません。

ACNeXtGenは、車両挙動の「根」と「幹」に触れるための計画です。
接地、荷重、コンプライアンス、駆動系、サスペンション入力、タイヤの記憶、ヨーモーメント、路面から車体へ入る情報。
それらをLua上で読み取り、分解し、組み直すことで、Assetto Corsaの挙動をより深く扱うことを目指しました。

Luaスクリプトを解析し、編集すれば、誰でも車両データフォルダだけに依存せず、より物理的な面からAssetto Corsaの挙動に手を加えることができます。

また、このプロジェクトは各車両に`script.lua`を配置しなくても機能する構成を目指しています。
それはACNeXtGenにとって非常に重要な点です。
特定の車だけを救うのではなく、可能な限り普遍的に、モジュールとして、車両側編集に依存しない形で機能することを目指しました。

## 思想

ACNeXtGenは、ひとつの信念から始まりました。

シミュレーターは、ただ車を動かすだけでは足りない。
ドライバーが車を理解する理由を与えるべきだ。

車は、路面、タイヤ、サスペンション、シャシー、駆動系を通して、常に何かを語っています。
接地が乱れた瞬間、荷重が逃げた瞬間、タイヤが戻ろうとする瞬間、デフが車体を押し出す瞬間、シャシーが遅れて応答する瞬間。
それらはすべて、車がドライバーへ渡す情報です。

ACNeXtGenは、その情報をより深く見ようとしたプロジェクトです。

これは完璧な物理を名乗るものではありません。
しかし、より良い物理、より深い挙動、より正直なドライビングフィールへ向かうための、ひとつの完結した歩みです。

## メッセージ

ワンポイントワン計画は、ここに完結しました。

このLuaを開き、読み、解析し、編集し、壊し、直し、さらに良くしようとするすべての人へ。

どうか、物理を閉じた箱として扱わないでください。

疑ってください。
調べてください。
分解してください。
改善してください。
車が本当は何を語ろうとしているのか、追いかけてください。

このプロジェクトが、より良い物理への小さな一助となることを願います。
そして、Assetto Corsaというシミュレーターの中で、まだ眠っている可能性を見つけるきっかけになることを願います。

私は、ユーザーの真理を追究する力を信じ、そして祈ります。

## クレジット

私はこのプロジェクトの制作と方針決定に携わりました。
全体的な構築と整理には、GPT-5.5の助力を受けました。

ACNeXtGenと共に歩んでくださり、ありがとうございました。
そして、これからもよろしくお願いします。



