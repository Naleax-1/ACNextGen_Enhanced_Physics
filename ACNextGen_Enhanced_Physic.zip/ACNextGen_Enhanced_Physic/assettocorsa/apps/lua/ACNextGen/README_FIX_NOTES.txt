ACNeXtGen Complete Fixed Package
================================

配置:
apps/lua/ACNextGen/
  ACNextGen.lua
  manifest.ini
  modules/*.lua




これはアセットコルサの物理と演算を部分的に強化させる試みで機能します
また、誰でも物理へと手を加えることができるようにしました
私は製作に携さりましたが、全体的な製作はGPT5.5に頼りました


