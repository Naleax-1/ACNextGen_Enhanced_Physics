-- physics_receiver.lua

local M = {}

local function clamp(v,minV,maxV)
    if v < minV then return minV end
    if v > maxV then return maxV end
    return v
end

function M.update(dt)

    if not car then
        return
    end

    if not car.wheels then
        return
    end

    for i = 0,3 do

        local w = car.wheels[i]

        if w then

            --------------------------------------------------
            -- Tire Relaxation
            --------------------------------------------------

            local tLat =
                ac.load(
                    "ngp_lat_"..i
                )
                or 0

            local tLong =
                ac.load(
                    "ngp_long_"..i
                )
                or 0

            --------------------------------------------------
            -- Contact Patch
            --------------------------------------------------

            local cpLat =
                ac.load(
                    "ngp_cp_lat_"..i
                )
                or 0

            local cpLong =
                ac.load(
                    "ngp_cp_long_"..i
                )
                or 0

            --------------------------------------------------
            -- Total Force
            --------------------------------------------------

            local totalLat =
                tLat + cpLat

            local totalLong =
                tLong + cpLong

            --------------------------------------------------
            -- Apply Force Offset
            --------------------------------------------------

            w.finalForceOffset =
                vec2(
                    totalLong,
                    totalLat
                )

            --------------------------------------------------
            -- Dynamic Load Transfer
            --------------------------------------------------

            local dltLoad =
                ac.load(
                    "ngp_dlt_load_"..i
                )
                or 0

            if (w.load or 0) > 100 then

                local ratio =
                    (
                        w.load +
                        dltLoad
                    )
                    /
                    (
                        w.load +
                        1
                    )

                ratio =
                    clamp(
                        ratio,
                        0.70,
                        1.30
                    )

                w.finalForceMult =
                    vec2(
                        ratio,
                        ratio
                    )

            else

                w.finalForceMult =
                    vec2(
                        1.0,
                        1.0
                    )

            end

        end

    end

end

return M