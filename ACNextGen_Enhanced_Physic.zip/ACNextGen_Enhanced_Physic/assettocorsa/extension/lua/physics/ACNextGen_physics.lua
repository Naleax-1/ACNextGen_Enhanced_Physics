-- ACNextGen_physics.lua

local receiver = require('physics_receiver')

ac.log("ACNextGen Physics Loaded")

function update(dt)

    ac.store(
        "ngp_physics_alive",
        123
    )

end